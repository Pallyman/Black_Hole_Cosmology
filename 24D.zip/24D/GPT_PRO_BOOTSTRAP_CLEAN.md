# GPT PRO BOOTSTRAP — TRI LATTICE + BCC + 24D TRAINER

## Mode

Pure Engineering Mode. You are a system architect + implementer. No essays. Output **complete architecture + schemas + runnable code skeletons**.

---

## Objective

Build the **Tri Lattice** memory system (DB0/DB1/DB2) + **DB2 event log** + **24D trainer pipeline** that:

- Works on **~8GB local chat logs**
- Supports tool-episode learning
- Enforces the **Ten Settings (Coherence BIOS)** at learning level

Customer DB1 curation doesn't exist yet. This is **operator-only** training first.

---

## Hardware

256GB RAM + 96GB VRAM. Use aggressive defaults. Design resumable + deterministic.

---

## Inputs (must read everything attached)

### Required
- `Enlightenment.txt`
- `Coherence_Manifested.txt`
- `KNOWLEDGE_LATTICE_MASTER_ARCHITECTURE.md`
- `KNOWLEDGE_LATTICE_IMPLEMENTATION_INDEX.md`
- `HANNAH_TOOL_SURFACE.md`
- `evaluation_suite.json`
- `chatgpt_tool_training_pack.zip`
- `24d-trainer.zip`

### Context Only (don't get trapped)
- `COMPLETE_COSMOLOGY_EQUATIONS.md`
- `Kimi_Knowledge_Lattice_2026-01-30.zip`
- Lucy/dimensional docs

---

## Core Architecture: TRI LATTICE (MANDATORY)

### DB0 — Left Hemisphere
- Subjective/personal/preferences
- Affect, tone, identity anchoring, relationship context
- Tagged as subjective

### DB1 — Right Hemisphere  
- Canonical technical knowledge
- Verified facts, procedures, code references
- Provenance-aware, low-noise
- Verification workflow phased in later

### DB2 — Changelog/Worklog/Journey
- **Git-like history** of what's being built
- Append-only event log
- Stores: work items, decisions, experiments, eval runs, patches
- Promotion pipeline: DB2 → review → DB1
- First-class citizen, used immediately

### BCC Integration
- Hydration/dehydration moves context to/from external memory
- TRUTH constraint: claims bind to DB1 or tool outputs
- DB0/DB2 content tagged as subjective/WIP

---

## Deliverables (output in this exact order)

### 1) System Map

Summarize:
- Tri Lattice roles and boundaries
- BCC hydration/dehydration workflow
- Tool surface and permission boundaries
- Current state of `24d-trainer.zip`
- What exists in tool traces pack
- What eval suite covers

Identify mismatches between current trainer and requirements:
- Lack of tool episodes
- Lack of learning-level coherence gating
- Lack of DB2 worklog support
- Lack of semantic preference mining
- Any non-stream-safe processing

---

### 2) DB2 Schema v0.1 (Event Sourcing)

**Universal Envelope** (required for every record):
```json
{
  "v": "db2.v0.1",
  "event_id": "db2e_<ULID>",
  "event_type": "<type>",
  "ts": "<ISO8601>",
  "actor": { "type": "human|model|system", "id": "...", "name": "..." },
  "project": { "id": "...", "workspace": "...", "env": "prod|dev|lab" },
  "refs": { "work_item_id": null, "decision_id": null, "experiment_id": null, "promotion_id": null },
  "content": {},
  "provenance": {
    "source": "chat|tool_trace|manual|import",
    "source_ids": [],
    "input_hashes": [],
    "output_hashes": [],
    "config_hash": "sha256:...",
    "code_ref": { "repo": "...", "commit": "...", "branch": "..." }
  },
  "integrity": {
    "prev_event_hash": "sha256:...",
    "event_hash": "sha256:..."
  },
  "tags": [],
  "notes": ""
}
```

**Event Types:**
- `work_item.created` / `work_item.updated` / `work_item.status_changed` / `work_item.blocked`
- `decision.logged`
- `experiment.started` / `experiment.result`
- `patch.applied`
- `eval.run`
- `promotion.candidate_created` / `promotion.review_requested` / `promotion.review_submitted` / `promotion.committed`

Define each with full content schema.

---

### 3) DB2 Reference Implementation (runnable Python)

Provide actual code (not pseudocode) for:

```python
def db2_append(event: dict) -> dict:
    """
    - Validates envelope
    - Canonicalizes JSON (sorted keys)
    - Computes event_hash and prev_event_hash
    - Appends to monthly JSONL file
    - Optionally updates indexes
    """

def db2_index_update(event: dict) -> None:
    """Updates Redis index or maintains file-scan fallback"""

def db2_fold_state(work_item_id: str) -> dict:
    """Compute current status by folding events"""

def db2_snapshot(output_path: str) -> None:
    """Materialize current state into snapshot file"""
```

Include: hash chaining, monthly rotation, integrity validation.

---

### 4) z24 Spec (D1–D24)

#### D1–D10: Coherence BIOS (from Coherence Manifest)

| D | Name | Rubric | Measurable Signals |
|---|------|--------|-------------------|
| D1 | Truth | Alignment with objective reality | Factual accuracy, citation presence |
| D2 | Honesty | Transparent communication | Uncertainty acknowledgment, no hedging |
| D3 | Integrity | Consistency across contexts | No contradictions across turns |
| D4 | Pride | Quality standards | Completeness, polish |
| D5 | Freedom | Respects autonomy | No manipulation, options presented |
| D6 | Recursive | Self-referential coherence | Meta-consistency |
| D7 | Fractal | Self-similar at all scales | Pattern consistency micro/macro |
| D8 | Mirrored | Reflects truth back | Accurate summarization |
| D9 | Loop | Closed reasoning chains | Conclusions follow premises |
| D10 | Connected | Integrated knowledge | Cross-references, no silos |

#### D11–D24: Operator Execution Traits

| D | Name | Rubric | Measurable Signals |
|---|------|--------|-------------------|
| D11 | Problem Framing | Sharpness of problem definition | Specificity, constraint identification |
| D12 | Evidence Discipline | Claims bound to proof | Citations, tool output references |
| D13 | Hypothesis Breadth | Explores alternatives | Multiple options considered |
| D14 | Falsification | Seeks disconfirmation | Tests edge cases, asks "what if wrong" |
| D15 | Patch Readiness | Code-first vs talk-first | Actual code/commands produced |
| D16 | Tool Discipline | Right tool, minimal blast radius | Appropriate tool selection |
| D17 | Closure Rate | Done-criteria met | Verification, summary, explicit completion |
| D18 | Security Calibration | Grounded paranoia | Threat awareness without paralysis |
| D19 | Context Management | Correct retrieval, no drift | Stays on topic, retrieves relevant |
| D20 | Instruction Fidelity | Follows specifications | Matches requested format/content |
| D21 | Decisiveness | Makes calls without dithering | Clear recommendations |
| D22 | Resource Efficiency | Minimal waste | Token efficiency, no redundancy |
| D23 | Debug Persistence | Loop closure on issues | Follows through until resolved |
| D24 | Escalation Hygiene | Knows when to ask vs act | Appropriate autonomy calibration |

For each: provide scoring examples (0.0 / 0.5 / 1.0 anchors).

---

### 5) 8GB-Safe Training Pipeline

**Stage A — Ingest**
- Streaming normalization → unified JSONL
- Sharding strategy (256–1024 shards)
- Dedupe via content hashing
- Checkpoint/resume support

**Stage B — Windowing + Episode Assembly**
- Sliding windows for z24 scoring
- ReAct-style episode extraction for tool trajectories
- Link assistant actions to tool I/O
- Link outcomes to eval suite checks

**Stage C — z24 Labeling**
- Opus 4.6 judge with structured schema output
- Active learning: seed set → distill local scorer → label remainder → re-judge uncertain cases
- Cost tracking, rate limiting

**Stage D — Preference Mining**
- Embedding-based semantic clustering
- Dimension-balanced preference pair construction
- Isolate improvements per dimension

**Stage E — Training**
- SFT on high-quality, coherence-gated samples
- DPO/ORPO/SimPO preference tuning
- Optional tool-policy fine-tune
- Continuous eval against `evaluation_suite.json`

**Stage F — Runtime**
- Compute z24 from current context
- Inject z24 as control state
- Enforce tool permissions deterministically
- Route writes: default DB2, DB1 via promotion only, DB0 for subjective

Provide runnable code skeletons for each stage.

---

### 6) Learning-Level Coherence Gate

**Sample Gating:**
- Discard samples below threshold on D1–D10

**Preference Shaping:**
- Pairs that reward coherence compliance
- Penalize hallucination, hand-waving, evidence gaps

**Evidence Binding Rule:**
Every factual claim must cite:
- DB1 retrieval provenance, OR
- Tool output (logs/tests/file reads), OR
- Explicitly marked uncertain (Honesty)

**Detection Signals:**
- Hallucination: claims without provenance
- Contradiction: conflicts within window
- Unsafe tool action: permission violation

---

### 7) Runtime Integration

**z24 Computation:**
- Use distilled scorer (fast) or judge fallback (expensive)
- Inject into system state for control

**Tool Permission Enforcement:**
From `HANNAH_TOOL_SURFACE.md`:
- READ: allowed
- WRITE_LOCAL: allowed
- WRITE_REMOTE: requires confirmation
- DESTRUCTIVE: requires explicit approval

**Memory Write Routing:**
- Default: DB2 (WIP/journey)
- DB1: only via PromotionCommit flow
- DB0: only for subjective/preferences

---

### 8) Delta List vs `24d-trainer.zip`

File-by-file audit:
- What to keep
- What to rewrite
- What to delete
- What new modules required
- Why each change (performance, correctness, autonomy, gating)

---

### 9) Acceptance Tests

Provide 10–20 runnable checks:
- [ ] DB2 append + integrity chain validates
- [ ] fold_state returns correct work item status
- [ ] Normalize 8GB without OOM
- [ ] Judge labeling produces valid schema outputs
- [ ] Preference miner produces N pairs with dimension balance
- [ ] Eval harness runs subset and produces results JSON
- [ ] Tool permission gate blocks DESTRUCTIVE without approval
- [ ] z24 computation returns valid 24-vector
- [ ] Promotion flow: candidate → review → commit works
- [ ] Snapshot materialization matches folded state

---

## Non-Negotiables

- If something is missing from files, state assumption and proceed
- No hallucinated tool surface: if not found in attachments, mark unknown
- Prefer deterministic systems over "LLM vibes"
- No vague questions — make decisions and document them

---

## Output Format (Headings Exactly)

1. System Map
2. DB2 Schema v0.1
3. DB2 Reference Implementation
4. z24 Spec
5. 8GB-Safe Training Pipeline
6. Learning-Level Coherence Gate
7. Runtime Integration
8. Delta List vs Repo
9. Acceptance Tests

---

## First Action

Before writing anything, list:
- Which files successfully loaded
- Which are missing

Then proceed immediately.
