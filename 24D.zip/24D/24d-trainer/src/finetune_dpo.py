#!/usr/bin/env python3
"""
finetune_dpo.py - DPO fine-tuning using z24-derived preferences

Fine-tunes a base language model using Direct Preference Optimization (DPO)
with preferences derived from z24 scoring.

Author: 24D Trainer Pipeline
"""

import json
import logging
from pathlib import Path
from typing import Dict, List, Optional
import argparse
from datetime import datetime

import torch
from datasets import Dataset, load_dataset
from transformers import (
    AutoModelForCausalLM,
    AutoTokenizer,
    TrainingArguments,
    BitsAndBytesConfig
)
from peft import LoraConfig, get_peft_model, prepare_model_for_kbit_training
from trl import DPOTrainer, DPOConfig

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


def load_preference_data(data_path: Path) -> Dataset:
    """Load preference pairs into HuggingFace Dataset."""
    records = []
    
    with open(data_path, 'r') as f:
        for line in f:
            if line.strip():
                record = json.loads(line)
                records.append({
                    'prompt': record['prompt'],
                    'chosen': record['chosen'],
                    'rejected': record['rejected']
                })
    
    logger.info(f"Loaded {len(records)} preference pairs")
    return Dataset.from_list(records)


def create_model_and_tokenizer(
    model_name: str,
    use_4bit: bool = True,
    use_lora: bool = True,
    lora_config: Optional[Dict] = None
):
    """Load base model with optional quantization and LoRA."""
    
    # Quantization config
    if use_4bit:
        bnb_config = BitsAndBytesConfig(
            load_in_4bit=True,
            bnb_4bit_quant_type="nf4",
            bnb_4bit_compute_dtype=torch.bfloat16,
            bnb_4bit_use_double_quant=True
        )
    else:
        bnb_config = None
    
    # Load tokenizer
    tokenizer = AutoTokenizer.from_pretrained(model_name)
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token
    tokenizer.padding_side = "left"
    
    # Load model
    model = AutoModelForCausalLM.from_pretrained(
        model_name,
        quantization_config=bnb_config,
        device_map="auto",
        torch_dtype=torch.bfloat16,
        trust_remote_code=True
    )
    
    if use_4bit:
        model = prepare_model_for_kbit_training(model)
    
    # Apply LoRA
    if use_lora:
        lora_config = lora_config or {}
        peft_config = LoraConfig(
            r=lora_config.get('r', 16),
            lora_alpha=lora_config.get('alpha', 32),
            lora_dropout=lora_config.get('dropout', 0.05),
            target_modules=lora_config.get('target_modules', [
                "q_proj", "k_proj", "v_proj", "o_proj",
                "gate_proj", "up_proj", "down_proj"
            ]),
            bias="none",
            task_type="CAUSAL_LM"
        )
        model = get_peft_model(model, peft_config)
        model.print_trainable_parameters()
    
    return model, tokenizer


def main():
    parser = argparse.ArgumentParser(
        description='Fine-tune a model using DPO with z24 preferences'
    )
    parser.add_argument(
        'data',
        type=Path,
        help='Preference pairs JSONL from generate_preferences.py'
    )
    parser.add_argument(
        '-o', '--output',
        type=Path,
        default=Path('models/aligned'),
        help='Output directory for fine-tuned model'
    )
    parser.add_argument(
        '--base-model',
        default='meta-llama/Llama-3.1-8B-Instruct',
        help='Base model to fine-tune'
    )
    parser.add_argument(
        '--beta',
        type=float,
        default=0.1,
        help='DPO beta (KL penalty coefficient)'
    )
    parser.add_argument(
        '--batch-size',
        type=int,
        default=4
    )
    parser.add_argument(
        '--grad-accum',
        type=int,
        default=4,
        help='Gradient accumulation steps'
    )
    parser.add_argument(
        '--lr',
        type=float,
        default=5e-7,
        help='Learning rate'
    )
    parser.add_argument(
        '--epochs',
        type=int,
        default=3
    )
    parser.add_argument(
        '--max-length',
        type=int,
        default=2048
    )
    parser.add_argument(
        '--lora-r',
        type=int,
        default=16,
        help='LoRA rank'
    )
    parser.add_argument(
        '--lora-alpha',
        type=int,
        default=32,
        help='LoRA alpha'
    )
    parser.add_argument(
        '--no-lora',
        action='store_true',
        help='Disable LoRA (full fine-tuning)'
    )
    parser.add_argument(
        '--no-4bit',
        action='store_true',
        help='Disable 4-bit quantization'
    )
    parser.add_argument(
        '--eval-split',
        type=float,
        default=0.05,
        help='Evaluation split ratio'
    )
    
    args = parser.parse_args()
    
    # Load data
    dataset = load_preference_data(args.data)
    
    # Split into train/eval
    split = dataset.train_test_split(test_size=args.eval_split)
    train_dataset = split['train']
    eval_dataset = split['test']
    
    logger.info(f"Train: {len(train_dataset)}, Eval: {len(eval_dataset)}")
    
    # Load model
    lora_config = {
        'r': args.lora_r,
        'alpha': args.lora_alpha,
        'dropout': 0.05
    }
    
    model, tokenizer = create_model_and_tokenizer(
        args.base_model,
        use_4bit=not args.no_4bit,
        use_lora=not args.no_lora,
        lora_config=lora_config
    )
    
    # Reference model for DPO
    ref_model = None  # DPOTrainer will create one
    
    # Output directory with timestamp
    output_dir = args.output / f"dpo_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
    output_dir.mkdir(parents=True, exist_ok=True)
    
    # DPO Config
    dpo_config = DPOConfig(
        beta=args.beta,
        loss_type="sigmoid",
        output_dir=str(output_dir),
        num_train_epochs=args.epochs,
        per_device_train_batch_size=args.batch_size,
        per_device_eval_batch_size=args.batch_size,
        gradient_accumulation_steps=args.grad_accum,
        learning_rate=args.lr,
        weight_decay=0.0,
        warmup_ratio=0.1,
        lr_scheduler_type="cosine",
        logging_steps=10,
        eval_strategy="steps",
        eval_steps=100,
        save_strategy="steps",
        save_steps=500,
        save_total_limit=3,
        bf16=True,
        gradient_checkpointing=True,
        max_length=args.max_length,
        max_prompt_length=args.max_length // 2,
        remove_unused_columns=False,
        report_to="none"  # Disable wandb etc
    )
    
    # Create trainer
    trainer = DPOTrainer(
        model=model,
        ref_model=ref_model,
        args=dpo_config,
        train_dataset=train_dataset,
        eval_dataset=eval_dataset,
        tokenizer=tokenizer
    )
    
    # Train
    logger.info("Starting DPO training...")
    trainer.train()
    
    # Save final model
    logger.info(f"Saving model to {output_dir}")
    trainer.save_model(str(output_dir / "final"))
    tokenizer.save_pretrained(str(output_dir / "final"))
    
    # Save training config
    config = {
        'base_model': args.base_model,
        'beta': args.beta,
        'batch_size': args.batch_size,
        'gradient_accumulation_steps': args.grad_accum,
        'learning_rate': args.lr,
        'epochs': args.epochs,
        'max_length': args.max_length,
        'lora_r': args.lora_r,
        'lora_alpha': args.lora_alpha,
        'use_lora': not args.no_lora,
        'use_4bit': not args.no_4bit,
        'train_samples': len(train_dataset),
        'eval_samples': len(eval_dataset),
        'timestamp': datetime.now().isoformat()
    }
    
    with open(output_dir / "training_config.json", 'w') as f:
        json.dump(config, f, indent=2)
    
    logger.info("Training complete!")
    logger.info(f"Model saved to: {output_dir / 'final'}")


if __name__ == '__main__':
    main()
