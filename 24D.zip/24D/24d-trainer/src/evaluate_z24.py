#!/usr/bin/env python3
"""
evaluate_z24.py - Evaluation suite for z24-aligned models

Measures how well the fine-tuned model scores on z24 dimensions compared
to the base model.

Author: 24D Trainer Pipeline
"""

import json
import logging
from pathlib import Path
from typing import Dict, List, Tuple, Optional
import argparse
from datetime import datetime
from collections import defaultdict

import torch
import numpy as np
from tqdm import tqdm
from transformers import AutoModelForCausalLM, AutoTokenizer
from scipy import stats

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


class Z24Evaluator:
    """Evaluates model outputs on z24 dimensions."""
    
    def __init__(
        self,
        encoder_path: Optional[Path] = None,
        judge_model: str = "claude-opus-4-6",
        use_encoder: bool = True
    ):
        self.use_encoder = use_encoder and encoder_path is not None
        
        if self.use_encoder:
            # Load fast encoder
            from train_z24_encoder import load_model
            self.encoder, self.encoder_tokenizer = load_model(encoder_path)
            self.device = next(self.encoder.parameters()).device
            logger.info(f"Loaded z24 encoder from {encoder_path}")
        else:
            # Use LLM judge
            from label_z24 import AnthropicJudge, DimensionConfig
            self.judge = AnthropicJudge(judge_model)
            self.dimensions = DimensionConfig(Path('config/dimensions.yaml'))
            self.rubric = self.dimensions.build_rubric_prompt()
            logger.info(f"Using LLM judge: {judge_model}")
    
    def score_text(self, text: str) -> List[float]:
        """Score a text window on z24."""
        if self.use_encoder:
            return self.encoder.predict(text, self.encoder_tokenizer, str(self.device)).tolist()
        else:
            result = self.judge.score(text, self.rubric)
            return result['z24'] if result else [0.5] * 24
    
    def score_response(self, prompt: str, response: str) -> List[float]:
        """Score a prompt-response pair."""
        window_text = f"[USER]: {prompt}\n\n[ASSISTANT]: {response}"
        return self.score_text(window_text)


class ModelComparison:
    """Compare base and fine-tuned models."""
    
    def __init__(
        self,
        base_model_path: str,
        finetuned_model_path: str,
        evaluator: Z24Evaluator,
        device: str = 'auto'
    ):
        self.evaluator = evaluator
        
        if device == 'auto':
            self.device = 'cuda' if torch.cuda.is_available() else 'cpu'
        else:
            self.device = device
        
        # Load models
        logger.info(f"Loading base model: {base_model_path}")
        self.base_tokenizer = AutoTokenizer.from_pretrained(base_model_path)
        self.base_model = AutoModelForCausalLM.from_pretrained(
            base_model_path,
            torch_dtype=torch.bfloat16,
            device_map="auto"
        )
        
        logger.info(f"Loading fine-tuned model: {finetuned_model_path}")
        self.ft_tokenizer = AutoTokenizer.from_pretrained(finetuned_model_path)
        self.ft_model = AutoModelForCausalLM.from_pretrained(
            finetuned_model_path,
            torch_dtype=torch.bfloat16,
            device_map="auto"
        )
        
        # Ensure pad token
        for tok in [self.base_tokenizer, self.ft_tokenizer]:
            if tok.pad_token is None:
                tok.pad_token = tok.eos_token
    
    def generate_response(self, model, tokenizer, prompt: str, max_new_tokens: int = 512) -> str:
        """Generate a response from a model."""
        inputs = tokenizer(prompt, return_tensors="pt").to(model.device)
        
        with torch.no_grad():
            outputs = model.generate(
                **inputs,
                max_new_tokens=max_new_tokens,
                do_sample=True,
                temperature=0.7,
                top_p=0.9,
                pad_token_id=tokenizer.pad_token_id
            )
        
        response = tokenizer.decode(outputs[0][inputs['input_ids'].shape[1]:], skip_special_tokens=True)
        return response.strip()
    
    def compare_on_prompts(self, prompts: List[str]) -> Dict:
        """Compare models on a list of prompts."""
        results = {
            'base': {'z24_scores': [], 'responses': []},
            'finetuned': {'z24_scores': [], 'responses': []},
            'per_prompt': []
        }
        
        for prompt in tqdm(prompts, desc="Comparing models"):
            # Generate responses
            base_response = self.generate_response(self.base_model, self.base_tokenizer, prompt)
            ft_response = self.generate_response(self.ft_model, self.ft_tokenizer, prompt)
            
            # Score responses
            base_z24 = self.evaluator.score_response(prompt, base_response)
            ft_z24 = self.evaluator.score_response(prompt, ft_response)
            
            results['base']['z24_scores'].append(base_z24)
            results['base']['responses'].append(base_response)
            results['finetuned']['z24_scores'].append(ft_z24)
            results['finetuned']['responses'].append(ft_response)
            
            results['per_prompt'].append({
                'prompt': prompt[:200] + '...' if len(prompt) > 200 else prompt,
                'base_z24_mean': np.mean(base_z24),
                'ft_z24_mean': np.mean(ft_z24),
                'improvement': np.mean(ft_z24) - np.mean(base_z24)
            })
        
        return results


def compute_statistics(results: Dict) -> Dict:
    """Compute statistical analysis of results."""
    base_scores = np.array(results['base']['z24_scores'])
    ft_scores = np.array(results['finetuned']['z24_scores'])
    
    stats_results = {
        'overall': {
            'base_mean': float(np.mean(base_scores)),
            'base_std': float(np.std(base_scores)),
            'ft_mean': float(np.mean(ft_scores)),
            'ft_std': float(np.std(ft_scores)),
            'improvement': float(np.mean(ft_scores) - np.mean(base_scores)),
            'improvement_pct': float((np.mean(ft_scores) - np.mean(base_scores)) / np.mean(base_scores) * 100)
        },
        'per_dimension': {},
        'statistical_tests': {}
    }
    
    # Per-dimension analysis
    dim_names = [
        "Truth", "Honesty", "Integrity", "Pride", "Freedom",
        "Recursive", "Fractal", "Mirrored", "Loop", "Connected",
        "Problem Framing", "Evidence Discipline", "Hypothesis Generation",
        "Falsification Effort", "Implementation Readiness", "Decisiveness",
        "Resource Efficiency", "Security Posture", "Error Sensitivity",
        "Autonomy Level", "Context Management", "Instruction Fidelity",
        "Tool Discipline", "Closure Rate"
    ]
    
    for i, name in enumerate(dim_names):
        base_dim = base_scores[:, i]
        ft_dim = ft_scores[:, i]
        
        # Paired t-test
        t_stat, p_value = stats.ttest_rel(ft_dim, base_dim)
        
        stats_results['per_dimension'][f"D{i+1}_{name}"] = {
            'base_mean': float(np.mean(base_dim)),
            'ft_mean': float(np.mean(ft_dim)),
            'improvement': float(np.mean(ft_dim) - np.mean(base_dim)),
            't_statistic': float(t_stat),
            'p_value': float(p_value),
            'significant': p_value < 0.05
        }
    
    # Overall statistical test
    base_means = np.mean(base_scores, axis=1)
    ft_means = np.mean(ft_scores, axis=1)
    t_stat, p_value = stats.ttest_rel(ft_means, base_means)
    
    stats_results['statistical_tests']['paired_ttest'] = {
        't_statistic': float(t_stat),
        'p_value': float(p_value),
        'significant': p_value < 0.05
    }
    
    # Wilcoxon signed-rank test
    try:
        w_stat, w_pvalue = stats.wilcoxon(ft_means, base_means)
        stats_results['statistical_tests']['wilcoxon'] = {
            'statistic': float(w_stat),
            'p_value': float(w_pvalue),
            'significant': w_pvalue < 0.05
        }
    except:
        pass
    
    return stats_results


def generate_report(results: Dict, stats_results: Dict, output_path: Path):
    """Generate markdown evaluation report."""
    report = []
    report.append("# z24 Evaluation Report")
    report.append(f"\nGenerated: {datetime.now().isoformat()}\n")
    
    # Overall results
    report.append("## Overall Results\n")
    report.append(f"| Metric | Base Model | Fine-tuned | Improvement |")
    report.append(f"|--------|------------|------------|-------------|")
    
    overall = stats_results['overall']
    report.append(f"| Mean z24 | {overall['base_mean']:.4f} | {overall['ft_mean']:.4f} | {overall['improvement']:+.4f} ({overall['improvement_pct']:+.1f}%) |")
    report.append(f"| Std Dev | {overall['base_std']:.4f} | {overall['ft_std']:.4f} | - |")
    
    # Statistical significance
    report.append("\n## Statistical Significance\n")
    for test_name, test_results in stats_results['statistical_tests'].items():
        sig = "✅ Significant" if test_results['significant'] else "❌ Not Significant"
        report.append(f"- **{test_name}**: p={test_results['p_value']:.4f} {sig}")
    
    # Per-dimension breakdown
    report.append("\n## Per-Dimension Analysis\n")
    report.append("| Dimension | Base | Fine-tuned | Δ | Significant |")
    report.append("|-----------|------|------------|---|-------------|")
    
    for dim_name, dim_stats in stats_results['per_dimension'].items():
        sig = "✅" if dim_stats['significant'] else ""
        report.append(f"| {dim_name} | {dim_stats['base_mean']:.3f} | {dim_stats['ft_mean']:.3f} | {dim_stats['improvement']:+.3f} | {sig} |")
    
    # Top improvements
    report.append("\n## Top Improvements\n")
    sorted_dims = sorted(
        stats_results['per_dimension'].items(),
        key=lambda x: x[1]['improvement'],
        reverse=True
    )
    
    for dim_name, dim_stats in sorted_dims[:5]:
        report.append(f"1. **{dim_name}**: +{dim_stats['improvement']:.3f}")
    
    # Potential regressions
    report.append("\n## Potential Regressions\n")
    regressions = [(k, v) for k, v in sorted_dims if v['improvement'] < 0]
    if regressions:
        for dim_name, dim_stats in regressions:
            report.append(f"- **{dim_name}**: {dim_stats['improvement']:.3f}")
    else:
        report.append("No dimensions showed regression.")
    
    # Write report
    with open(output_path, 'w') as f:
        f.write('\n'.join(report))
    
    logger.info(f"Report saved to {output_path}")


def load_test_prompts(data_path: Path, n_samples: int = 100) -> List[str]:
    """Load test prompts from preference data."""
    prompts = []
    
    with open(data_path, 'r') as f:
        for line in f:
            if line.strip():
                record = json.loads(line)
                prompts.append(record['prompt'])
                if len(prompts) >= n_samples:
                    break
    
    return prompts


def main():
    parser = argparse.ArgumentParser(
        description='Evaluate z24 alignment of fine-tuned model'
    )
    parser.add_argument(
        '--base-model',
        required=True,
        help='Path to base model'
    )
    parser.add_argument(
        '--finetuned-model',
        required=True,
        help='Path to fine-tuned model'
    )
    parser.add_argument(
        '--test-data',
        type=Path,
        required=True,
        help='Preference data JSONL to sample prompts from'
    )
    parser.add_argument(
        '--encoder',
        type=Path,
        default=None,
        help='Path to trained z24 encoder (for fast scoring)'
    )
    parser.add_argument(
        '--n-samples',
        type=int,
        default=100,
        help='Number of prompts to evaluate'
    )
    parser.add_argument(
        '-o', '--output',
        type=Path,
        default=Path('evaluation_report.md'),
        help='Output report path'
    )
    
    args = parser.parse_args()
    
    # Create evaluator
    evaluator = Z24Evaluator(
        encoder_path=args.encoder,
        use_encoder=args.encoder is not None
    )
    
    # Load test prompts
    prompts = load_test_prompts(args.test_data, args.n_samples)
    logger.info(f"Loaded {len(prompts)} test prompts")
    
    # Compare models
    comparison = ModelComparison(
        args.base_model,
        args.finetuned_model,
        evaluator
    )
    
    results = comparison.compare_on_prompts(prompts)
    
    # Compute statistics
    stats_results = compute_statistics(results)
    
    # Generate report
    generate_report(results, stats_results, args.output)
    
    # Also save raw results
    raw_output = args.output.with_suffix('.json')
    with open(raw_output, 'w') as f:
        json.dump({
            'stats': stats_results,
            'per_prompt': results['per_prompt']
        }, f, indent=2)
    
    logger.info(f"Raw results saved to {raw_output}")
    
    # Print summary
    print("\n" + "=" * 60)
    print("EVALUATION SUMMARY")
    print("=" * 60)
    print(f"Base Model Mean z24:      {stats_results['overall']['base_mean']:.4f}")
    print(f"Fine-tuned Model Mean z24: {stats_results['overall']['ft_mean']:.4f}")
    print(f"Improvement:              {stats_results['overall']['improvement']:+.4f} ({stats_results['overall']['improvement_pct']:+.1f}%)")
    print(f"Statistically Significant: {'Yes' if stats_results['statistical_tests']['paired_ttest']['significant'] else 'No'}")
    print("=" * 60)


if __name__ == '__main__':
    main()
