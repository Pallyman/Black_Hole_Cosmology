#!/usr/bin/env python3
"""
train_z24_encoder.py - Train a fast z24 encoder from labeled data

Distills the expensive LLM judge into a lightweight sentence transformer
that can score z24 in milliseconds.

Author: 24D Trainer Pipeline
"""

import json
import logging
from pathlib import Path
from typing import List, Dict, Tuple, Optional
import argparse
from datetime import datetime

import torch
import torch.nn as nn
from torch.utils.data import Dataset, DataLoader, random_split
from torch.optim import AdamW
from torch.optim.lr_scheduler import CosineAnnealingLR
from transformers import AutoTokenizer, AutoModel, get_linear_schedule_with_warmup
from tqdm import tqdm
import numpy as np

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


class Z24Dataset(Dataset):
    """Dataset for z24 encoder training."""
    
    def __init__(self, data_path: Path, tokenizer, max_length: int = 512):
        self.tokenizer = tokenizer
        self.max_length = max_length
        self.samples = []
        
        logger.info(f"Loading data from {data_path}")
        with open(data_path, 'r') as f:
            for line in f:
                if line.strip():
                    record = json.loads(line)
                    self.samples.append({
                        'text': record['window_text'],
                        'z24': record['z24'],
                        'id': record['id']
                    })
        
        logger.info(f"Loaded {len(self.samples)} samples")
    
    def __len__(self) -> int:
        return len(self.samples)
    
    def __getitem__(self, idx: int) -> Dict:
        sample = self.samples[idx]
        
        # Tokenize
        encoding = self.tokenizer(
            sample['text'],
            truncation=True,
            max_length=self.max_length,
            padding='max_length',
            return_tensors='pt'
        )
        
        return {
            'input_ids': encoding['input_ids'].squeeze(0),
            'attention_mask': encoding['attention_mask'].squeeze(0),
            'z24': torch.tensor(sample['z24'], dtype=torch.float32),
            'id': sample['id']
        }


class Z24Encoder(nn.Module):
    """
    z24 encoder model.
    
    Architecture:
    - Sentence transformer base (frozen or fine-tuned)
    - Optional hidden layers
    - 24-dim regression head
    """
    
    def __init__(
        self,
        base_model: str = "sentence-transformers/all-MiniLM-L6-v2",
        hidden_dims: List[int] = None,
        dropout: float = 0.1,
        freeze_base: bool = False
    ):
        super().__init__()
        
        # Load base encoder
        self.encoder = AutoModel.from_pretrained(base_model)
        encoder_dim = self.encoder.config.hidden_size
        
        if freeze_base:
            for param in self.encoder.parameters():
                param.requires_grad = False
        
        # Build head
        layers = []
        prev_dim = encoder_dim
        
        if hidden_dims:
            for dim in hidden_dims:
                layers.extend([
                    nn.Linear(prev_dim, dim),
                    nn.ReLU(),
                    nn.Dropout(dropout)
                ])
                prev_dim = dim
        
        layers.append(nn.Linear(prev_dim, 24))
        layers.append(nn.Sigmoid())  # Output 0-1
        
        self.head = nn.Sequential(*layers)
    
    def forward(self, input_ids, attention_mask) -> torch.Tensor:
        # Get encoder output
        outputs = self.encoder(input_ids=input_ids, attention_mask=attention_mask)
        
        # Mean pooling
        token_embeddings = outputs.last_hidden_state
        input_mask_expanded = attention_mask.unsqueeze(-1).expand(token_embeddings.size()).float()
        pooled = torch.sum(token_embeddings * input_mask_expanded, 1) / torch.clamp(input_mask_expanded.sum(1), min=1e-9)
        
        # Predict z24
        z24 = self.head(pooled)
        return z24
    
    def predict(self, text: str, tokenizer, device: str = 'cpu') -> np.ndarray:
        """Convenience method for single inference."""
        self.eval()
        with torch.no_grad():
            encoding = tokenizer(
                text,
                truncation=True,
                max_length=512,
                padding='max_length',
                return_tensors='pt'
            )
            input_ids = encoding['input_ids'].to(device)
            attention_mask = encoding['attention_mask'].to(device)
            z24 = self(input_ids, attention_mask)
            return z24.cpu().numpy()[0]


class Z24Trainer:
    """Training pipeline for z24 encoder."""
    
    def __init__(
        self,
        model: Z24Encoder,
        tokenizer,
        config: Dict,
        output_dir: Path
    ):
        self.model = model
        self.tokenizer = tokenizer
        self.config = config
        self.output_dir = output_dir
        self.output_dir.mkdir(parents=True, exist_ok=True)
        
        # Setup device
        if config.get('device') == 'auto':
            self.device = 'cuda' if torch.cuda.is_available() else 'cpu'
        else:
            self.device = config.get('device', 'cpu')
        
        self.model.to(self.device)
        logger.info(f"Using device: {self.device}")
        
        # Loss function
        loss_type = config.get('loss', 'mse')
        if loss_type == 'mse':
            self.criterion = nn.MSELoss()
        elif loss_type == 'huber':
            self.criterion = nn.HuberLoss()
        else:
            self.criterion = nn.MSELoss()
        
        # Tracking
        self.best_val_loss = float('inf')
        self.patience_counter = 0
        self.history = {
            'train_loss': [],
            'val_loss': [],
            'per_dim_mse': []
        }
    
    def train(self, train_loader: DataLoader, val_loader: DataLoader):
        """Main training loop."""
        config = self.config
        
        # Optimizer
        optimizer = AdamW(
            self.model.parameters(),
            lr=config.get('learning_rate', 2e-5),
            weight_decay=config.get('weight_decay', 0.01)
        )
        
        # Scheduler
        total_steps = len(train_loader) * config.get('epochs', 10)
        warmup_steps = int(total_steps * config.get('warmup_ratio', 0.1))
        scheduler = get_linear_schedule_with_warmup(
            optimizer,
            num_warmup_steps=warmup_steps,
            num_training_steps=total_steps
        )
        
        # Training
        epochs = config.get('epochs', 10)
        patience = config.get('early_stopping_patience', 3)
        
        for epoch in range(epochs):
            # Train epoch
            train_loss = self._train_epoch(train_loader, optimizer, scheduler, epoch)
            self.history['train_loss'].append(train_loss)
            
            # Validate
            val_loss, per_dim_mse = self._validate(val_loader)
            self.history['val_loss'].append(val_loss)
            self.history['per_dim_mse'].append(per_dim_mse)
            
            logger.info(f"Epoch {epoch+1}/{epochs} - Train Loss: {train_loss:.4f}, Val Loss: {val_loss:.4f}")
            
            # Early stopping check
            if val_loss < self.best_val_loss - config.get('early_stopping_min_delta', 0.001):
                self.best_val_loss = val_loss
                self.patience_counter = 0
                self._save_checkpoint(epoch, is_best=True)
            else:
                self.patience_counter += 1
                if self.patience_counter >= patience:
                    logger.info(f"Early stopping at epoch {epoch+1}")
                    break
            
            # Regular checkpoint
            if (epoch + 1) % config.get('save_frequency', 1) == 0:
                self._save_checkpoint(epoch)
        
        # Save final model
        self._save_final()
        self._save_history()
    
    def _train_epoch(self, loader: DataLoader, optimizer, scheduler, epoch: int) -> float:
        """Single training epoch."""
        self.model.train()
        total_loss = 0
        
        pbar = tqdm(loader, desc=f"Epoch {epoch+1} Training")
        for batch in pbar:
            input_ids = batch['input_ids'].to(self.device)
            attention_mask = batch['attention_mask'].to(self.device)
            targets = batch['z24'].to(self.device)
            
            optimizer.zero_grad()
            predictions = self.model(input_ids, attention_mask)
            loss = self.criterion(predictions, targets)
            
            loss.backward()
            torch.nn.utils.clip_grad_norm_(self.model.parameters(), 1.0)
            optimizer.step()
            scheduler.step()
            
            total_loss += loss.item()
            pbar.set_postfix({'loss': loss.item()})
        
        return total_loss / len(loader)
    
    def _validate(self, loader: DataLoader) -> Tuple[float, List[float]]:
        """Validation pass."""
        self.model.eval()
        total_loss = 0
        all_preds = []
        all_targets = []
        
        with torch.no_grad():
            for batch in tqdm(loader, desc="Validating"):
                input_ids = batch['input_ids'].to(self.device)
                attention_mask = batch['attention_mask'].to(self.device)
                targets = batch['z24'].to(self.device)
                
                predictions = self.model(input_ids, attention_mask)
                loss = self.criterion(predictions, targets)
                
                total_loss += loss.item()
                all_preds.append(predictions.cpu())
                all_targets.append(targets.cpu())
        
        # Per-dimension MSE
        all_preds = torch.cat(all_preds, dim=0)
        all_targets = torch.cat(all_targets, dim=0)
        per_dim_mse = ((all_preds - all_targets) ** 2).mean(dim=0).tolist()
        
        return total_loss / len(loader), per_dim_mse
    
    def _save_checkpoint(self, epoch: int, is_best: bool = False):
        """Save model checkpoint."""
        checkpoint = {
            'epoch': epoch,
            'model_state_dict': self.model.state_dict(),
            'config': self.config,
            'best_val_loss': self.best_val_loss
        }
        
        if is_best:
            path = self.output_dir / 'best_model.pt'
        else:
            path = self.output_dir / f'checkpoint_epoch_{epoch+1}.pt'
        
        torch.save(checkpoint, path)
        logger.info(f"Saved checkpoint: {path}")
    
    def _save_final(self):
        """Save final model in HuggingFace format."""
        final_dir = self.output_dir / 'final'
        final_dir.mkdir(exist_ok=True)
        
        # Save encoder
        self.model.encoder.save_pretrained(final_dir / 'encoder')
        self.tokenizer.save_pretrained(final_dir / 'encoder')
        
        # Save head separately
        torch.save(self.model.head.state_dict(), final_dir / 'head.pt')
        
        # Save full model
        torch.save(self.model.state_dict(), final_dir / 'full_model.pt')
        
        # Save config
        with open(final_dir / 'config.json', 'w') as f:
            json.dump(self.config, f, indent=2)
        
        logger.info(f"Saved final model to {final_dir}")
    
    def _save_history(self):
        """Save training history."""
        with open(self.output_dir / 'history.json', 'w') as f:
            json.dump(self.history, f, indent=2)


def load_model(model_dir: Path, device: str = 'cpu') -> Tuple[Z24Encoder, AutoTokenizer]:
    """Load a trained z24 encoder."""
    final_dir = model_dir / 'final'
    
    # Load config
    with open(final_dir / 'config.json', 'r') as f:
        config = json.load(f)
    
    # Load tokenizer
    tokenizer = AutoTokenizer.from_pretrained(final_dir / 'encoder')
    
    # Create model
    model = Z24Encoder(
        base_model=str(final_dir / 'encoder'),
        hidden_dims=config.get('hidden_dims'),
        dropout=config.get('dropout', 0.1)
    )
    
    # Load weights
    model.load_state_dict(torch.load(final_dir / 'full_model.pt', map_location=device))
    model.to(device)
    model.eval()
    
    return model, tokenizer


def main():
    parser = argparse.ArgumentParser(
        description='Train z24 encoder from labeled data'
    )
    parser.add_argument(
        'input',
        type=Path,
        help='Labeled JSONL file from label_z24.py'
    )
    parser.add_argument(
        '-o', '--output',
        type=Path,
        default=Path('models/z24_encoder'),
        help='Output directory for trained model'
    )
    parser.add_argument(
        '--base-model',
        default='sentence-transformers/all-MiniLM-L6-v2',
        help='Base sentence transformer model'
    )
    parser.add_argument(
        '--hidden-dims',
        type=int,
        nargs='+',
        default=[256, 128],
        help='Hidden layer dimensions'
    )
    parser.add_argument(
        '--batch-size',
        type=int,
        default=32
    )
    parser.add_argument(
        '--epochs',
        type=int,
        default=10
    )
    parser.add_argument(
        '--lr',
        type=float,
        default=2e-5,
        help='Learning rate'
    )
    parser.add_argument(
        '--val-split',
        type=float,
        default=0.1
    )
    parser.add_argument(
        '--device',
        default='auto',
        choices=['auto', 'cuda', 'cpu']
    )
    parser.add_argument(
        '--seed',
        type=int,
        default=42
    )
    
    args = parser.parse_args()
    
    # Set seed
    torch.manual_seed(args.seed)
    np.random.seed(args.seed)
    
    # Load tokenizer
    tokenizer = AutoTokenizer.from_pretrained(args.base_model)
    
    # Load dataset
    full_dataset = Z24Dataset(args.input, tokenizer)
    
    # Split
    val_size = int(len(full_dataset) * args.val_split)
    train_size = len(full_dataset) - val_size
    train_dataset, val_dataset = random_split(full_dataset, [train_size, val_size])
    
    logger.info(f"Train: {len(train_dataset)}, Val: {len(val_dataset)}")
    
    # Create loaders
    train_loader = DataLoader(
        train_dataset,
        batch_size=args.batch_size,
        shuffle=True,
        num_workers=4
    )
    val_loader = DataLoader(
        val_dataset,
        batch_size=args.batch_size,
        shuffle=False,
        num_workers=4
    )
    
    # Create model
    model = Z24Encoder(
        base_model=args.base_model,
        hidden_dims=args.hidden_dims,
        dropout=0.1
    )
    
    # Config
    config = {
        'base_model': args.base_model,
        'hidden_dims': args.hidden_dims,
        'dropout': 0.1,
        'batch_size': args.batch_size,
        'epochs': args.epochs,
        'learning_rate': args.lr,
        'weight_decay': 0.01,
        'warmup_ratio': 0.1,
        'val_split': args.val_split,
        'early_stopping_patience': 3,
        'early_stopping_min_delta': 0.001,
        'save_frequency': 1,
        'device': args.device,
        'seed': args.seed,
        'loss': 'mse'
    }
    
    # Train
    trainer = Z24Trainer(model, tokenizer, config, args.output)
    trainer.train(train_loader, val_loader)
    
    logger.info("Training complete!")


if __name__ == '__main__':
    main()
