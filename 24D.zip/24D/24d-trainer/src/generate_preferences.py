#!/usr/bin/env python3
"""
generate_preferences.py - Generate DPO preference pairs from z24 labels

Creates training data for DPO fine-tuning by pairing responses with different
z24 scores - higher z24 becomes "chosen", lower becomes "rejected".

Author: 24D Trainer Pipeline
"""

import json
import logging
from pathlib import Path
from typing import List, Dict, Tuple, Optional
from dataclasses import dataclass, asdict
import argparse
from collections import defaultdict
import random
from tqdm import tqdm
import numpy as np

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


@dataclass
class PreferencePair:
    """A single preference pair for DPO training."""
    prompt: str
    chosen: str
    rejected: str
    z24_chosen: List[float]
    z24_rejected: List[float]
    z24_delta: float  # Mean difference
    meta: Dict
    
    def to_dict(self) -> Dict:
        return asdict(self)


class PreferenceGenerator:
    """Generates preference pairs from z24-labeled data."""
    
    def __init__(
        self,
        min_delta: float = 0.1,
        strategy: str = 'cross_conversation',
        max_pairs: int = 100000,
        seed: int = 42
    ):
        self.min_delta = min_delta
        self.strategy = strategy
        self.max_pairs = max_pairs
        random.seed(seed)
        np.random.seed(seed)
        
        self.stats = {
            'total_labels': 0,
            'pairs_generated': 0,
            'pairs_skipped_low_delta': 0
        }
    
    def load_labels(self, input_path: Path) -> List[Dict]:
        """Load z24 labeled data."""
        labels = []
        with open(input_path, 'r') as f:
            for line in f:
                if line.strip():
                    labels.append(json.loads(line))
        self.stats['total_labels'] = len(labels)
        logger.info(f"Loaded {len(labels)} labeled windows")
        return labels
    
    def extract_prompt_response(self, window_text: str) -> Tuple[str, str]:
        """Extract prompt and final response from window text."""
        # Split by role markers
        parts = window_text.split('\n\n')
        
        # Find last user message as prompt, last assistant as response
        prompt_parts = []
        response = ""
        
        for part in parts:
            if part.startswith('[USER]:'):
                prompt_parts.append(part[7:].strip())
            elif part.startswith('[ASSISTANT]:'):
                response = part[12:].strip()
        
        # Use all user messages as context + last user message as prompt
        prompt = '\n'.join(prompt_parts) if prompt_parts else ""
        
        return prompt, response
    
    def compute_z24_mean(self, z24: List[float]) -> float:
        """Compute mean z24 score."""
        return sum(z24) / len(z24)
    
    def generate_cross_conversation(self, labels: List[Dict]) -> List[PreferencePair]:
        """Generate pairs by comparing responses across conversations."""
        pairs = []
        
        # Group by approximate prompt similarity (using first 100 chars as key)
        prompt_groups = defaultdict(list)
        
        for label in labels:
            prompt, response = self.extract_prompt_response(label['window_text'])
            if prompt and response:
                # Simple grouping by prompt prefix
                key = prompt[:100].lower().strip()
                prompt_groups[key].append({
                    'prompt': prompt,
                    'response': response,
                    'z24': label['z24'],
                    'z24_mean': self.compute_z24_mean(label['z24']),
                    'id': label['id']
                })
        
        # Generate pairs within each group
        for key, group in tqdm(prompt_groups.items(), desc="Generating pairs"):
            if len(group) < 2:
                continue
            
            # Sort by z24 mean
            group.sort(key=lambda x: x['z24_mean'], reverse=True)
            
            # Pair high with low
            for i in range(len(group)):
                for j in range(i + 1, len(group)):
                    if len(pairs) >= self.max_pairs:
                        break
                    
                    high = group[i]
                    low = group[j]
                    delta = high['z24_mean'] - low['z24_mean']
                    
                    if delta < self.min_delta:
                        self.stats['pairs_skipped_low_delta'] += 1
                        continue
                    
                    pair = PreferencePair(
                        prompt=high['prompt'],
                        chosen=high['response'],
                        rejected=low['response'],
                        z24_chosen=high['z24'],
                        z24_rejected=low['z24'],
                        z24_delta=delta,
                        meta={
                            'chosen_id': high['id'],
                            'rejected_id': low['id'],
                            'strategy': 'cross_conversation'
                        }
                    )
                    pairs.append(pair)
                    self.stats['pairs_generated'] += 1
                
                if len(pairs) >= self.max_pairs:
                    break
        
        return pairs
    
    def generate_within_conversation(self, labels: List[Dict]) -> List[PreferencePair]:
        """Generate pairs from different turns within same conversation."""
        pairs = []
        
        # Group by conversation
        conv_groups = defaultdict(list)
        for label in labels:
            conv_groups[label['conversation_id']].append(label)
        
        for conv_id, conv_labels in tqdm(conv_groups.items(), desc="Processing conversations"):
            if len(conv_labels) < 2:
                continue
            
            # Sort by z24 mean
            for label in conv_labels:
                label['_z24_mean'] = self.compute_z24_mean(label['z24'])
            
            conv_labels.sort(key=lambda x: x['_z24_mean'], reverse=True)
            
            # Pair high with low within conversation
            for i in range(min(3, len(conv_labels))):  # Top 3
                for j in range(max(0, len(conv_labels) - 3), len(conv_labels)):  # Bottom 3
                    if i >= j:
                        continue
                    if len(pairs) >= self.max_pairs:
                        break
                    
                    high = conv_labels[i]
                    low = conv_labels[j]
                    delta = high['_z24_mean'] - low['_z24_mean']
                    
                    if delta < self.min_delta:
                        self.stats['pairs_skipped_low_delta'] += 1
                        continue
                    
                    prompt_h, response_h = self.extract_prompt_response(high['window_text'])
                    prompt_l, response_l = self.extract_prompt_response(low['window_text'])
                    
                    if not response_h or not response_l:
                        continue
                    
                    # Use higher-scored prompt as the canonical prompt
                    pair = PreferencePair(
                        prompt=prompt_h,
                        chosen=response_h,
                        rejected=response_l,
                        z24_chosen=high['z24'],
                        z24_rejected=low['z24'],
                        z24_delta=delta,
                        meta={
                            'chosen_id': high['id'],
                            'rejected_id': low['id'],
                            'conversation_id': conv_id,
                            'strategy': 'within_conversation'
                        }
                    )
                    pairs.append(pair)
                    self.stats['pairs_generated'] += 1
        
        return pairs
    
    def generate_random_pairs(self, labels: List[Dict]) -> List[PreferencePair]:
        """Generate random pairs sorted by z24."""
        pairs = []
        
        # Compute z24 means
        for label in labels:
            label['_z24_mean'] = self.compute_z24_mean(label['z24'])
        
        # Sort all by z24
        sorted_labels = sorted(labels, key=lambda x: x['_z24_mean'], reverse=True)
        
        # Take top and bottom percentiles
        n = len(sorted_labels)
        top_20 = sorted_labels[:int(n * 0.2)]
        bottom_20 = sorted_labels[int(n * 0.8):]
        
        # Random pairing
        random.shuffle(top_20)
        random.shuffle(bottom_20)
        
        for high, low in zip(top_20, bottom_20):
            if len(pairs) >= self.max_pairs:
                break
            
            delta = high['_z24_mean'] - low['_z24_mean']
            if delta < self.min_delta:
                self.stats['pairs_skipped_low_delta'] += 1
                continue
            
            prompt_h, response_h = self.extract_prompt_response(high['window_text'])
            prompt_l, response_l = self.extract_prompt_response(low['window_text'])
            
            if not response_h or not response_l:
                continue
            
            pair = PreferencePair(
                prompt=prompt_h,
                chosen=response_h,
                rejected=response_l,
                z24_chosen=high['z24'],
                z24_rejected=low['z24'],
                z24_delta=delta,
                meta={
                    'chosen_id': high['id'],
                    'rejected_id': low['id'],
                    'strategy': 'random'
                }
            )
            pairs.append(pair)
            self.stats['pairs_generated'] += 1
        
        return pairs
    
    def generate(self, input_path: Path, output_path: Path):
        """Main generation pipeline."""
        labels = self.load_labels(input_path)
        
        if self.strategy == 'cross_conversation':
            pairs = self.generate_cross_conversation(labels)
        elif self.strategy == 'within_conversation':
            pairs = self.generate_within_conversation(labels)
        elif self.strategy == 'random':
            pairs = self.generate_random_pairs(labels)
        elif self.strategy == 'combined':
            # Use all strategies
            pairs = []
            pairs.extend(self.generate_cross_conversation(labels))
            pairs.extend(self.generate_within_conversation(labels))
            pairs.extend(self.generate_random_pairs(labels))
            # Dedupe
            seen = set()
            unique_pairs = []
            for p in pairs:
                key = (p.chosen[:100], p.rejected[:100])
                if key not in seen:
                    seen.add(key)
                    unique_pairs.append(p)
            pairs = unique_pairs[:self.max_pairs]
        else:
            raise ValueError(f"Unknown strategy: {self.strategy}")
        
        # Shuffle
        random.shuffle(pairs)
        
        # Write output
        output_path.parent.mkdir(parents=True, exist_ok=True)
        with open(output_path, 'w') as f:
            for pair in pairs:
                f.write(json.dumps(pair.to_dict()) + '\n')
        
        self.print_stats()
        logger.info(f"Wrote {len(pairs)} pairs to {output_path}")
    
    def print_stats(self):
        logger.info("=" * 50)
        logger.info("Preference Generation Complete")
        logger.info(f"  Total labels: {self.stats['total_labels']}")
        logger.info(f"  Pairs generated: {self.stats['pairs_generated']}")
        logger.info(f"  Pairs skipped (low delta): {self.stats['pairs_skipped_low_delta']}")
        logger.info("=" * 50)


def main():
    parser = argparse.ArgumentParser(
        description='Generate DPO preference pairs from z24 labels'
    )
    parser.add_argument(
        'input',
        type=Path,
        help='Labeled JSONL file from label_z24.py'
    )
    parser.add_argument(
        '-o', '--output',
        type=Path,
        default=Path('data/preferences/dpo_pairs.jsonl'),
        help='Output JSONL file'
    )
    parser.add_argument(
        '--strategy',
        choices=['cross_conversation', 'within_conversation', 'random', 'combined'],
        default='combined',
        help='Pairing strategy'
    )
    parser.add_argument(
        '--min-delta',
        type=float,
        default=0.1,
        help='Minimum z24 delta for valid pair'
    )
    parser.add_argument(
        '--max-pairs',
        type=int,
        default=100000,
        help='Maximum pairs to generate'
    )
    parser.add_argument(
        '--seed',
        type=int,
        default=42
    )
    
    args = parser.parse_args()
    
    generator = PreferenceGenerator(
        min_delta=args.min_delta,
        strategy=args.strategy,
        max_pairs=args.max_pairs,
        seed=args.seed
    )
    
    generator.generate(args.input, args.output)


if __name__ == '__main__':
    main()
