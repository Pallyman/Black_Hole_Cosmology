#!/usr/bin/env python3
"""
normalize_logs.py - Multi-source conversation log normalizer

Converts chat logs from various formats (ChatGPT, Claude, etc.) into a unified
JSONL schema for z24 labeling pipeline.

Author: 24D Trainer Pipeline
"""

import json
import hashlib
import logging
from pathlib import Path
from datetime import datetime
from typing import Generator, Optional, Dict, Any, List
from dataclasses import dataclass, asdict
import argparse
from tqdm import tqdm
import os

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


@dataclass
class NormalizedTurn:
    """Unified schema for a single conversation turn."""
    id: str
    conversation_id: str
    timestamp: str
    role: str  # "user" | "assistant" | "system"
    model: Optional[str]
    content: str
    meta: Dict[str, Any]
    
    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)
    
    def content_hash(self) -> str:
        """Generate hash for deduplication."""
        hash_input = f"{self.conversation_id}:{self.timestamp}:{self.role}:{self.content}"
        return hashlib.sha256(hash_input.encode()).hexdigest()[:16]


class CheckpointManager:
    """Manages processing checkpoints for resumable operations."""
    
    def __init__(self, checkpoint_path: Path):
        self.checkpoint_path = checkpoint_path
        self.processed_files: set = set()
        self.processed_count: int = 0
        self.load()
    
    def load(self):
        """Load checkpoint from disk."""
        if self.checkpoint_path.exists():
            with open(self.checkpoint_path, 'r') as f:
                data = json.load(f)
                self.processed_files = set(data.get('processed_files', []))
                self.processed_count = data.get('processed_count', 0)
            logger.info(f"Loaded checkpoint: {self.processed_count} records from {len(self.processed_files)} files")
    
    def save(self):
        """Save checkpoint to disk."""
        with open(self.checkpoint_path, 'w') as f:
            json.dump({
                'processed_files': list(self.processed_files),
                'processed_count': self.processed_count,
                'timestamp': datetime.now().isoformat()
            }, f, indent=2)
    
    def mark_file_done(self, filepath: str):
        """Mark a file as fully processed."""
        self.processed_files.add(filepath)
    
    def is_file_processed(self, filepath: str) -> bool:
        """Check if file was already processed."""
        return filepath in self.processed_files
    
    def increment(self, count: int = 1):
        """Increment processed record count."""
        self.processed_count += count


class ChatGPTNormalizer:
    """Normalizer for ChatGPT JSON exports."""
    
    @staticmethod
    def detect(filepath: Path) -> bool:
        """Check if file is ChatGPT format."""
        try:
            with open(filepath, 'r', encoding='utf-8') as f:
                data = json.load(f)
                # ChatGPT exports have specific structure
                if isinstance(data, list) and len(data) > 0:
                    first = data[0]
                    return 'mapping' in first or 'message' in first
                elif isinstance(data, dict):
                    return 'mapping' in data or 'conversations' in data
        except:
            pass
        return False
    
    @staticmethod
    def normalize(filepath: Path) -> Generator[NormalizedTurn, None, None]:
        """Normalize ChatGPT export to unified format."""
        with open(filepath, 'r', encoding='utf-8') as f:
            data = json.load(f)
        
        # Handle different ChatGPT export structures
        conversations = []
        if isinstance(data, list):
            conversations = data
        elif isinstance(data, dict) and 'conversations' in data:
            conversations = data['conversations']
        elif isinstance(data, dict) and 'mapping' in data:
            conversations = [data]
        
        for conv in conversations:
            conv_id = conv.get('id', conv.get('conversation_id', hashlib.md5(str(conv).encode()).hexdigest()[:12]))
            title = conv.get('title', 'Untitled')
            
            # Extract messages from mapping structure
            mapping = conv.get('mapping', {})
            messages = []
            
            for node_id, node in mapping.items():
                msg = node.get('message')
                if msg and msg.get('content') and msg['content'].get('parts'):
                    content_parts = msg['content']['parts']
                    content = '\n'.join(str(p) for p in content_parts if isinstance(p, str))
                    
                    if content.strip():
                        role = msg.get('author', {}).get('role', 'unknown')
                        if role in ['user', 'assistant', 'system']:
                            timestamp = msg.get('create_time')
                            if timestamp:
                                timestamp = datetime.fromtimestamp(timestamp).isoformat()
                            else:
                                timestamp = datetime.now().isoformat()
                            
                            model = msg.get('metadata', {}).get('model_slug', None)
                            
                            turn_id = f"{conv_id}:{node_id[:8]}"
                            
                            messages.append({
                                'id': turn_id,
                                'timestamp': timestamp,
                                'role': role,
                                'content': content,
                                'model': model
                            })
            
            # Sort by timestamp
            messages.sort(key=lambda x: x['timestamp'])
            
            for msg in messages:
                yield NormalizedTurn(
                    id=msg['id'],
                    conversation_id=conv_id,
                    timestamp=msg['timestamp'],
                    role=msg['role'],
                    model=msg['model'],
                    content=msg['content'],
                    meta={
                        'source': 'chatgpt',
                        'title': title,
                        'original_file': str(filepath.name)
                    }
                )


class ClaudeNormalizer:
    """Normalizer for Claude JSONL exports."""
    
    @staticmethod
    def detect(filepath: Path) -> bool:
        """Check if file is Claude JSONL format."""
        try:
            with open(filepath, 'r', encoding='utf-8') as f:
                first_line = f.readline()
                if first_line.strip():
                    data = json.loads(first_line)
                    # Claude exports typically have these fields
                    return 'uuid' in data or ('role' in data and 'content' in data)
        except:
            pass
        return False
    
    @staticmethod
    def normalize(filepath: Path) -> Generator[NormalizedTurn, None, None]:
        """Normalize Claude JSONL to unified format."""
        with open(filepath, 'r', encoding='utf-8') as f:
            conv_id = filepath.stem  # Use filename as conversation ID
            turn_idx = 0
            
            for line in f:
                line = line.strip()
                if not line:
                    continue
                
                try:
                    msg = json.loads(line)
                except json.JSONDecodeError:
                    logger.warning(f"Skipping malformed line in {filepath}")
                    continue
                
                # Handle different Claude formats
                if 'uuid' in msg:
                    # Full conversation export
                    conv_id = msg.get('uuid', conv_id)
                    messages = msg.get('messages', msg.get('chat_messages', []))
                    
                    for i, m in enumerate(messages):
                        role = m.get('role', m.get('sender', 'unknown'))
                        if role == 'human':
                            role = 'user'
                        
                        content = m.get('content', m.get('text', ''))
                        if isinstance(content, list):
                            content = '\n'.join(str(c.get('text', c)) for c in content if isinstance(c, dict))
                        
                        if content and role in ['user', 'assistant', 'system']:
                            timestamp = m.get('created_at', m.get('timestamp', datetime.now().isoformat()))
                            
                            yield NormalizedTurn(
                                id=f"{conv_id}:{i}",
                                conversation_id=conv_id,
                                timestamp=timestamp,
                                role=role,
                                model=m.get('model', 'claude'),
                                content=content,
                                meta={
                                    'source': 'claude',
                                    'title': msg.get('name', 'Untitled'),
                                    'original_file': str(filepath.name)
                                }
                            )
                else:
                    # Simple message format
                    role = msg.get('role', 'unknown')
                    content = msg.get('content', '')
                    
                    if content and role in ['user', 'assistant', 'system']:
                        yield NormalizedTurn(
                            id=f"{conv_id}:{turn_idx}",
                            conversation_id=conv_id,
                            timestamp=msg.get('timestamp', datetime.now().isoformat()),
                            role=role,
                            model=msg.get('model', 'claude'),
                            content=content,
                            meta={
                                'source': 'claude',
                                'original_file': str(filepath.name)
                            }
                        )
                        turn_idx += 1


class GenericNormalizer:
    """Fallback normalizer for generic JSONL."""
    
    @staticmethod
    def normalize(filepath: Path) -> Generator[NormalizedTurn, None, None]:
        """Attempt to normalize any JSONL file."""
        with open(filepath, 'r', encoding='utf-8') as f:
            conv_id = filepath.stem
            turn_idx = 0
            
            for line in f:
                line = line.strip()
                if not line:
                    continue
                
                try:
                    msg = json.loads(line)
                except json.JSONDecodeError:
                    continue
                
                # Try to extract standard fields
                role = msg.get('role', msg.get('sender', msg.get('author', 'unknown')))
                if role == 'human':
                    role = 'user'
                
                content = msg.get('content', msg.get('text', msg.get('message', '')))
                if isinstance(content, list):
                    content = '\n'.join(str(c) for c in content)
                
                if content and role in ['user', 'assistant', 'system']:
                    yield NormalizedTurn(
                        id=f"{conv_id}:{turn_idx}",
                        conversation_id=msg.get('conversation_id', conv_id),
                        timestamp=msg.get('timestamp', msg.get('created_at', datetime.now().isoformat())),
                        role=role,
                        model=msg.get('model', 'unknown'),
                        content=content,
                        meta={
                            'source': 'generic',
                            'original_file': str(filepath.name)
                        }
                    )
                    turn_idx += 1


class LogNormalizer:
    """Main normalizer that auto-detects format and processes files."""
    
    def __init__(self, output_path: Path, checkpoint_dir: Path):
        self.output_path = output_path
        self.checkpoint = CheckpointManager(checkpoint_dir / 'normalize_checkpoint.json')
        self.seen_hashes: set = set()
        self.stats = {
            'total_files': 0,
            'total_turns': 0,
            'duplicates_skipped': 0,
            'errors': 0
        }
    
    def detect_format(self, filepath: Path) -> str:
        """Auto-detect file format."""
        if filepath.suffix == '.json':
            if ChatGPTNormalizer.detect(filepath):
                return 'chatgpt'
        elif filepath.suffix == '.jsonl':
            if ClaudeNormalizer.detect(filepath):
                return 'claude'
        return 'generic'
    
    def process_file(self, filepath: Path) -> Generator[NormalizedTurn, None, None]:
        """Process a single file with appropriate normalizer."""
        format_type = self.detect_format(filepath)
        logger.info(f"Processing {filepath.name} as {format_type} format")
        
        if format_type == 'chatgpt':
            yield from ChatGPTNormalizer.normalize(filepath)
        elif format_type == 'claude':
            yield from ClaudeNormalizer.normalize(filepath)
        else:
            yield from GenericNormalizer.normalize(filepath)
    
    def process_directory(self, input_dir: Path, resume: bool = True):
        """Process all files in a directory."""
        files = list(input_dir.glob('**/*.json')) + list(input_dir.glob('**/*.jsonl'))
        logger.info(f"Found {len(files)} files to process")
        
        with open(self.output_path, 'a', encoding='utf-8') as out_f:
            for filepath in tqdm(files, desc="Processing files"):
                # Skip if already processed
                if resume and self.checkpoint.is_file_processed(str(filepath)):
                    logger.debug(f"Skipping already processed: {filepath}")
                    continue
                
                self.stats['total_files'] += 1
                
                try:
                    for turn in self.process_file(filepath):
                        # Deduplication
                        content_hash = turn.content_hash()
                        if content_hash in self.seen_hashes:
                            self.stats['duplicates_skipped'] += 1
                            continue
                        self.seen_hashes.add(content_hash)
                        
                        # Write to output
                        out_f.write(json.dumps(turn.to_dict()) + '\n')
                        self.stats['total_turns'] += 1
                        self.checkpoint.increment()
                        
                        # Periodic checkpoint
                        if self.stats['total_turns'] % 10000 == 0:
                            self.checkpoint.save()
                            out_f.flush()
                    
                    self.checkpoint.mark_file_done(str(filepath))
                    
                except Exception as e:
                    logger.error(f"Error processing {filepath}: {e}")
                    self.stats['errors'] += 1
        
        # Final checkpoint
        self.checkpoint.save()
        self.print_stats()
    
    def print_stats(self):
        """Print processing statistics."""
        logger.info("=" * 50)
        logger.info("Normalization Complete")
        logger.info(f"  Files processed: {self.stats['total_files']}")
        logger.info(f"  Total turns: {self.stats['total_turns']}")
        logger.info(f"  Duplicates skipped: {self.stats['duplicates_skipped']}")
        logger.info(f"  Errors: {self.stats['errors']}")
        logger.info(f"  Output: {self.output_path}")
        logger.info("=" * 50)


def main():
    parser = argparse.ArgumentParser(
        description='Normalize chat logs from multiple sources into unified JSONL'
    )
    parser.add_argument(
        'input_dir',
        type=Path,
        help='Directory containing raw chat exports'
    )
    parser.add_argument(
        '-o', '--output',
        type=Path,
        default=Path('data/normalized/conversations.jsonl'),
        help='Output JSONL file path'
    )
    parser.add_argument(
        '-c', '--checkpoint-dir',
        type=Path,
        default=Path('data/normalized'),
        help='Directory for checkpoint files'
    )
    parser.add_argument(
        '--no-resume',
        action='store_true',
        help='Start fresh, ignoring any existing checkpoints'
    )
    parser.add_argument(
        '-v', '--verbose',
        action='store_true',
        help='Enable verbose logging'
    )
    
    args = parser.parse_args()
    
    if args.verbose:
        logging.getLogger().setLevel(logging.DEBUG)
    
    # Ensure output directory exists
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.checkpoint_dir.mkdir(parents=True, exist_ok=True)
    
    # Clear output file if not resuming
    if args.no_resume and args.output.exists():
        args.output.unlink()
    
    normalizer = LogNormalizer(args.output, args.checkpoint_dir)
    normalizer.process_directory(args.input_dir, resume=not args.no_resume)


if __name__ == '__main__':
    main()
