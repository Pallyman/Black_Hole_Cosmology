#!/bin/bash
# 24D Heterogeneous ML Training Pipeline
# Run the full pipeline from raw logs to aligned model

set -e  # Exit on error

# Configuration
RAW_DATA_DIR="${1:-data/raw}"
OUTPUT_DIR="${2:-models/aligned}"
BASE_MODEL="${3:-meta-llama/Llama-3.1-8B-Instruct}"

echo "=========================================="
echo "24D Heterogeneous ML Training Pipeline"
echo "=========================================="
echo "Raw data: $RAW_DATA_DIR"
echo "Output: $OUTPUT_DIR"
echo "Base model: $BASE_MODEL"
echo ""

# Step 1: Normalize logs
echo "[1/6] Normalizing logs..."
python src/normalize_logs.py "$RAW_DATA_DIR" \
    -o data/normalized/conversations.jsonl \
    --checkpoint-dir data/normalized

echo "✓ Normalization complete"
echo ""

# Step 2: Label with z24
echo "[2/6] Labeling with z24 (this may take a while)..."
python src/label_z24.py data/normalized/conversations.jsonl \
    -o data/labeled/z24_labels.jsonl \
    --checkpoint-dir data/labeled \
    --provider anthropic \
    --rate-limit 50 \
    --min-confidence 0.5

echo "✓ Labeling complete"
echo ""

# Step 3: Train fast encoder
echo "[3/6] Training z24 encoder..."
python src/train_z24_encoder.py data/labeled/z24_labels.jsonl \
    -o models/z24_encoder \
    --epochs 10 \
    --batch-size 32

echo "✓ Encoder training complete"
echo ""

# Step 4: Generate preference pairs
echo "[4/6] Generating preference pairs..."
python src/generate_preferences.py data/labeled/z24_labels.jsonl \
    -o data/preferences/dpo_pairs.jsonl \
    --strategy combined \
    --min-delta 0.1 \
    --max-pairs 50000

echo "✓ Preference generation complete"
echo ""

# Step 5: Fine-tune with DPO
echo "[5/6] Fine-tuning with DPO..."
python src/finetune_dpo.py data/preferences/dpo_pairs.jsonl \
    -o "$OUTPUT_DIR" \
    --base-model "$BASE_MODEL" \
    --beta 0.1 \
    --epochs 3 \
    --batch-size 4 \
    --grad-accum 4

echo "✓ Fine-tuning complete"
echo ""

# Step 6: Evaluate
echo "[6/6] Evaluating..."

# Find the most recent fine-tuned model
FT_MODEL=$(ls -td "$OUTPUT_DIR"/dpo_* 2>/dev/null | head -1)
if [ -z "$FT_MODEL" ]; then
    FT_MODEL="$OUTPUT_DIR"
fi

python src/evaluate_z24.py \
    --base-model "$BASE_MODEL" \
    --finetuned-model "$FT_MODEL/final" \
    --test-data data/preferences/dpo_pairs.jsonl \
    --encoder models/z24_encoder \
    --n-samples 100 \
    -o evaluation_report.md

echo "✓ Evaluation complete"
echo ""

echo "=========================================="
echo "Pipeline Complete!"
echo "=========================================="
echo "Fine-tuned model: $FT_MODEL/final"
echo "Evaluation report: evaluation_report.md"
echo ""
echo "🔵🫸🫷🔴🤞🤌🫴🟣"
