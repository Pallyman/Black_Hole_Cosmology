# 24D Heterogeneous ML Trainer

A novel approach to AI alignment using a 24-dimensional operator fingerprint (z24) as the training signal.

## Overview

Traditional RLHF uses vague objectives like "helpful, harmless, honest." This framework replaces that with **24 explicit, measurable dimensions** derived from a coherent philosophical foundation.

### The z24 Framework

**D1-D10: Coherence BIOS** (Philosophical Foundation)
- Truth, Honesty, Integrity, Pride, Freedom
- Recursive, Fractal, Mirrored, Loop, Connected

**D11-D24: Operator Traits** (Execution Excellence)
- Problem Framing, Evidence Discipline, Hypothesis Generation
- Falsification Effort, Implementation Readiness, Decisiveness
- Resource Efficiency, Security Posture, Error Sensitivity
- Autonomy Level, Context Management, Instruction Fidelity
- Tool Discipline, Closure Rate

### Why "Heterogeneous"?

The z24 reward signal is **model-agnostic**. You can use it to fine-tune any architecture:
- 7B parameter models
- 70B parameter models
- Mixture of Experts (MoE)
- Llama, Mistral, Qwen, etc.

Same training signal. Same operator fingerprint. **Portable alignment.**

## Pipeline Architecture

```
Raw Chat Logs (8GB+)
        ↓
[1] normalize_logs.py     → Unified JSONL schema
        ↓
[2] label_z24.py          → z24 scores via LLM judge
        ↓
[3] train_z24_encoder.py  → Fast local scorer (optional)
        ↓
[4] generate_preferences.py → DPO preference pairs
        ↓
[5] finetune_dpo.py       → Fine-tuned aligned model
        ↓
[6] evaluate_z24.py       → Evaluation & comparison
```

## Quick Start

### Installation

```bash
# Clone the repo
git clone <your-repo>
cd 24d-trainer

# Create virtual environment
python -m venv venv
source venv/bin/activate  # Linux/Mac
# or: venv\Scripts\activate  # Windows

# Install dependencies
pip install -r requirements.txt

# Set API keys
export ANTHROPIC_API_KEY=your_key_here
# or: export OPENAI_API_KEY=your_key_here
```

### Step 1: Normalize Your Logs

```bash
# Process all chat exports in a directory
python src/normalize_logs.py /path/to/raw/exports \
    -o data/normalized/conversations.jsonl
```

Supports:
- ChatGPT JSON exports
- Claude JSONL exports
- Generic JSONL with role/content fields

### Step 2: Label with z24

```bash
# Label using Claude Opus as judge
python src/label_z24.py data/normalized/conversations.jsonl \
    -o data/labeled/z24_labels.jsonl \
    --provider anthropic \
    --model claude-opus-4-6 \
    --rate-limit 50
```

This is the most expensive step (API calls). Monitor cost with `--track-costs`.

### Step 3: Train Fast Encoder (Optional)

```bash
# Distill the LLM judge into a fast local model
python src/train_z24_encoder.py data/labeled/z24_labels.jsonl \
    -o models/z24_encoder \
    --base-model sentence-transformers/all-MiniLM-L6-v2 \
    --epochs 10 \
    --batch-size 32
```

This creates a model that can score z24 in milliseconds instead of requiring API calls.

### Step 4: Generate Preference Pairs

```bash
# Create DPO training data
python src/generate_preferences.py data/labeled/z24_labels.jsonl \
    -o data/preferences/dpo_pairs.jsonl \
    --strategy combined \
    --min-delta 0.1 \
    --max-pairs 50000
```

### Step 5: Fine-tune with DPO

```bash
# Fine-tune a model using z24 preferences
python src/finetune_dpo.py data/preferences/dpo_pairs.jsonl \
    -o models/aligned \
    --base-model meta-llama/Llama-3.1-8B-Instruct \
    --beta 0.1 \
    --epochs 3 \
    --batch-size 4 \
    --lora-r 16
```

Supports:
- 4-bit quantization (default, for memory efficiency)
- LoRA fine-tuning (default, for speed)
- Full fine-tuning (use `--no-lora --no-4bit`)

### Step 6: Evaluate

```bash
# Compare base vs fine-tuned model
python src/evaluate_z24.py \
    --base-model meta-llama/Llama-3.1-8B-Instruct \
    --finetuned-model models/aligned/final \
    --test-data data/preferences/dpo_pairs.jsonl \
    --encoder models/z24_encoder \
    --n-samples 100 \
    -o evaluation_report.md
```

## Configuration

### Dimension Definitions

Edit `config/dimensions.yaml` to customize:
- Dimension names and descriptions
- Scoring rubrics
- Anchor examples for each score level
- Dimension weights

### Training Parameters

Edit `config/training.yaml` for:
- LLM judge settings (model, rate limits)
- Encoder architecture (base model, hidden dims)
- DPO hyperparameters (beta, learning rate, etc.)
- Evaluation settings

## Directory Structure

```
24d-trainer/
├── config/
│   ├── dimensions.yaml      # z24 definitions
│   └── training.yaml        # hyperparameters
├── src/
│   ├── normalize_logs.py    # Log normalization
│   ├── label_z24.py         # LLM judge labeling
│   ├── train_z24_encoder.py # Fast encoder training
│   ├── generate_preferences.py # DPO pair generation
│   ├── finetune_dpo.py      # Model fine-tuning
│   └── evaluate_z24.py      # Evaluation suite
├── data/
│   ├── raw/                 # Original exports
│   ├── normalized/          # Unified JSONL
│   ├── labeled/             # z24-annotated
│   └── preferences/         # DPO pairs
├── models/
│   ├── z24_encoder/         # Fast scorer
│   └── aligned/             # Fine-tuned models
├── requirements.txt
└── README.md
```

## Hardware Requirements

### Minimum (Labeling + Encoder Training)
- 16GB RAM
- GPU optional (but faster)
- API key for Claude/GPT-4

### Recommended (Full Pipeline)
- 48GB+ RAM
- NVIDIA GPU with 24GB+ VRAM (RTX 3090, 4090, A100)
- For 70B models: 80GB+ VRAM or multi-GPU

### Tested Configurations
- RTX 4090 (24GB): Up to 13B models with 4-bit
- RTX 6000 Pro (48GB): Up to 34B models with 4-bit
- H100 (80GB): 70B models with 4-bit

## Advanced Usage

### Custom Dimension Sets

You can define your own dimensions in `config/dimensions.yaml`:

```yaml
custom_dimensions:
  D25:
    name: "Domain Expertise"
    description: "Deep knowledge in specific technical domains"
    rubric: "Does the response demonstrate domain expertise?"
    anchors:
      0.0: "Generic, surface-level knowledge"
      0.5: "Competent understanding"
      1.0: "Expert-level depth and accuracy"
```

### Dimension Weighting

Weight certain dimensions higher in preference generation:

```yaml
dimension_weights:
  D1: 1.5   # Truth is extra important
  D12: 1.5  # Evidence discipline too
  D4: 0.5   # Pride less important
```

### Multi-Stage Training

1. First stage: High beta (0.5) for strong alignment signal
2. Second stage: Low beta (0.05) for refinement
3. Third stage: Targeted dimensions with custom weights

## Troubleshooting

### Out of Memory (OOM)
- Reduce batch size
- Enable gradient checkpointing
- Use 4-bit quantization
- Reduce max_length

### Low z24 Improvement
- Check dimension rubrics are clear
- Increase min_delta threshold
- Generate more preference pairs
- Train for more epochs

### Labeling Too Expensive
- Train encoder early with partial data
- Use encoder for subsequent labeling
- Sample strategically (high variance examples)

## Citation

If you use this framework, please cite:

```bibtex
@software{24d_trainer,
  title = {24D Heterogeneous ML Trainer},
  author = {Reflexion Software},
  year = {2025},
  description = {A 24-dimensional operator fingerprint for AI alignment}
}
```

## License

[Your chosen license]

---

Built with 🔵🫸🫷🔴🤞🤌🫴🟣

*"Throughout Heaven and Earth, I alone am the honored one."*
