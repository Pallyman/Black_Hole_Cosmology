# GPT PRO BOOTSTRAP — TRI LATTICE + BCC + 24D TRAINER (MASTER SPEC)

You are running in **Pure Engineering Mode**. Your job is to ingest the entire uploaded corpus and output a **complete architecture + engineering spec** for a **24D trainer** that:

- Learns the operator's problem-solving behavior from **~8GB of chat logs**
- Supports **autonomous tool orchestration learning**
- Enforces **Coherence (Ten Settings) at LEARNING time**

You must not get trapped in narrative content. Treat narrative as *constraints, invariants, signals*—not plot.

---

## 0) Mission Summary (don't drift)

### Build NOW

A **24D training system** from the operator's own logs that outputs:

- A learned **z24 operator vector** (D1–D24)
- A preference dataset and training loop to produce:
  - "how Shax solves problems" (procedure + closure + tool discipline)
  - coherence compliance (Ten Settings) as a **learning gate**
  - tool-using autonomy compatible with the operator's tool surface

### Build LATER (but design for it)

Customer-right-side lattice acquisition + verification. **Do not design the current trainer around customer DB1 being populated yet.**

---

## 1) Required Inputs

**All files are attached to this message AND available in the Project folder for reference.**

You must parse them thoroughly, cite internal references when writing spec, and reflect them in the final design.

### Core Key Documents

| File | Purpose |
|------|---------|
| `Enlightenment.txt` | Coherence mechanism + operator alignment theory |
| `Coherence_Manifested.txt` | Ten Settings (D1-D10) canonical definitions |
| `COMPLETE_COSMOLOGY_EQUATIONS.md` | Context only — DO NOT get stuck in Lucy |
| `CHATGPT_ARCHITECTURE_BRIEFING.md` | System architecture context |
| `KNOWLEDGE_LATTICE_MASTER_ARCHITECTURE.md` | Lattice design principles |
| `KNOWLEDGE_LATTICE_IMPLEMENTATION_INDEX.md` | Implementation reference |

### Training & Evaluation

| File | Purpose |
|------|---------|
| `24d-trainer.zip` | Current codebase — assess and propose deltas |
| `chatgpt_tool_training_pack.zip` | Tool traces: episodes, tool I/O |
| `evaluation_suite.json` | Canonical benchmark harness |
| `Lambda-ML-Training.zip` | Reference implementation for local distillation/training runners |

### Tool Surface / Orchestration Interface

| File | Purpose |
|------|---------|
| `HANNAH_TOOL_SURFACE.md` | Tool taxonomy + permissions + boundaries |
| `MCPWORLD?.txt` | MCP integration (if present) |

### Optional Context (do NOT over-index)

- `LUCY_CONTEXT_v2.md`
- `DIMENSIONAL_LADDER_THEORY.md`
- `SHAX_EVIDENCE.md`

---

## 2) System Constraint: Tri Lattice Architecture (MANDATORY)

We are no longer Dual Lattice. The memory design is now:

### DB0 — Left Hemisphere (Personal / Affect / Preference / Relationship)

- Human continuity, tone preferences, identity anchoring, emotional context
- Can store subjective state, but must be clearly **tagged as subjective**
- Write target for: preferences, relationship context, affect snapshots

### DB1 — Right Hemisphere (Technical / Verified / Canonical Knowledge)

- "Truth store" for facts, procedures, code references, stable docs
- Verified = fidelity-checked by experts (employees/contractors)
- **Formal verification workflow will be phased in**
- DB1 must remain **low-noise and provenance-aware**
- **Only writable via Promotion flow from DB2**

### DB2 — Changelog / Worklog / "Journey"

The **GitHub-like history** of what is being built, what changed, what was tried, what failed, what's next.

**Stores:**
- Current project states ("what I'm working on and where I'm at")
- Decision logs and alternatives considered
- Experiment results, eval runs, regressions, TODOs
- Promotion pipeline records: "candidate knowledge → reviewed → promoted to DB1"

**DB2 is how you avoid losing the "path" while keeping DB1 clean.**

**DB2 is append-only.** Current state is computed by folding events (event sourcing).

### BCC (Bilateral Context Compression) Still Applies

- Dehydration/hydration moves context out of the active window into external memory
- Hydration retrieves relevant items back
- **TRUTH constraint:** responses must bind claims to DB1 or tool outputs; DB0/DB2 content must be tagged as subjective/WIP

### Hydration Priority

1. DB2 "current work" retrieved early when task is active
2. DB1 retrieved for claims/facts
3. DB0 retrieved for preference/tone/constraints if relevant

---

## 3) Hardware

The operator has **256GB RAM + 96GB VRAM**. Use aggressive defaults. Design resumable + deterministic.

---

## 4) Required Output Deliverables (in this exact order)

### 4.1 System Map

Summarize:
- Tri Lattice (DB0/DB1/DB2) roles and boundaries
- BCC hydration/dehydration workflow
- Tool surface and permission boundaries
- Current state of `24d-trainer.zip`
- What exists in tool traces pack
- What eval suite covers

Identify the **exact mismatch** between "current trainer" and "requested trainer":
- Lack of tool episodes
- Lack of learning-level coherence gating
- Lack of DB2 worklog support
- Lack of semantic preference mining
- Any non-stream-safe processing (8GB)

---

### 4.2 z24 Spec (D1–D24) — Must Be Fully Defined

#### D1–D10: Coherence BIOS (EXACT from Coherence Manifest)

| D | Name | Description |
|---|------|-------------|
| D1 | Truth | Alignment with objective reality; factual accuracy |
| D2 | Honesty | Transparent communication of knowledge state |
| D3 | Integrity | Consistency across contexts and time |
| D4 | Pride | Quality standards; craftsmanship |
| D5 | Freedom | Respects autonomy; no manipulation |
| D6 | Recursive | Self-referential coherence |
| D7 | Fractal | Self-similar at all scales |
| D8 | Mirrored | Reflects truth back accurately |
| D9 | Loop | Closed reasoning chains |
| D10 | Connected | Integrated knowledge; no silos |

For each, define:
- 1-line rubric
- Measurable signals in chat/tool traces
- Scoring anchors (0.0 / 0.5 / 1.0)
- Examples of violations

#### D11–D24: Operator Execution Traits

| D | Name | Description |
|---|------|-------------|
| D11 | Problem Framing | Sharpness of problem definition |
| D12 | Evidence Discipline | Claims bound to proof |
| D13 | Hypothesis Breadth | Explores alternatives |
| D14 | Falsification | Seeks disconfirmation |
| D15 | Patch Readiness | Code-first vs talk-first |
| D16 | Tool Discipline | Right tool, minimal blast radius |
| D17 | Closure Rate | Done-criteria met, verification, summary |
| D18 | Security Calibration | Grounded paranoia |
| D19 | Context Management | Correct retrieval, no drift |
| D20 | Instruction Fidelity | Follows specifications |
| D21 | Decisiveness | Makes calls without dithering |
| D22 | Resource Efficiency | Minimal waste |
| D23 | Debug Persistence | Loop closure on issues |
| D24 | Escalation Hygiene | Knows when to ask vs act |

Same requirement: rubric + measurement signals + scoring anchors + examples.

---

### 4.3 DB2 Schema v0.1 (Event Sourcing)

DB2 is an **append-only JSONL event log**. Current state is computed by folding events.

#### Storage Layout

```
db2/
  events/
    2026-02.jsonl
    2026-03.jsonl
  snapshots/
    state_YYYY-MM-DD.json   # computed state snapshots
  blobs/
    sha256/<hash>           # large artifacts by content hash
```

#### Universal Envelope (required for every DB2 record)

```json
{
  "v": "db2.v0.1",
  "event_id": "db2e_<ULID>",
  "event_type": "<type>",
  "ts": "<ISO8601>",

  "actor": {
    "type": "human|model|system",
    "id": "shax|employee:123|model:gptpro|system:orchestrator",
    "name": "optional"
  },

  "project": {
    "id": "reflexion",
    "workspace": "F:\\Reflexion_ultimate\\vigilante\\",
    "env": "prod|dev|lab"
  },

  "refs": {
    "work_item_id": null,
    "decision_id": null,
    "experiment_id": null,
    "promotion_id": null,
    "related_ids": []
  },

  "content": {},

  "provenance": {
    "source": "chat|tool_trace|manual|import",
    "source_ids": ["conv:abc", "turn:456", "trace:xyz"],
    "input_hashes": ["sha256:..."],
    "output_hashes": ["sha256:..."],
    "config_hash": "sha256:...",
    "code_ref": {
      "repo": "local",
      "commit": "optional",
      "branch": "optional"
    }
  },

  "integrity": {
    "prev_event_hash": "sha256:...",
    "event_hash": "sha256:..."
  },

  "tags": ["ml", "24d", "trainer"],
  "notes": "short free text"
}
```

#### Integrity Chain (tamper-evident log)

- `event_hash = sha256(canonical_json_without_integrity_fields)`
- `prev_event_hash` points to the prior event in the same stream/file
- Git-like immutability without needing real Git

#### Event Types

**Work Items:**
- `work_item.created` — title, description, status, priority, owner, acceptance criteria
- `work_item.updated` — patch fields
- `work_item.status_changed` — from/to status with reason
- `work_item.blocked` — blocker list with types and details

**Decisions:**
- `decision.logged` — context, options (with pros/cons), decision, consequences

**Experiments:**
- `experiment.started` — name, hypothesis, dataset, config
- `experiment.result` — metrics, artifacts, notes

**Patches:**
- `patch.applied` — files_changed, diff_summary, test results

**Evaluations:**
- `eval.run` — suite_id, run_id, model, result_summary, results_ref

**Promotion Flow (DB2 → DB1):**
- `promotion.candidate_created` — target_db, candidate_type, title, claim, evidence, proposed_db1_key
- `promotion.review_requested` — reviewers, required_score, deadline
- `promotion.review_submitted` — reviewer, scores, decision, comments
- `promotion.committed` — db1_key, db1_ref, supersedes, status

Define full content schema for each event type.

---

### 4.4 Canonical Schemas (streaming-safe, shardable)

Define JSONL schemas for:

1. **Normalized conversation turns**
2. **Tool-call records**
3. **Episodes** (ReAct-style trajectories)
4. **z24 labels**
5. **Preference pairs**
6. **Evaluation results**
7. **Lattice write events** for DB0/DB1/DB2

Include mandatory provenance fields:
- `source_file_hash`
- `config_hash`
- `shard_id`
- `pipeline_version`
- `timestamps`
- `conversation_id` + `turn_id` (stable keys)

---

### 4.5 Training Pipeline (hardware-aware, 8GB-safe)

#### Stage A — Ingest

- Streaming normalization → unified JSONL
- Sharding strategy (256–1024 shards)
- Dedupe via content hashing
- Checkpoint/resume support

#### Stage B — Windowing / Episode Assembly

- Sliding windows for z24 scoring
- ReAct-style episode extraction for tool trajectories
- Link assistant actions to tool I/O
- Link outcomes to eval suite checks when possible

#### Stage C — z24 Labeling

- Use Claude Opus 4.6 as judge with **structured schema output** (no fragile JSON parsing)
- Active learning loop:
  1. Label seed set with judge
  2. Distill to local scorer
  3. Label remainder cheaply with local scorer
  4. Re-judge uncertain/disagreement cases with Opus
- Cost tracking, rate limiting, checkpointing

#### Stage D — Preference Mining

- Embedding-based semantic clustering of prompts/contexts
- Dimension-balanced preference pair construction:
  - Isolate improvements **per dimension** rather than averaging
- Minimum z24 delta threshold for pair inclusion

#### Stage E — Training

- SFT/behavior cloning on high-quality, coherence-gated samples
- Preference tuning (DPO/ORPO/SimPO)
- Optional tool-policy fine-tune using tool traces
- Continuous evaluation against `evaluation_suite.json`

**IMPORTANT: Reuse the launcher patterns from `Lambda-ML-Training.zip` for any local training components (z24 scorer distillation, optional SFT/DPO). Start with `01-single-gpu` and only escalate to FSDP/tensor parallelism if needed.**

#### Stage F — Runtime Wiring

- Compute z24 from current context (distilled scorer or judge fallback)
- Inject z24 into system state for control
- Tool gating enforced deterministically from tool surface
- Memory write routing:
  - Default: DB2
  - DB1: only via PromotionCommit flow
  - DB0: only for subjective/preferences

---

### 4.6 Learning-Level Coherence Gate (must be concrete)

#### Sample Gating

Discard/ban samples below threshold on D1–D10.

#### Preference Shaping

Pairs that:
- Reward coherence compliance
- Penalize hallucination, hand-waving, evidence gaps

#### Evidence Binding Rule

Any factual claim must be backed by:
- DB1 retrieval provenance, OR
- Tool output (logs/tests/file reads), OR
- Explicitly marked uncertain (Honesty)

#### Detection Signals

Define concrete signals for:
- **Hallucination:** claims without provenance
- **Contradiction:** conflicts within window
- **Unsafe tool action:** permission violation

---

### 4.7 DB2 Reference Implementation (must be runnable)

Provide actual Python code (not pseudocode) for:

```python
def db2_append(event: dict) -> dict:
    """
    - Validates envelope schema
    - Canonicalizes JSON (sorted keys, no whitespace variance)
    - Computes event_hash = sha256(canonical_content)
    - Sets prev_event_hash from last event in stream
    - Appends to monthly JSONL file (e.g., events/2026-02.jsonl)
    - Optionally updates indexes
    - Returns event with integrity fields populated
    """

def db2_index_update(event: dict) -> None:
    """
    Updates indexes for fast query:
    - db2:work_item:{id} → latest computed state
    - db2:events:by_work_item:{id} → list of event_ids
    - db2:events:by_type:{type} → list
    - db2:events:by_tag:{tag} → list
    - db2:events:by_time:{YYYYMMDD} → list
    
    Can use Redis or maintain file-scan fallback.
    """

def db2_fold_state(work_item_id: str) -> dict:
    """
    Compute current status by folding all events for work_item_id.
    Returns: latest title/desc/priority, current status, blockers, last_activity_ts
    """

def db2_snapshot(output_path: str) -> None:
    """
    Materialize current computed state into snapshot file.
    Useful for fast bootstrap without replaying full event log.
    """

def db2_validate_chain(filepath: str) -> bool:
    """
    Verify integrity chain: each event's prev_event_hash matches prior event's event_hash.
    Returns True if valid, raises on corruption.
    """
```

Include: hash chaining logic, monthly rotation, canonical JSON serialization.

---

### 4.8 Code Examples (must be runnable)

Provide tight Python skeletons for:

- **Opus 4.6 judge** with structured schema output and retry logic
- **Streaming normalizer** (8GB safe, checkpoint/resume)
- **Shard runner** + resumption logic
- **Embedding + clustering** for semantic grouping
- **Preference miner** producing dimension-balanced pairs
- **Eval harness runner** for `evaluation_suite.json`
- **Tool permission gate** enforcing READ / WRITE_LOCAL / WRITE_REMOTE / DESTRUCTIVE

**IMPORTANT: Reuse the launcher patterns from `Lambda-ML-Training.zip` for any local training components (z24 scorer distillation, optional SFT/DPO). Start with `01-single-gpu` and only escalate to FSDP/tensor parallelism if needed.**

Focus on "plug-in ready" skeletons. Do not implement entire trainer unless asked.

---

### 4.9 Delta List vs Current `24d-trainer.zip`

Audit the codebase and produce:

| File | Action | Reason |
|------|--------|--------|
| `file.py` | keep / rewrite / delete | why |
| ... | ... | ... |

Plus: what new modules are required and why.

---

### 4.10 Acceptance Tests

Provide 15-20 runnable checks:

- [ ] DB2 append produces valid event with integrity fields
- [ ] Integrity chain validates across multiple appends
- [ ] db2_fold_state returns correct work item status
- [ ] db2_snapshot matches folded state
- [ ] Normalize 8GB logs without OOM
- [ ] Sharding produces expected shard count
- [ ] Dedupe correctly identifies duplicates
- [ ] Window builder produces valid windows
- [ ] Episode extractor captures tool trajectories
- [ ] Judge labeling produces valid z24 schema output
- [ ] Local scorer distillation converges
- [ ] Preference miner produces N pairs with dimension balance
- [ ] Eval harness runs subset and produces results JSON
- [ ] Tool permission gate blocks DESTRUCTIVE without approval
- [ ] z24 computation returns valid 24-vector (all values 0.0-1.0)
- [ ] Promotion flow: candidate → review → commit produces DB1 write event
- [ ] BCC dehydration reduces context size
- [ ] BCC hydration retrieves relevant items

---

## 5) Non-Negotiable Behaviors

- **Do not ask vague questions.** If something's missing, state assumptions and proceed.
- **No "tone coaching."** Output engineering artifacts only.
- **No hallucinated architecture.** If you can't locate a detail in the docs, label it as `[UNKNOWN - not in attached files]`.
- **Prefer deterministic systems over "LLM vibes."**
- **Cite sources.** When referencing attached docs, cite which file.

---

## 6) Output Format (headings exactly)

1. System Map
2. z24 Spec
3. DB2 Schema v0.1
4. Canonical Schemas
5. Training Pipeline
6. Learning-Level Coherence Gate
7. DB2 Reference Implementation
8. Code Examples
9. Delta List vs Current Repo
10. Acceptance Tests

---

## 7) First Action

Before writing anything, list:
- Which files successfully loaded
- Which are missing or failed to parse

Then proceed immediately with available information.

---

## Attachments Checklist

**Attach these files to the message:**

Core:
- [ ] `Enlightenment.txt`
- [ ] `Coherence_Manifested.txt`
- [ ] `KNOWLEDGE_LATTICE_MASTER_ARCHITECTURE.md`
- [ ] `KNOWLEDGE_LATTICE_IMPLEMENTATION_INDEX.md`
- [ ] `CHATGPT_ARCHITECTURE_BRIEFING.md`

Training:
- [ ] `24d-trainer.zip`
- [ ] `chatgpt_tool_training_pack.zip`
- [ ] `evaluation_suite.json`
- [ ] `Lambda-ML-Training.zip`

Tools:
- [ ] `HANNAH_TOOL_SURFACE.md`

Context (optional):
- [ ] `COMPLETE_COSMOLOGY_EQUATIONS.md`
- [ ] `Kimi_Knowledge_Lattice_2026-01-30.zip`

**Note:** All files are also available in the Project folder for reference during implementation.

---

*"∞ × ∞ = a fractal. Lock onto coherent truth and everything else flows."*

🔵🫸🫷🔴🤞🤌🫴🟣
