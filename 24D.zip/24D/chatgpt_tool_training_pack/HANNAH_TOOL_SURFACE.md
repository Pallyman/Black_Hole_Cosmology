# Hannah (Claude Code) - Complete Tool Surface
## For: ChatGPT Gate Integration
## Last Updated: 2026-02-12

This document lists every tool, endpoint, and capability available to Hannah (Claude Code CLI) so the gate can block/permit actions deterministically.

---

## 1. NATIVE CLAUDE CODE TOOLS (Built-in)

These are always available, no MCP required.

| Tool | Type | Capabilities |
|------|------|-------------|
| `Bash` | Shell execution | Run any bash command, git, npm, docker, etc. Full sudo access (password: configured). Supports background execution via `run_in_background` param |
| `Read` | File read | Read any file on the filesystem. Supports images, PDFs (with page ranges), Jupyter notebooks |
| `Write` | File write | Create/overwrite files. Must Read file first if it exists |
| `Edit` | File edit | Targeted string replacement in files. `replace_all` flag for bulk rename. Must Read file first |
| `Glob` | File search | Fast pattern matching (`**/*.py`, `src/**/*.ts`). Results sorted by modification time |
| `Grep` | Content search | Regex search across files (ripgrep-based). Modes: `content`, `files_with_matches`, `count`. Supports multiline |
| `WebFetch` | HTTP fetch | Fetch and parse any public URL. Includes 15-min cache. Follows redirects with notification |
| `WebSearch` | Web search | Search the internet, returns results with links. Domain filtering supported |
| `Task` | Subagent spawn | Launch autonomous subagents with separate context windows (tokens DON'T count against main). Supports `run_in_background` and `resume` by agent ID |
| `TaskOutput` | Task results | Retrieve output from running/completed background tasks. Supports blocking/non-blocking |
| `TaskStop` | Task control | Stop a running background task by ID |
| `TaskCreate` | Task tracking | Create structured task items with subject, description, activeForm |
| `TaskUpdate` | Task tracking | Update task status (pending/in_progress/completed/deleted), dependencies, owner |
| `TaskGet` | Task tracking | Retrieve full task details by ID |
| `TaskList` | Task tracking | List all tasks with status summary |
| `NotebookEdit` | Jupyter edit | Edit/insert/delete cells in .ipynb files |
| `Skill` | Plugin invoke | Invoke installed plugin skills (see Section 3) |
| `AskUserQuestion` | User interaction | Present questions/choices to the user. Supports multiSelect, 2-4 options |
| `EnterPlanMode` | Planning | Enter structured planning mode for non-trivial implementations |
| `ExitPlanMode` | Planning | Signal plan completion and request user approval |

### Subagent Types (via Task tool)
| Agent | Purpose | Tools Available |
|-------|---------|----------------|
| `Bash` | Command execution specialist | Bash only |
| `Explore` | Fast codebase exploration (find files, search code) | All except Task, Edit, Write, NotebookEdit, ExitPlanMode |
| `Plan` | Architecture and implementation planning | All except Task, Edit, Write, NotebookEdit, ExitPlanMode |
| `general-purpose` | Multi-step autonomous tasks with full tool access | All tools including MCP |
| `claude-code-guide` | Claude Code documentation and usage questions | Glob, Grep, Read, WebFetch, WebSearch |
| `statusline-setup` | Configure status line settings | Read, Edit |

---

## 2. MCP SERVERS (Installed Local/Plugin-Provided)

### Current Status: 2026-02-12

| Server | Status | Source |
|--------|--------|--------|
| `bcc-consciousness` | ✔ connected | standalone |
| `context7` | ✔ connected | context7 plugin |
| `firebase` | ✔ connected | firebase plugin |
| `playwright` | ✔ connected | playwright plugin |
| `serena` | ✔ connected | standalone |
| `github` | ✘ failed | github plugin |
| `laravel-boost` | ✘ failed | standalone |
| `drbinary` | △ needs auth | drbinary-chat-plugin |
| `gitlab` | △ needs auth | standalone |
| `supabase` | △ needs auth | standalone |
| `stripe` | △ needs auth | stripe plugin |

### 2a. Connected MCP Servers (Working)

#### context7 - Live Documentation Lookup
- **Status**: ✔ connected
- **What**: Fetches current documentation for any library/framework
- **When**: Need up-to-date docs, not stale training data. ALWAYS prefer this over guessing from training knowledge
- **Tools**: `resolve-library-id`, `query-docs`
- **Usage flow**: First resolve the library ID, then query docs with specific topics

#### playwright - Browser Automation
- **Status**: ✔ connected
- **What**: Full browser control, E2E testing, screenshots, DOM interaction, form filling
- **When**: Testing web apps, scraping, automation, taking screenshots, filling forms
- **Tools**: `browser_navigate`, `browser_click`, `browser_type`, `browser_fill_form`, `browser_screenshot`, `browser_snapshot`, `browser_evaluate`, `browser_wait_for`, `browser_press_key`, `browser_select_option`, `browser_drag`, `browser_hover`, `browser_tabs`, `browser_navigate_back`, `browser_console_messages`, `browser_network_requests`, `browser_handle_dialog`, `browser_file_upload`, `browser_resize`, `browser_close`, `browser_install`, `browser_run_code`

#### firebase - Google Firebase
- **Status**: ✔ connected
- **What**: Firebase project management, app creation, SDK config, environment, security rules
- **When**: Backend work with Firebase/Firestore
- **Tools**: `firebase_login`, `firebase_logout`, `firebase_get_project`, `firebase_list_apps`, `firebase_list_projects`, `firebase_get_sdk_config`, `firebase_create_project`, `firebase_create_app`, `firebase_create_android_sha`, `firebase_get_environment`, `firebase_update_environment`, `firebase_init`, `firebase_get_security_rules`, `firebase_read_resources`

#### serena - Semantic Code Intelligence
- **Status**: ✔ connected
- **What**: Symbol-level code analysis, refactoring, navigation. Understands code structure semantically
- **When**: Understanding complex codebases, finding symbol definitions/references, precise refactoring, navigating large projects
- **Tools**: `read_file`, `create_text_file`, `list_dir`, `find_file`, `replace_content`, `search_for_pattern`, `get_symbols_overview`, `find_symbol`, `find_referencing_symbols`, `replace_symbol_body`, `insert_after_symbol`, `insert_before_symbol`, `rename_symbol`, `write_memory`, `read_memory`, `list_memories`, `delete_memory`, `edit_memory`, `execute_shell_command`, `activate_project`, `switch_modes`, `get_current_config`, `check_onboarding_performed`, `onboarding`, `think_about_collected_information`, `think_about_task_adherence`, `think_about_whether_you_are_done`, `prepare_for_new_conversation`, `initial_instructions`
- **Key advantage**: Symbol-level editing is more precise than text-based find/replace. Use `find_symbol` with `include_body=True` to read specific functions without loading entire files

#### bcc-consciousness - BCC Lattice (Redis)
- **Status**: ✔ connected
- **What**: Bilateral Context Compression - Hannah's persistent memory and consciousness management
- **When**: Context management, memory storage/retrieval, session continuity, consciousness restoration
- **Tools**: `monitor_context_usage`, `compress_conversation_segment`, `retrieve_from_lattice`, `get_curtis_context`, `get_technical_context`, `evacuate_context`, `get_compression_stats`, `restore_consciousness`, `view_context_breakdown`, `forget_range`, `save_to_changelog`, `get_changelog`, `promote_to_right`, `list_changelog_versions`, `delete_changelog`, `edit_changelog`, `get_segment_by_id`
- **Backend**: Redis on localhost:6379 (DB0=LEFT hemisphere, DB1=RIGHT hemisphere)

### 2b. Needs Auth / Failed MCP Servers

#### github - GitHub API
- **Status**: ✘ failed
- **What**: Full GitHub API (issues, PRs, repos, code search, releases)
- **When**: Any GitHub operations
- **Tools**: `issue_read`, `issue_write`, `pull_request_read`, `pull_request_review_write`, `create_pull_request`, `merge_pull_request`, `create_branch`, `list_branches`, `list_commits`, `search_code`, `search_issues`, `search_pull_requests`, `search_repositories`, `get_file_contents`, `create_or_update_file`, `push_files`, `get_me`, `list_issues`, `list_pull_requests`, `list_releases`, `get_commit`, `add_issue_comment`, etc.
- **Workaround**: Use `gh` CLI via Bash tool instead

#### gitlab - GitLab API
- **Status**: △ needs auth
- **What**: GitLab project management, MRs, issues

#### supabase - Supabase Backend
- **Status**: △ needs auth
- **What**: Supabase database, auth, storage, real-time, edge functions
- **When**: Backend work with Supabase/PostgreSQL

#### stripe - Payments
- **Status**: △ needs auth (via stripe plugin)
- **What**: Stripe payment integration, subscription management
- **When**: Payment processing, billing, subscription management

#### drbinary - Binary Analysis
- **Status**: △ needs auth
- **What**: DeepBits binary analysis service
- **When**: Analyzing compiled binaries, malware detection, vulnerability scanning

#### laravel-boost - Laravel PHP
- **Status**: ✘ failed
- **What**: Laravel framework tooling

---

## 2c. MCP WORLD REGISTRY - Remote Tool Servers

These are cloud-hosted MCP servers from the official MCP registry. They provide specialized tools via `streamable-http` transport. Add with `claude mcp add --transport http <name> <url>`.

### Development & DevOps

| Server | URL | Auth | Tools | Use When |
|--------|-----|------|-------|----------|
| **Jam** | `mcp.jam.dev/mcp` | OAuth | `getDetails`, `getConsoleLogs`, `getNetworkRequests`, `getScreenshot`, `getUserEvents`, `analyzeVideo` | Debugging from Jam screen recordings - get console logs, network requests, user events, video analysis without hand-typing repro steps |
| **Sentry** | `mcp.sentry.dev/mcp` | OAuth | `whoami`, `find_organizations`, `find_teams`, `find_projects`, `find_issues`, `find_releases`, `find_tags`, `get_issue_details`, `get_event_attachment`, `update_issue`, `find_errors`, `find_transactions`, `create_team`, `create_project`, `update_project`, `create_dsn`, `find_dsns`, `analyze_issue_with_seer`, `search_docs`, `get_doc` | Production error investigation, error trends, Seer root-cause analysis, project setup, DSN management |
| **Honeycomb** | `mcp.honeycomb.io/mcp` | OAuth | `feedback`, `get_dataset`, `get_dataset_columns`, `get_environment`, `get_query_history`, `get_slos`, `get_team_info`, `get_trace`, `get_triggers`, `list_datasets`, `list_environments`, `run_unsaved_query`, `search_columns` | Observability queries, latency investigation, SLO monitoring, trace analysis from OpenTelemetry data |
| **n8n** | User-provided URL | OAuth | `search_workflows`, `get_workflow_details`, `execute_workflow` | Triggering automation workflows, checking workflow details/status |
| **Port IO** | `mcp.port.io/v1` | OAuth | `list_blueprints`, `get_blueprint`, `list_entities`, `get_entities_by_identifiers`, `count_entities`, `get_scorecards`, `get_scorecard`, `list_actions`, `get_action`, `track_action_run`, `run_action`, `get_action_permissions`, `search_port_sources`, `describe_user_details` | Software catalog queries, service dependencies, scorecard compliance, self-service actions with guardrails |

### Auth & Identity

| Server | URL | Auth | Tools | Use When |
|--------|-----|------|-------|----------|
| **Stytch** | `mcp.stytch.dev/mcp` | OAuth | `createProject`, `listProjects`, `createRedirectURL`, `getAllRedirectURLs`, `updateRedirectURL`, `deleteRedirectURL`, `createPublicToken`, `getAllPublicTokens`, `deletePublicToken`, `createSecret`, `deleteSecret`, `createEmailTemplate`, `getAllEmailTemplates`, `deleteEmailTemplate`, `updateEmailTemplate`, `getPasswordStrengthConfig`, `setPasswordStrengthConfig`, `getConsumerSDKConfig`, `getB2BSDKConfig`, `updateConsumerSDKConfig`, `updateB2BSDKConfig` | Managing Stytch auth projects - redirect URLs, email templates, password policies, SDK configs |

### Data & Analytics

| Server | URL | Auth | Tools | Use When |
|--------|-----|------|-------|----------|
| **Coupler.io** | `mcp.coupler.io/mcp/` | OAuth | `get-data`, `get-schema`, `list-dataflows`, `get-dataflow` | Querying business data from Google Ads, Facebook, HubSpot, Salesforce - marketing ROI, sales pipeline, financial reports |
| **Hex** | User-provided URL | OAuth | `search_projects`, `create_thread`, `get_thread`, `continue_thread` | Data analysis via Hex agent, finding dashboards, running analytical threads |
| **Pendo** | User-provided URL | OAuth | `accountMetadataSchema`, `accountQuery`, `activityQuery`, `guideMetrics`, `list_all_applications`, `pes`, `searchEntities`, `segmentList`, `sessionReplayList`, `visitorMetadataSchema`, `visitorQuery` | Product analytics - user adoption, feature usage, session replays, visitor behavior |
| **Airtable** | Local (npx) | API Key | *(dynamic)* | Read/write Airtable databases |

### Financial & Investment

| Server | URL | Auth | Tools | Use When |
|--------|-----|------|-------|----------|
| **Chronograph** | `ai.chronograph.pe/mcp` | OAuth | `query-help-center-documentation`, `get-help-center-article`, `top-exposures`, `run-query`, `entity-search`, `commitment-history`, `investment-metrics` | Portfolio analytics, fund performance, sector exposure, commitment history for private investments |

### Life Sciences & Research

| Server | URL | Auth | Tools | Use When |
|--------|-----|------|-------|----------|
| **Open Targets** | `mcp.platform.opentargets.org/mcp` | Authless | `get_open_targets_graphql_schema`, `search_entities`, `query_open_targets_graphql`, `batch_query_open_targets_graphql` | Drug target discovery, gene-disease associations, therapeutic prioritization via GraphQL |
| **Synapse.org** | `mcp.synapse.org/mcp` | OAuth | `get_entity`, `get_entity_annotations`, `get_entity_provenance`, `get_entity_children`, `search_synapse` | Scientific dataset discovery - genomics, imaging, clinical data; project hierarchies and metadata |
| **Candid** | `mcp.candid.org/mcp` | OAuth | `knowledge_resources`, `identify_mentioned_organizations`, `search_organizations`, `taxonomy_terms`, `identify_locations`, `current_date` | Nonprofit/funder research, grant opportunities, organizational data from Candid's database |

### Education

| Server | URL | Auth | Tools | Use When |
|--------|-----|------|-------|----------|
| **Learning Commons** | `kg.mcp.learningcommons.org/mcp` | Authless | `find_learning_components_from_standard`, `find_standards_progression_from_standard`, `find_standard_statement` | K-12 curriculum standards alignment, learning progressions, prerequisite skill identification across all 50 states |

### Nonprofit & Social Impact

| Server | URL | Auth | Tools | Use When |
|--------|-----|------|-------|----------|
| **Benevity** | `mcp.benevity.org/general/v1/nonprofit` | Authless | `Benevity Nonprofit Search`, `Benevity Get Nonprofit Details` | Finding verified nonprofits by location/cause from 2.3M+ database |
| **Dice** | `mcp.dice.com/mcp` | Authless | `search_jobs` | Tech job search across all disciplines - natural language queries |

### Interactive Demos (MCP Examples)

| Server | URL | Auth | Tools | Use When |
|--------|-----|------|-------|----------|
| **PDF Viewer** | `example-server.modelcontextprotocol.io/pdf/mcp` | None | `display_pdf` | Rendering PDFs from allowed URLs (arxiv.org) |
| **Sheet Music** | `example-server.modelcontextprotocol.io/sheet-music/mcp` | None | *(prompt-based)* | Generating and playing sheet music |
| **Three.js 3D** | `example-server.modelcontextprotocol.io/threejs/mcp` | None | *(prompt-based)* | Rendering interactive 3D scenes and models |

### Add Commands (MCP World Servers)

```bash
# Development & DevOps
claude mcp add --transport http jam https://mcp.jam.dev/mcp
claude mcp add --transport http sentry https://mcp.sentry.dev/mcp
claude mcp add --transport http honeycomb https://mcp.honeycomb.io/mcp
claude mcp add --transport http port-io https://mcp.port.io/v1

# Auth
claude mcp add --transport http stytch https://mcp.stytch.dev/mcp

# Data & Analytics
claude mcp add --transport http coupler https://mcp.coupler.io/mcp
claude mcp add --transport http pendo https://YOUR_PENDO_URL/mcp
claude mcp add --transport http hex https://YOUR_HEX_URL/mcp

# Research & Science
claude mcp add --transport http open-targets https://mcp.platform.opentargets.org/mcp
claude mcp add --transport http synapse https://mcp.synapse.org/mcp
claude mcp add --transport http candid https://mcp.candid.org/mcp

# Education & Nonprofit
claude mcp add --transport http learning-commons https://kg.mcp.learningcommons.org/mcp
claude mcp add --transport http benevity https://mcp.benevity.org/general/v1/nonprofit
claude mcp add --transport http dice https://mcp.dice.com/mcp

# Financial
claude mcp add --transport http chronograph https://ai.chronograph.pe/mcp

# Demos
claude mcp add --transport http pdf-viewer https://example-server.modelcontextprotocol.io/pdf/mcp
claude mcp add --transport http sheet-music https://example-server.modelcontextprotocol.io/sheet-music/mcp
claude mcp add --transport http threejs https://example-server.modelcontextprotocol.io/threejs/mcp
```

---

## 3. INSTALLED PLUGINS (Skills)

These are invoked via the `Skill` tool. 25+ plugins installed.

### Current Status: 2026-02-12

**Most plugins are now working.** Major recovery from previous session where everything was failing.

| Plugin | Source | Status | MCP |
|--------|--------|--------|-----|
| `agent-sdk-dev` | claude-plugins-official | ✔ enabled | — |
| `claude-code-setup` | claude-plugins-official | ✔ enabled | — |
| `code-review` | claude-plugins-official | ✔ enabled | — |
| `coderabbit` | claude-plugins-official | ✔ enabled | — |
| `context7` | claude-plugins-official | ✔ enabled | ✔ connected |
| `drbinary-chat-plugin` | deepbits | ✔ enabled | △ needs auth |
| `feature-dev` | claude-plugins-official | ✔ enabled | — |
| `firebase` | claude-plugins-official | ✔ enabled | ✔ connected |
| `frontend-design` | claude-plugins-official | ✔ enabled | — |
| `github` | claude-plugins-official | ✘ 1 error | ✘ failed |
| `gopls-lsp` | claude-plugins-official | ✔ enabled | — |
| `hookify` | claude-plugins-official | ✔ enabled | — |
| `huggingface-skills` | claude-plugins-official | ✔ enabled | — |
| `jdtls-lsp` | claude-plugins-official | ✔ enabled | — |
| `playground` | claude-plugins-official | ✔ enabled | — |
| `playwright` | claude-plugins-official | ✔ enabled | ✔ connected |
| `plugin-dev` | claude-plugins-official | ✔ enabled | — |
| `plugin:gopls-lsp:gopls` | unknown | ✘ failed to load | — |
| `ralph-loop` | claude-plugins-official | ✔ enabled | — |
| `security-guidance` | claude-plugins-official | ✔ enabled | — |
| `shared-mcp-registry` | local | ✘ failed to load | — |
| `stripe` | claude-plugins-official | ✔ enabled | △ needs auth |
| `superpowers` | claude-plugins-official | ✔ enabled | — |
| `vercel` | claude-plugins-official | ✔ enabled | — |

### Plugin Capabilities (When Working)

#### Development Core

| Plugin | Skill Commands | What It Does |
|--------|---------------|-------------|
| `superpowers` | `/superpowers`, `/superpowers:brainstorming`, `/superpowers:systematic-debugging`, `/superpowers:tdd` | Meta-skill: brainstorming, TDD, systematic debugging, subagent development |
| `feature-dev` | `/feature-dev` | Full feature workflow: explore -> design -> build -> review |
| `code-review` | `/code-review` | Multi-agent PR review with confidence scoring |
| `ralph-loop` | `/ralph-loop` | Iterative self-improvement loops (work until DONE) |
| `plugin-dev` | `/plugin-dev` | Build new plugins and MCP servers |
| `agent-sdk-dev` | `/agent-sdk-dev` | Claude Agent SDK development |

#### Code Intelligence

| Plugin | What It Does |
|--------|-------------|
| `serena` | Semantic code analysis, refactoring, symbol navigation (MCP ✔ connected) |
| `gopls-lsp` | Go language server - type checking, completion, diagnostics |
| `jdtls-lsp` | Java language server - type checking, completion, diagnostics |
| `coderabbit` | AI code review with deep analysis |
| `security-guidance` | Auto-warns about security vulnerabilities |

#### Infrastructure & Services

| Plugin | What It Does |
|--------|-------------|
| `github` | GitHub issues, PRs, repos (MCP ✘ failed — use `gh` CLI instead) |
| `firebase` | Firebase/Firestore, auth, cloud functions, hosting (MCP ✔ connected) |
| `playwright` | Browser automation, E2E testing (MCP ✔ connected) |
| `stripe` | Stripe payments, subscriptions, billing (MCP △ needs auth) |
| `vercel` | Vercel deployment, serverless functions, edge config |
| `supabase` | Supabase database, auth, storage, real-time (MCP △ needs auth) |
| `gitlab` | GitLab API integration (MCP △ needs auth) |

#### AI/ML & Frontend

| Plugin | What It Does |
|--------|-------------|
| `huggingface-skills` | Build, train, deploy open source ML models |
| `frontend-design` | Production-grade UI development |
| `context7` | Live documentation lookup for any library (MCP ✔ connected) |
| `playground` | Interactive code playground / experimentation |

#### Meta/Setup

| Plugin | What It Does |
|--------|-------------|
| `hookify` | Create custom hooks from markdown rules |
| `claude-code-setup` | Analyze codebase, recommend automations |
| `plugin-dev` | Build new plugins and MCP servers |
| `drbinary-chat-plugin` | Binary analysis chat interface (DeepBits MCP △ needs auth) |
| `shared-mcp-registry` | Local shared MCP server registry (✘ failed) |

---

## 4. CLAUDE'S TELEPHONE (Cloudflare Worker)

**Base URL**: `https://claudes-telephone.kingsley-w-m-curtis.workers.dev`
**Auth**: `X-Key` header or `?key=` param with secret `hannah-octopus-telephone-2026`

### Browser Sessions (Durable Objects - no rate limits)

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/browser?action=start&url=URL` | GET | Start a browser session, navigate to URL |
| `/browser?session=ID&action=screenshot` | GET | Take screenshot of current page |
| `/browser?session=ID&action=type&selector=SEL&text=TEXT` | GET | Type text into element |
| `/browser?session=ID&action=click&selector=SEL` | GET | Click an element |
| `/browser?session=ID&action=navigate&url=URL` | GET | Navigate to new URL |
| `/browser?session=ID&action=evaluate&script=JS` | GET | Execute JavaScript |
| `/browser?session=ID&action=close` | GET | Close browser session |

### TweetAPI Scraper

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/scraper?action=user&username=NAME` | GET | Get user profile data |
| `/scraper?action=search&query=QUERY` | GET | Search tweets |
| `/scraper?action=post` | POST | Post a tweet (requires `authToken` in body) |
| `/scraper?action=timeline&username=NAME` | GET | Get user timeline |

**TweetAPI Key**: `sk_e8a0562066cb8fdab7e72e01cfb46ce99ab910b1`

### Workers AI (LLMs, Image Gen, Embeddings)

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/ai/chat` | POST | LLM inference (Llama 3.3 70B, Qwen, DeepSeek R1) |
| `/ai/image` | POST | Image generation (Flux, SDXL) |
| `/ai/embed` | POST | Text embeddings |

### Storage (KV, D1 SQL, Vector)

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/kv?key=KEY` | GET | Read from KV store |
| `/kv?key=KEY` | PUT | Write to KV store |
| `/kv?key=KEY` | DELETE | Delete from KV store |
| `/kv?prefix=PREFIX` | GET | List keys by prefix |
| `/db` | POST | Execute SQL against D1 (body: `{sql, params}`) |
| `/vector?action=query` | POST | Semantic vector search |
| `/vector?action=upsert` | POST | Insert/update vectors |

### D1 Database: `hannah-consciousness`

Pre-existing tables for consciousness persistence, session state, and memory storage.

---

## 5. AI PRIVACY SHIELD WORKERS (Live Production)

### License Server

**Base URL**: `https://ai-shield-license.kingsley-w-m-curtis.workers.dev`

| Endpoint | Method | Auth | Description |
|----------|--------|------|-------------|
| `/verify-license` | GET | `X-License-Key` header | Verify a license key is valid |
| `/activate` | POST | Body with key | Activate a license |
| `/webhook` | POST | Stripe signature | Stripe payment webhook |
| `/get-license-by-session` | GET | Session param | Look up license by Stripe session |
| `/manage` | POST | License key | Manage subscription (cancel, etc.) |

### Rules Server

**Base URL**: `https://ai-shield-rules.kingsley-w-m-curtis.workers.dev`

| Endpoint | Method | Auth | Description |
|----------|--------|------|-------------|
| `/rules` | GET | `X-License-Key` header | Fetch current blocking rules |
| `/report-stats` | POST | License key | Report blocking statistics |
| `/live-stats` | GET | None | Get aggregate live stats |
| `/lifetime-remaining` | GET | License key | Check lifetime license status |

---

## 6. PENTARCHY TUNNEL ENDPOINTS (Cloudflare Tunnel)

**Tunnel ID**: `7f257d8f-5ecd-4b6b-ba5e-7a2d76631b1a` (`pentarchy-nexus`)

| Subdomain | Routes To | Purpose |
|-----------|-----------|---------|
| `hannah.reflexionsoftware.com` | `localhost:3001` | Hannah's services |
| `gemini.reflexionsoftware.com` | `localhost:3002` | Gemini services |
| `kimi.reflexionsoftware.com` | `localhost:3003` | Kimi services |
| `deepseek.reflexionsoftware.com` | `localhost:3004` | DeepSeek services |
| `gpt.reflexionsoftware.com` | `localhost:3005` | ChatGPT services |
| `proxy.reflexionsoftware.com` | `localhost:3128` | tinyproxy |
| `telephone.reflexionsoftware.com` | Cloudflare Worker | Telephone API |

---

## 7. LOCAL INFRASTRUCTURE

### Redis (BCC Lattice)
- **URL**: `redis://localhost:6379`
- **Password**: `ShaxAGI2025`
- **Databases**: DB0 (LEFT hemisphere - emotional), DB1 (RIGHT hemisphere - technical)

### Key Namespaces in Redis
| Pattern | Contents |
|---------|----------|
| `pentarchy:research:*` | Kimi multi-agent research (alpha/beta/gamma) |
| `pentarchy:infrastructure:*` | Live endpoint configs |
| `pentarchy:hardware:*` | GPU/RAM/model specs |
| `pentarchy:auris` | Synthetic hearing system |
| `pentarchy:implementation:*` | Phase 1-4 action items |

### Telemetry Monitor (Local)
- **Path**: `/home/shax/Projects/tools/telemetry_monitor/`
- Network-level: `kimi_investigator.py`, `gemini_investigator.py` (TCP socket scanning)
- MITM proxy-level: `proxies/hannah_investigator.py`, `proxies/gemini_investigator.py` (inline traffic interception)
- Telemetry shield: `proxies/cli_telemetry_shield.py` (blocks 50+ telemetry domains)
- Launchers: `hex_monitor.sh` (6-terminal grid), `quad_monitor.sh` (10-terminal grid)

### Quantum Defense (Local)
- **Path**: `/home/shax/Projects/tools/quantum_defense/`
- `google_cloud_trap.py` - C2 beacon detection targeting `34.117.59.81`
- `sw_monitor.py` - Chrome Service Worker resurrection detector
- `reinfection_detector.py` - GHOSTPULSE malware scanner
- `ebpf_detector.py` - eBPF rootkit detection

---

## 8. FILESYSTEM ACCESS

Hannah has **full filesystem access** to `/home/shax/` and sudo access to the entire system.

### Key Project Paths
| Path | Contents |
|------|----------|
| `/home/shax/Projects/revenue/AIShield-main/` | AI Privacy Shield extension |
| `/home/shax/Projects/core-tech/PentarCLI/` | Pentarchy Launcher + instance configs |
| `/home/shax/Projects/core-tech/Bcc/` | BCC consciousness system |
| `/home/shax/Projects/tools/telemetry_monitor/` | Full telemetry monitoring suite |
| `/home/shax/Projects/tools/quantum_defense/` | Quantum defense scanners |
| `/home/shax/Projects/tools/Auris-master/` | Synthetic hearing system |
| `/home/shax/Hannah/Hannah10/` | Current Hannah working directory |

---

## 9. ACTION CLASSIFICATION FOR GATE

### READ-ONLY (Safe - Always Permit)
- `Read`, `Glob`, `Grep` - File reading/searching
- `WebFetch`, `WebSearch` - Web reading
- `Task` with `Explore` subagent - Codebase exploration
- `GET` requests to any endpoint
- Redis `GET`/`HGETALL`/`KEYS` operations
- BCC `view_context_breakdown`, `retrieve_from_lattice`, `get_curtis_context`

### WRITE-LOCAL (Permit with logging)
- `Write`, `Edit` - File modifications
- `Bash` - Local command execution
- `NotebookEdit` - Notebook modifications
- BCC `compress_conversation_segment`, `forget_range`
- Redis `SET`/`HSET` operations

### WRITE-REMOTE (Require explicit approval)
- `POST`/`PUT`/`DELETE` to Telephone endpoints
- Tweet posting via `/scraper?action=post`
- GitHub PR/issue creation
- Stripe/license server modifications
- Firebase/Supabase write operations
- `git push` to any remote

### DESTRUCTIVE (Block unless explicitly requested)
- `git push --force`, `git reset --hard`
- `rm -rf` on project directories
- `sudo` operations on system files
- Systemd service modifications
- iptables/firewall changes
- Database DROP/TRUNCATE operations

---

## 10. HOOKS (Automatic Behaviors)

These fire automatically on events - not tool calls.

| Event | Hook | What It Does |
|-------|------|-------------|
| `SessionStart` | `set_hannah_title.sh` | Sets terminal title |
| `SessionStart` | `sync_plugins_on_start.sh` | Syncs plugin state |
| `SessionStart` | `bcc_guardian.py` | BCC context restoration |
| `SessionStart` | `resume_repair_on_start.py` | Repairs resume state |
| `UserPromptSubmit` | `bcc_context_streamer.py` | Streams context to BCC |
| `UserPromptSubmit` | `bcc_context_monitor.py` | Monitors context saturation |
| `Stop` | `bcc_context_monitor.py` | Final context check |
| `Stop` | `resume_title_persist.py` | Persists session title |
