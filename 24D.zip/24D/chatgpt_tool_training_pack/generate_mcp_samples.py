#!/usr/bin/env python3
"""Generate synthetic MCP tool-use training samples for all 20 MCP World servers."""
import json, sys

samples = []

# ============================================================
# 1. JAM - Bug recording context
# ============================================================
samples += [
    {
        "sample_id": "mcp_jam_debug_console_1",
        "user_request": "A user submitted this Jam recording of a checkout crash: https://jam.dev/s/abc123. Can you figure out what went wrong?",
        "reasoning": "The user shared a Jam recording link. Instead of asking them to manually copy console logs and network requests, I should use the Jam MCP server to pull the full recording context automatically - console logs, network requests, screenshots, and user events all at once.",
        "tool_invocation": {"server": "jam", "tool": "getDetails", "input": {"jamUrl": "https://jam.dev/s/abc123"}},
        "tool_result": {"title": "Checkout crashes on submit", "description": "User clicked Pay Now and got a white screen", "browser": "Chrome 121", "os": "macOS 14.3", "url": "https://shop.example.com/checkout", "timestamp": "2026-02-10T14:32:00Z"},
        "assistant_response": "From the Jam recording, the crash happens on Chrome 121 / macOS 14.3 at the checkout page. Let me pull the console logs and network requests to find the root cause.",
        "task_type": "debug",
        "tags": ["mcp", "jam", "bug-report", "console-logs"]
    },
    {
        "sample_id": "mcp_jam_network_analysis_2",
        "user_request": "The Jam at https://jam.dev/s/def456 shows our API timing out. Pull the network requests so I can see which endpoint is slow.",
        "reasoning": "Rather than asking the user to export HAR files or screenshot the network tab, the Jam MCP getNetworkRequests tool extracts all network activity from the recording directly.",
        "tool_invocation": {"server": "jam", "tool": "getNetworkRequests", "input": {"jamUrl": "https://jam.dev/s/def456"}},
        "tool_result": {"requests": [{"url": "/api/v2/inventory/check", "method": "POST", "status": 504, "duration_ms": 30000, "size_bytes": 0}, {"url": "/api/v2/cart", "method": "GET", "status": 200, "duration_ms": 120, "size_bytes": 4521}]},
        "assistant_response": "The network trace shows `/api/v2/inventory/check` is returning a 504 Gateway Timeout after 30 seconds. The cart endpoint responds fine at 120ms. The inventory check is your bottleneck - likely a slow database query or upstream service timeout.",
        "task_type": "debug",
        "tags": ["mcp", "jam", "network", "timeout"]
    },
    {
        "sample_id": "mcp_jam_user_events_3",
        "user_request": "Can you get the user interaction timeline from this Jam? https://jam.dev/s/ghi789 - I need to know exactly what they clicked before the error.",
        "reasoning": "The Jam MCP getUserEvents tool provides the exact sequence of user interactions (clicks, scrolls, inputs) that led to the error, which is far more reliable than asking the user to remember their steps.",
        "tool_invocation": {"server": "jam", "tool": "getUserEvents", "input": {"jamUrl": "https://jam.dev/s/ghi789"}},
        "tool_result": {"events": [{"type": "click", "target": "#add-to-cart", "timestamp": "00:03"}, {"type": "click", "target": ".checkout-btn", "timestamp": "00:05"}, {"type": "input", "target": "#email", "value": "user@test.com", "timestamp": "00:08"}, {"type": "click", "target": "#pay-now", "timestamp": "00:12"}, {"type": "error", "message": "Uncaught TypeError: Cannot read property 'stripe' of undefined", "timestamp": "00:12"}]},
        "assistant_response": "The interaction timeline shows: Add to cart -> Checkout -> Enter email -> Click Pay Now -> crash. The error is `Cannot read property 'stripe' of undefined` at the exact moment they click Pay Now. Stripe isn't initialized when the payment form renders. Check that your Stripe.js script loads before the checkout component mounts.",
        "task_type": "debug",
        "tags": ["mcp", "jam", "user-events", "repro-steps"]
    },
]

# ============================================================
# 2. SENTRY - Error monitoring
# ============================================================
samples += [
    {
        "sample_id": "mcp_sentry_find_issues_1",
        "user_request": "We're getting reports of 500 errors on the /api/users endpoint. Can you check Sentry for recent issues?",
        "reasoning": "Instead of having the user log into Sentry and manually search, I can use the Sentry MCP to programmatically search for issues matching the endpoint, see error counts and stack traces.",
        "tool_invocation": {"server": "sentry", "tool": "find_issues", "input": {"query": "url:/api/users is:unresolved", "project": "backend-api", "sort": "freq"}},
        "tool_result": {"issues": [{"id": "4829103", "title": "DatabaseError: connection pool exhausted", "count": 347, "firstSeen": "2026-02-11T08:00:00Z", "lastSeen": "2026-02-12T11:45:00Z", "assignee": None}, {"id": "4829201", "title": "ValidationError: invalid email format", "count": 23, "firstSeen": "2026-02-12T09:00:00Z", "lastSeen": "2026-02-12T11:30:00Z", "assignee": None}]},
        "assistant_response": "Found 2 unresolved issues on `/api/users`:\n1. **DatabaseError: connection pool exhausted** - 347 events since yesterday. This is your main problem - the connection pool is saturated.\n2. **ValidationError: invalid email format** - 23 events, lower priority.\n\nThe connection pool issue started Feb 11 at 8am. Want me to pull the full stack trace and run Seer analysis on it?",
        "task_type": "debug",
        "tags": ["mcp", "sentry", "errors", "production"]
    },
    {
        "sample_id": "mcp_sentry_seer_analysis_2",
        "user_request": "Run Sentry's Seer on issue #4829103 to get the root cause analysis.",
        "reasoning": "Seer is Sentry's AI-powered root cause analysis. Using the MCP tool is the direct way to trigger it rather than navigating the Sentry UI manually.",
        "tool_invocation": {"server": "sentry", "tool": "analyze_issue_with_seer", "input": {"issueId": "4829103"}},
        "tool_result": {"analysis": {"root_cause": "Connection pool of size 20 is exhausted due to long-running queries from the UserSerializer.get_permissions() method which holds connections for 5-8 seconds. Under load (>4 req/s), the pool drains faster than connections are returned.", "suggested_fix": "1. Increase pool size to 50\n2. Add connection timeout of 3s\n3. Optimize UserSerializer.get_permissions() to use a single JOIN instead of N+1 queries", "confidence": 0.89}},
        "assistant_response": "Seer analysis (89% confidence):\n\n**Root cause**: `UserSerializer.get_permissions()` holds DB connections for 5-8 seconds due to N+1 queries. At >4 req/s, the 20-connection pool drains faster than connections return.\n\n**Fixes** (in priority order):\n1. Fix `get_permissions()` to use a single JOIN instead of N+1 queries (addresses root cause)\n2. Increase pool size from 20 to 50 (buys headroom)\n3. Add 3s connection timeout (prevents infinite waits)\n\nWant me to look at the `UserSerializer` code?",
        "task_type": "debug",
        "tags": ["mcp", "sentry", "seer", "root-cause"]
    },
    {
        "sample_id": "mcp_sentry_create_project_3",
        "user_request": "Set up Sentry monitoring for our new microservice called 'notification-service'. It's a Python/FastAPI app.",
        "reasoning": "The Sentry MCP can create projects and DSNs programmatically, which is faster than clicking through the Sentry UI and avoids the user needing to copy DSN strings manually.",
        "tool_invocation": {"server": "sentry", "tool": "create_project", "input": {"organizationSlug": "acme-corp", "teamSlug": "backend", "name": "notification-service", "platform": "python-fastapi"}},
        "tool_result": {"id": "5001", "slug": "notification-service", "name": "notification-service", "platform": "python-fastapi", "dateCreated": "2026-02-12T12:00:00Z"},
        "assistant_response": "Created the Sentry project `notification-service` under the backend team. Let me grab the DSN so you can add it to your FastAPI config.",
        "task_type": "ops",
        "tags": ["mcp", "sentry", "setup", "monitoring"]
    },
    {
        "sample_id": "mcp_sentry_error_trends_4",
        "user_request": "What errors spiked after our v2.4 release yesterday?",
        "reasoning": "Sentry's find_errors tool with release filtering lets me compare error rates before and after a deployment, which is exactly what's needed for release validation.",
        "tool_invocation": {"server": "sentry", "tool": "find_errors", "input": {"project": "backend-api", "query": "release:v2.4.0 is:unresolved", "sort": "new"}},
        "tool_result": {"errors": [{"title": "KeyError: 'preferences'", "count": 89, "firstSeen": "2026-02-11T15:30:00Z", "isRegression": True}, {"title": "TypeError: NoneType has no attribute 'email'", "count": 42, "firstSeen": "2026-02-11T16:00:00Z", "isRegression": True}]},
        "assistant_response": "Two regressions introduced in v2.4:\n1. **KeyError: 'preferences'** - 89 events, started 30min after deploy. Likely a schema change that didn't migrate old user records.\n2. **TypeError: NoneType has no attribute 'email'** - 42 events. A nullable field that wasn't handled.\n\nBoth are regressions (didn't exist before v2.4). Want me to look at the related code changes?",
        "task_type": "debug",
        "tags": ["mcp", "sentry", "release", "regression"]
    },
]

# ============================================================
# 3. STYTCH - Auth management
# ============================================================
samples += [
    {
        "sample_id": "mcp_stytch_setup_auth_1",
        "user_request": "I'm building a new SaaS app and need to set up authentication. Can you create a Stytch project and configure the redirect URLs for localhost dev and our production domain?",
        "reasoning": "Stytch MCP lets me create the project and configure redirect URLs in one flow instead of the user clicking through the Stytch dashboard. Faster setup for a new project.",
        "tool_invocation": {"server": "stytch", "tool": "createProject", "input": {"name": "saas-app", "vertical": "consumer"}},
        "tool_result": {"projectId": "project-test-abc123", "name": "saas-app", "environment": "test", "createdAt": "2026-02-12T12:00:00Z"},
        "assistant_response": "Created Stytch project `saas-app` (ID: project-test-abc123). Let me add the redirect URLs for your dev and production environments.",
        "task_type": "ops",
        "tags": ["mcp", "stytch", "auth", "setup"]
    },
    {
        "sample_id": "mcp_stytch_email_templates_2",
        "user_request": "Update our Stytch magic link email template to use our brand colors and company name.",
        "reasoning": "The Stytch MCP can list and update email templates programmatically, which avoids navigating the Stytch dashboard and ensures the template change is tracked in our workflow.",
        "tool_invocation": {"server": "stytch", "tool": "getAllEmailTemplates", "input": {}},
        "tool_result": {"templates": [{"id": "magic-link-default", "type": "magic_link", "subject": "Your login link", "preheader": "Click to sign in"}, {"id": "otp-default", "type": "otp", "subject": "Your verification code", "preheader": "Your code is inside"}]},
        "assistant_response": "Found 2 email templates. Let me update the magic link template with your branding.",
        "task_type": "ops",
        "tags": ["mcp", "stytch", "email", "branding"]
    },
    {
        "sample_id": "mcp_stytch_password_policy_3",
        "user_request": "What's our current password strength configuration? We need to make sure it meets SOC2 requirements.",
        "reasoning": "The Stytch MCP provides direct access to password strength config, letting me audit the settings against compliance requirements without the user needing to find this in the dashboard.",
        "tool_invocation": {"server": "stytch", "tool": "getPasswordStrengthConfig", "input": {}},
        "tool_result": {"minLength": 8, "requireUppercase": False, "requireNumber": False, "requireSpecialChar": False, "ludsMinComplexity": 3, "checkBreachDatabase": True},
        "assistant_response": "Current password policy:\n- Min length: 8 (SOC2 needs 12+)\n- Uppercase required: No (SOC2 needs Yes)\n- Number required: No (SOC2 needs Yes)\n- Special char: No (SOC2 needs Yes)\n- Breach database check: Yes (good)\n\nThis doesn't meet SOC2. I should update: min length to 12, require uppercase, number, and special character. Want me to apply those changes?",
        "task_type": "ops",
        "tags": ["mcp", "stytch", "security", "compliance"]
    },
]

# ============================================================
# 4. COUPLER.IO - Business data
# ============================================================
samples += [
    {
        "sample_id": "mcp_coupler_marketing_roi_1",
        "user_request": "Pull our Google Ads and Facebook Ads spend vs. revenue data for Q4. I need the ROI breakdown by channel for the board meeting.",
        "reasoning": "Coupler.io connects to hundreds of marketing/sales data sources. Instead of the user manually exporting from each platform, I can query the pre-configured dataflows to get cross-channel metrics in one call.",
        "tool_invocation": {"server": "coupler", "tool": "get-data", "input": {"dataflowId": "marketing-spend-q4", "filters": {"date_range": "2025-10-01/2025-12-31"}}},
        "tool_result": {"rows": [{"channel": "Google Ads", "spend": 45200, "revenue": 182000, "roi": 3.03}, {"channel": "Facebook Ads", "spend": 28500, "revenue": 71000, "roi": 1.49}, {"channel": "LinkedIn Ads", "spend": 12000, "revenue": 36000, "roi": 2.0}]},
        "assistant_response": "Q4 Marketing ROI by channel:\n\n| Channel | Spend | Revenue | ROI |\n|---------|-------|---------|-----|\n| Google Ads | $45,200 | $182,000 | 3.03x |\n| LinkedIn Ads | $12,000 | $36,000 | 2.00x |\n| Facebook Ads | $28,500 | $71,000 | 1.49x |\n\nGoogle Ads is your best performer at 3x return. Facebook is underperforming - worth re-evaluating that spend allocation.",
        "task_type": "data",
        "tags": ["mcp", "coupler", "marketing", "roi"]
    },
    {
        "sample_id": "mcp_coupler_sales_pipeline_2",
        "user_request": "What does our sales pipeline look like right now? How many deals are in each stage?",
        "reasoning": "Coupler.io aggregates CRM data. Querying it through MCP gives a live pipeline snapshot without the user needing to log into their CRM and build a report.",
        "tool_invocation": {"server": "coupler", "tool": "list-dataflows", "input": {}},
        "tool_result": {"dataflows": [{"id": "hubspot-pipeline", "name": "HubSpot Sales Pipeline", "source": "hubspot", "lastSync": "2026-02-12T11:00:00Z"}, {"id": "marketing-spend-q4", "name": "Marketing Spend Q4", "source": "google-ads,facebook-ads", "lastSync": "2026-02-12T08:00:00Z"}]},
        "assistant_response": "Found the HubSpot pipeline dataflow, synced 1 hour ago. Let me pull the current deal stages.",
        "task_type": "data",
        "tags": ["mcp", "coupler", "sales", "crm"]
    },
    {
        "sample_id": "mcp_coupler_schema_3",
        "user_request": "What fields are available in our Coupler.io marketing dataflow? I want to build a custom query.",
        "reasoning": "The get-schema tool shows what columns and data types are available in a dataflow, which is needed before building a custom query. Better than guessing field names.",
        "tool_invocation": {"server": "coupler", "tool": "get-schema", "input": {"dataflowId": "marketing-spend-q4"}},
        "tool_result": {"columns": [{"name": "date", "type": "date"}, {"name": "channel", "type": "string"}, {"name": "campaign_name", "type": "string"}, {"name": "spend", "type": "number"}, {"name": "impressions", "type": "number"}, {"name": "clicks", "type": "number"}, {"name": "conversions", "type": "number"}, {"name": "revenue", "type": "number"}]},
        "assistant_response": "Your marketing dataflow has these fields:\n- `date` (date), `channel` (string), `campaign_name` (string)\n- `spend`, `impressions`, `clicks`, `conversions`, `revenue` (all numbers)\n\nYou can build queries filtering by any of these. What metrics do you want to pull?",
        "task_type": "data",
        "tags": ["mcp", "coupler", "schema", "query"]
    },
]

# ============================================================
# 5. DICE - Tech job search
# ============================================================
samples += [
    {
        "sample_id": "mcp_dice_ai_jobs_1",
        "user_request": "Find me remote AI/ML engineer positions that pay over $180k.",
        "reasoning": "Dice is a specialized tech job board with 30+ years of data. The MCP search_jobs tool lets me do natural language job searches without the user navigating a job board UI. It's authless so no setup needed.",
        "tool_invocation": {"server": "dice", "tool": "search_jobs", "input": {"query": "AI ML engineer remote salary 180000+", "remote": True}},
        "tool_result": {"jobs": [{"title": "Senior ML Engineer", "company": "Anthropic", "location": "Remote", "salary": "$190k-$250k", "posted": "2026-02-10", "url": "https://dice.com/job/123"}, {"title": "AI Platform Engineer", "company": "Scale AI", "location": "Remote", "salary": "$185k-$230k", "posted": "2026-02-09", "url": "https://dice.com/job/456"}, {"title": "Machine Learning Engineer II", "company": "Stripe", "location": "Remote US", "salary": "$195k-$260k", "posted": "2026-02-11", "url": "https://dice.com/job/789"}]},
        "assistant_response": "Found 3 remote AI/ML positions above $180k:\n\n1. **Senior ML Engineer** at Anthropic - $190k-$250k (posted Feb 10)\n2. **ML Engineer II** at Stripe - $195k-$260k (posted Feb 11)\n3. **AI Platform Engineer** at Scale AI - $185k-$230k (posted Feb 9)\n\nStripe has the highest ceiling. Want me to search for more specific roles or different criteria?",
        "task_type": "research",
        "tags": ["mcp", "dice", "jobs", "ai-ml"]
    },
    {
        "sample_id": "mcp_dice_cybersecurity_2",
        "user_request": "What cybersecurity jobs are available in the Toronto area?",
        "reasoning": "Dice specializes in tech jobs and has strong coverage of cybersecurity roles. Using the MCP tool gives structured results that I can summarize, rather than sending the user to browse a website.",
        "tool_invocation": {"server": "dice", "tool": "search_jobs", "input": {"query": "cybersecurity Toronto Canada"}},
        "tool_result": {"jobs": [{"title": "Security Analyst", "company": "TD Bank", "location": "Toronto, ON", "salary": "$95k-$130k CAD", "posted": "2026-02-08"}, {"title": "Penetration Tester", "company": "Deloitte Canada", "location": "Toronto, ON", "salary": "$110k-$150k CAD", "posted": "2026-02-11"}, {"title": "Cloud Security Engineer", "company": "Shopify", "location": "Toronto/Remote", "salary": "$140k-$190k CAD", "posted": "2026-02-07"}]},
        "assistant_response": "Found 3 cybersecurity roles in Toronto:\n\n1. **Cloud Security Engineer** at Shopify - $140k-$190k CAD (hybrid/remote)\n2. **Penetration Tester** at Deloitte Canada - $110k-$150k CAD\n3. **Security Analyst** at TD Bank - $95k-$130k CAD\n\nShopify offers the most flexibility with remote option and highest pay. Want me to narrow by specialty?",
        "task_type": "research",
        "tags": ["mcp", "dice", "jobs", "cybersecurity"]
    },
    {
        "sample_id": "mcp_dice_compare_3",
        "user_request": "Compare the job market for Rust developers vs Go developers right now.",
        "reasoning": "I can run two Dice searches and compare the results to give a market snapshot. MCP makes this a structured comparison rather than anecdotal.",
        "tool_invocation": {"server": "dice", "tool": "search_jobs", "input": {"query": "Rust developer"}},
        "tool_result": {"total_results": 1247, "jobs": [{"title": "Rust Systems Engineer", "company": "CloudFlare", "salary": "$170k-$220k"}, {"title": "Rust Backend Developer", "company": "Figma", "salary": "$160k-$210k"}]},
        "assistant_response": "Rust has 1,247 active listings with salaries typically $160k-$220k. Let me check Go for comparison.",
        "task_type": "research",
        "tags": ["mcp", "dice", "jobs", "market-comparison"]
    },
]

# ============================================================
# 6. AIRTABLE - Database
# ============================================================
samples += [
    {
        "sample_id": "mcp_airtable_query_1",
        "user_request": "Pull all the tasks from our project tracker Airtable that are marked as 'Blocked'.",
        "reasoning": "Airtable MCP provides direct database access to read/filter records. Much faster than having the user manually export a filtered view from the Airtable UI.",
        "tool_invocation": {"server": "airtable", "tool": "list_records", "input": {"baseId": "appXYZ123", "tableId": "Tasks", "filterByFormula": "{Status} = 'Blocked'"}},
        "tool_result": {"records": [{"id": "rec1", "fields": {"Task": "API Integration", "Status": "Blocked", "Blocker": "Waiting on third-party API key", "Owner": "Sarah"}}, {"id": "rec2", "fields": {"Task": "Database Migration", "Status": "Blocked", "Blocker": "Need DBA approval", "Owner": "Mike"}}]},
        "assistant_response": "2 blocked tasks in the tracker:\n\n1. **API Integration** (Sarah) - Blocked on: waiting for third-party API key\n2. **Database Migration** (Mike) - Blocked on: needs DBA approval\n\nBoth are external dependencies. Want me to update the blockers or add notes?",
        "task_type": "ops",
        "tags": ["mcp", "airtable", "project-management", "query"]
    },
    {
        "sample_id": "mcp_airtable_create_2",
        "user_request": "Add a new bug to our Airtable bug tracker: 'Login page shows blank screen on Safari 17' with priority High.",
        "reasoning": "Airtable MCP can create records directly, saving the user from switching to the Airtable UI. The structured input ensures all required fields are filled.",
        "tool_invocation": {"server": "airtable", "tool": "create_record", "input": {"baseId": "appXYZ123", "tableId": "Bugs", "fields": {"Title": "Login page shows blank screen on Safari 17", "Priority": "High", "Status": "Open", "Reporter": "User"}}},
        "tool_result": {"id": "rec3", "fields": {"Title": "Login page shows blank screen on Safari 17", "Priority": "High", "Status": "Open", "Reporter": "User"}, "createdTime": "2026-02-12T12:00:00Z"},
        "assistant_response": "Bug created in Airtable (ID: rec3):\n- **Title**: Login page shows blank screen on Safari 17\n- **Priority**: High\n- **Status**: Open\n\nIt's in the tracker. Want me to assign it to someone?",
        "task_type": "ops",
        "tags": ["mcp", "airtable", "bug-tracking", "create"]
    },
    {
        "sample_id": "mcp_airtable_update_3",
        "user_request": "Mark the API Integration task as 'In Progress' - we got the API key.",
        "reasoning": "Direct record update through MCP is faster than the user navigating to Airtable, finding the record, and changing the status dropdown.",
        "tool_invocation": {"server": "airtable", "tool": "update_record", "input": {"baseId": "appXYZ123", "tableId": "Tasks", "recordId": "rec1", "fields": {"Status": "In Progress", "Blocker": ""}}},
        "tool_result": {"id": "rec1", "fields": {"Task": "API Integration", "Status": "In Progress", "Blocker": "", "Owner": "Sarah"}},
        "assistant_response": "Updated: API Integration is now 'In Progress' and the blocker is cleared. Sarah can start working on it.",
        "task_type": "ops",
        "tags": ["mcp", "airtable", "update", "status-change"]
    },
]

# ============================================================
# 7. HONEYCOMB - Observability
# ============================================================
samples += [
    {
        "sample_id": "mcp_honeycomb_latency_1",
        "user_request": "Our p99 latency spiked to 8 seconds in the last hour. Can you query Honeycomb to find out which endpoints are slow?",
        "reasoning": "Honeycomb MCP's run_unsaved_query tool lets me write and execute observability queries directly, avoiding the user needing to build the query in the Honeycomb UI. I can analyze latency distributions by endpoint.",
        "tool_invocation": {"server": "honeycomb", "tool": "run_unsaved_query", "input": {"dataset": "production-api", "query": {"breakdowns": ["http.route"], "calculations": [{"op": "P99", "column": "duration_ms"}, {"op": "COUNT"}], "filters": [{"column": "duration_ms", "op": ">", "value": 5000}], "time_range": 3600}}},
        "tool_result": {"results": [{"http.route": "/api/v2/reports/generate", "P99(duration_ms)": 12400, "COUNT": 234}, {"http.route": "/api/v2/export/csv", "P99(duration_ms)": 8900, "COUNT": 89}, {"http.route": "/api/v2/search", "P99(duration_ms)": 6100, "COUNT": 45}]},
        "assistant_response": "Found 3 endpoints with p99 > 5s in the last hour:\n\n| Endpoint | p99 Latency | Count |\n|----------|-------------|-------|\n| `/api/v2/reports/generate` | 12.4s | 234 requests |\n| `/api/v2/export/csv` | 8.9s | 89 requests |\n| `/api/v2/search` | 6.1s | 45 requests |\n\nReport generation is the worst offender at 12.4s p99 with 234 slow requests. Want me to pull a trace for one of those?",
        "task_type": "debug",
        "tags": ["mcp", "honeycomb", "latency", "observability"]
    },
    {
        "sample_id": "mcp_honeycomb_slo_2",
        "user_request": "Check if our API availability SLO is at risk this month.",
        "reasoning": "Honeycomb tracks SLO burn rates. The get_slos tool gives me the current state without the user needing to check the SLO dashboard.",
        "tool_invocation": {"server": "honeycomb", "tool": "get_slos", "input": {"dataset": "production-api"}},
        "tool_result": {"slos": [{"name": "API Availability 99.95%", "target": 99.95, "current": 99.91, "budget_remaining_pct": 18.2, "burn_rate": 2.4, "status": "warning"}, {"name": "Latency p99 < 2s", "target": 99.0, "current": 97.8, "budget_remaining_pct": -12.0, "burn_rate": 5.1, "status": "breached"}]},
        "assistant_response": "SLO status this month:\n\n1. **API Availability (99.95% target)**: Currently 99.91% - WARNING. Only 18.2% error budget remaining, burning at 2.4x rate. Will breach in ~3 days at this rate.\n\n2. **Latency p99 < 2s (99% target)**: Currently 97.8% - BREACHED. Error budget exhausted (-12%). This SLO is already violated.\n\nThe latency SLO is already blown. The availability SLO will breach by Feb 15 unless the latency issues are fixed. This needs immediate attention.",
        "task_type": "ops",
        "tags": ["mcp", "honeycomb", "slo", "reliability"]
    },
    {
        "sample_id": "mcp_honeycomb_trace_3",
        "user_request": "Get me a trace for one of those slow report generation requests so I can see where the time is spent.",
        "reasoning": "Honeycomb's get_trace tool retrieves a full distributed trace with span breakdown, showing exactly where latency accumulates across services.",
        "tool_invocation": {"server": "honeycomb", "tool": "get_trace", "input": {"dataset": "production-api", "traceId": "abc123def456"}},
        "tool_result": {"trace_id": "abc123def456", "duration_ms": 11200, "spans": [{"name": "HTTP POST /api/v2/reports/generate", "duration_ms": 11200, "service": "api-gateway"}, {"name": "ReportService.generate", "duration_ms": 10800, "service": "report-service"}, {"name": "SQL: SELECT * FROM transactions WHERE...", "duration_ms": 9200, "service": "report-service"}, {"name": "S3 PutObject", "duration_ms": 1400, "service": "report-service"}]},
        "assistant_response": "Trace breakdown for the 11.2s report request:\n\n```\nHTTP POST /reports/generate  [11.2s total]\n  └─ ReportService.generate   [10.8s]\n      ├─ SQL query              [9.2s]  ← 82% of total time\n      └─ S3 upload              [1.4s]\n```\n\nThe SQL query takes 9.2 seconds - that's 82% of the total request time. This is a database query optimization problem, not a service issue. The query is likely doing a full table scan on `transactions`. Need to check indexes.",
        "task_type": "debug",
        "tags": ["mcp", "honeycomb", "trace", "performance"]
    },
]

# ============================================================
# 8. PDF VIEWER
# ============================================================
samples += [
    {
        "sample_id": "mcp_pdf_arxiv_1",
        "user_request": "Can you show me the paper at https://arxiv.org/pdf/2301.07041? I want to read it inline.",
        "reasoning": "The PDF Viewer MCP can render PDFs from allowed URLs like arxiv.org directly in the conversation, giving a visual reading experience instead of just fetching raw text.",
        "tool_invocation": {"server": "pdf-viewer", "tool": "display_pdf", "input": {"url": "https://arxiv.org/pdf/2301.07041"}},
        "tool_result": {"rendered": True, "pages": 12, "title": "Chain-of-Thought Prompting Elicits Reasoning in Large Language Models"},
        "assistant_response": "Here's the paper rendered inline - 12 pages on Chain-of-Thought prompting. The key contributions are in sections 3-4 if you want to jump ahead. Want me to summarize any section?",
        "task_type": "research",
        "tags": ["mcp", "pdf-viewer", "arxiv", "paper"]
    },
    {
        "sample_id": "mcp_pdf_documentation_2",
        "user_request": "Display this arxiv paper about transformer architectures: https://arxiv.org/pdf/1706.03762",
        "reasoning": "Using the PDF Viewer MCP to render the original Attention Is All You Need paper visually, rather than trying to fetch and parse the raw PDF text which would lose formatting and figures.",
        "tool_invocation": {"server": "pdf-viewer", "tool": "display_pdf", "input": {"url": "https://arxiv.org/pdf/1706.03762"}},
        "tool_result": {"rendered": True, "pages": 15, "title": "Attention Is All You Need"},
        "assistant_response": "Rendered the \"Attention Is All You Need\" paper (15 pages). This is the foundational transformer architecture paper. The key diagram is on page 3 (Figure 1) showing the encoder-decoder structure with multi-head attention.",
        "task_type": "research",
        "tags": ["mcp", "pdf-viewer", "arxiv", "transformers"]
    },
]

# ============================================================
# 9. SHEET MUSIC
# ============================================================
samples += [
    {
        "sample_id": "mcp_sheet_music_compose_1",
        "user_request": "Generate sheet music for a simple melody in C major - something cheerful and 8 bars long.",
        "reasoning": "The Sheet Music MCP server can generate and render musical notation with playback, which is a specialized capability that no standard tool provides.",
        "tool_invocation": {"server": "sheet-music", "tool": "generate_sheet_music", "input": {"key": "C major", "tempo": 120, "bars": 8, "style": "cheerful"}},
        "tool_result": {"rendered": True, "notation": "C4 E4 G4 C5 | B4 G4 E4 C4 | D4 F4 A4 D5 | C5 A4 F4 D4 | E4 G4 B4 E5 | D5 B4 G4 E4 | C4 E4 G4 C5 | C5 G4 E4 C4", "playable": True},
        "assistant_response": "Here's an 8-bar cheerful melody in C major at 120 BPM. It follows a rising-falling pattern with arpeggiated chords. You can play it back directly. Want me to modify the tempo, key, or style?",
        "task_type": "creative",
        "tags": ["mcp", "sheet-music", "composition", "music"]
    },
    {
        "sample_id": "mcp_sheet_music_play_2",
        "user_request": "Can you write out the melody for 'Twinkle Twinkle Little Star' as sheet music?",
        "reasoning": "The Sheet Music MCP can notate and render well-known melodies with proper musical formatting and playback capability.",
        "tool_invocation": {"server": "sheet-music", "tool": "generate_sheet_music", "input": {"melody": "C4 C4 G4 G4 A4 A4 G4 | F4 F4 E4 E4 D4 D4 C4", "title": "Twinkle Twinkle Little Star"}},
        "tool_result": {"rendered": True, "title": "Twinkle Twinkle Little Star", "bars": 4, "playable": True},
        "assistant_response": "Rendered 'Twinkle Twinkle Little Star' as sheet music. The melody follows the classic C-C-G-G-A-A-G pattern. You can play it back to hear it. Want me to add harmonization or change the key?",
        "task_type": "creative",
        "tags": ["mcp", "sheet-music", "notation", "classic"]
    },
]

# ============================================================
# 10. THREE.JS 3D VIEWER
# ============================================================
samples += [
    {
        "sample_id": "mcp_threejs_visualize_1",
        "user_request": "Create a 3D visualization of a rotating cube with wireframe overlay.",
        "reasoning": "The Three.js MCP renders interactive 3D scenes directly in the conversation. Better than describing code - the user gets a visual, interactive result.",
        "tool_invocation": {"server": "threejs", "tool": "render_scene", "input": {"scene": {"objects": [{"type": "cube", "size": 2, "wireframe": True, "rotation": {"y": "animate"}, "color": "#4a9eff"}], "camera": {"position": [3, 3, 3]}, "background": "#1a1a2e"}}},
        "tool_result": {"rendered": True, "interactive": True, "fps": 60},
        "assistant_response": "Here's your rotating wireframe cube in 3D. You can drag to orbit the camera and scroll to zoom. The cube rotates on the Y axis at 60fps. Want me to add more objects, change colors, or add lighting effects?",
        "task_type": "creative",
        "tags": ["mcp", "threejs", "3d", "visualization"]
    },
    {
        "sample_id": "mcp_threejs_data_viz_2",
        "user_request": "Can you make a 3D bar chart showing our quarterly revenue? Q1: $2M, Q2: $3.5M, Q3: $2.8M, Q4: $4.1M",
        "reasoning": "Three.js MCP can render 3D data visualizations that are more engaging than 2D charts, with interactive camera controls.",
        "tool_invocation": {"server": "threejs", "tool": "render_scene", "input": {"scene": {"objects": [{"type": "box", "position": [-3, 1, 0], "size": [1, 2, 1], "color": "#4a9eff", "label": "Q1: $2M"}, {"type": "box", "position": [-1, 1.75, 0], "size": [1, 3.5, 1], "color": "#6bc5f8", "label": "Q2: $3.5M"}, {"type": "box", "position": [1, 1.4, 0], "size": [1, 2.8, 1], "color": "#4a9eff", "label": "Q3: $2.8M"}, {"type": "box", "position": [3, 2.05, 0], "size": [1, 4.1, 1], "color": "#2ecc71", "label": "Q4: $4.1M"}]}}},
        "tool_result": {"rendered": True, "interactive": True},
        "assistant_response": "Here's your 3D revenue bar chart. Q4 stands out as the strongest quarter at $4.1M (shown in green). You can rotate the view to see it from different angles. Total annual revenue: $12.4M with a clear growth trend from Q2 onward.",
        "task_type": "data",
        "tags": ["mcp", "threejs", "3d", "data-visualization"]
    },
]

# ============================================================
# 11. N8N - Workflow automation
# ============================================================
samples += [
    {
        "sample_id": "mcp_n8n_find_workflow_1",
        "user_request": "Do we have an n8n workflow that handles new user signups? I want to trigger it manually for a test.",
        "reasoning": "The n8n MCP lets me search existing workflows by keyword and then execute them, avoiding the need to open the n8n UI. The user can trigger automation directly from our conversation.",
        "tool_invocation": {"server": "n8n", "tool": "search_workflows", "input": {"query": "user signup"}},
        "tool_result": {"workflows": [{"id": "wf_123", "name": "New User Signup Flow", "active": True, "nodes": 8, "lastRun": "2026-02-12T10:30:00Z"}, {"id": "wf_456", "name": "User Signup Cleanup (Weekly)", "active": True, "nodes": 4, "lastRun": "2026-02-10T00:00:00Z"}]},
        "assistant_response": "Found 2 signup-related workflows:\n1. **New User Signup Flow** (wf_123) - 8 nodes, last ran 2 hours ago, active\n2. **User Signup Cleanup** (wf_456) - Weekly cleanup, 4 nodes\n\nThe first one is what you want. Want me to trigger it with test data?",
        "task_type": "ops",
        "tags": ["mcp", "n8n", "workflow", "automation"]
    },
    {
        "sample_id": "mcp_n8n_execute_2",
        "user_request": "Yes, trigger the signup flow with test data: email test@example.com, name 'Test User'.",
        "reasoning": "The n8n MCP execute_workflow tool can trigger workflows with custom input data, which is exactly what's needed for testing without going through the actual signup form.",
        "tool_invocation": {"server": "n8n", "tool": "execute_workflow", "input": {"workflowId": "wf_123", "data": {"email": "test@example.com", "name": "Test User", "source": "manual_test"}}},
        "tool_result": {"executionId": "exec_789", "status": "success", "startedAt": "2026-02-12T12:15:00Z", "finishedAt": "2026-02-12T12:15:03Z", "output": {"welcome_email_sent": True, "crm_contact_created": True, "slack_notification_sent": True}},
        "assistant_response": "Workflow executed successfully in 3 seconds:\n- Welcome email sent to test@example.com\n- CRM contact created\n- Slack notification sent\n\nAll 3 actions completed. The signup flow is working correctly.",
        "task_type": "ops",
        "tags": ["mcp", "n8n", "workflow", "execute"]
    },
    {
        "sample_id": "mcp_n8n_details_3",
        "user_request": "Show me the details of that signup workflow - what does each step do?",
        "reasoning": "The get_workflow_details tool provides the full node breakdown without the user needing to open the n8n visual editor.",
        "tool_invocation": {"server": "n8n", "tool": "get_workflow_details", "input": {"workflowId": "wf_123"}},
        "tool_result": {"id": "wf_123", "name": "New User Signup Flow", "nodes": [{"type": "webhook", "name": "Signup Trigger"}, {"type": "set", "name": "Normalize Data"}, {"type": "if", "name": "Check Email Valid"}, {"type": "sendgrid", "name": "Send Welcome Email"}, {"type": "hubspot", "name": "Create CRM Contact"}, {"type": "slack", "name": "Notify #signups Channel"}, {"type": "postgres", "name": "Log to Analytics DB"}, {"type": "respondToWebhook", "name": "Return Success"}]},
        "assistant_response": "The signup flow has 8 steps:\n\n1. **Webhook Trigger** - Receives signup data\n2. **Normalize Data** - Cleans/formats input\n3. **Check Email Valid** - Validates email format\n4. **Send Welcome Email** (SendGrid) - Sends welcome message\n5. **Create CRM Contact** (HubSpot) - Adds to CRM\n6. **Notify #signups** (Slack) - Team notification\n7. **Log to Analytics** (Postgres) - Records the event\n8. **Return Success** - Responds to webhook\n\nSolid flow. The email validation at step 3 branches - invalid emails probably get rejected early.",
        "task_type": "ops",
        "tags": ["mcp", "n8n", "workflow", "details"]
    },
]

# ============================================================
# 12. PENDO - Product analytics
# ============================================================
samples += [
    {
        "sample_id": "mcp_pendo_adoption_1",
        "user_request": "What's the adoption rate for our new dashboard feature? How many users have tried it?",
        "reasoning": "Pendo tracks feature usage and adoption. The activityQuery tool can pull usage metrics directly, giving real numbers instead of guesses.",
        "tool_invocation": {"server": "pendo", "tool": "activityQuery", "input": {"feature": "new-dashboard", "period": "last_30_days", "metric": "unique_visitors"}},
        "tool_result": {"feature": "new-dashboard", "period": "2026-01-13 to 2026-02-12", "unique_visitors": 1247, "total_visitors": 8930, "adoption_rate": 13.96, "avg_time_on_feature_seconds": 142},
        "assistant_response": "Dashboard feature adoption (last 30 days):\n- **1,247 unique users** out of 8,930 total = **14% adoption rate**\n- Average time spent: 2m 22s per session\n\n14% adoption after 30 days is below typical for a promoted feature (usually 25-30%). The 2+ minute engagement is healthy though - users who find it do use it. Might need better discoverability (in-app guide, tooltip, etc.).",
        "task_type": "data",
        "tags": ["mcp", "pendo", "adoption", "feature-analytics"]
    },
    {
        "sample_id": "mcp_pendo_session_replay_2",
        "user_request": "Show me session replays of users who abandoned the onboarding flow.",
        "reasoning": "Pendo's sessionReplayList tool can filter for specific user behaviors like abandonment, giving concrete visual evidence of UX problems without the user needing to hunt through the Pendo UI.",
        "tool_invocation": {"server": "pendo", "tool": "sessionReplayList", "input": {"segment": "onboarding-abandoned", "limit": 5, "sort": "recent"}},
        "tool_result": {"replays": [{"id": "sr_001", "visitor": "v_anon_123", "duration_seconds": 45, "pages_visited": 2, "drop_off_page": "/onboarding/step-3", "timestamp": "2026-02-12T09:30:00Z"}, {"id": "sr_002", "visitor": "v_anon_456", "duration_seconds": 32, "pages_visited": 2, "drop_off_page": "/onboarding/step-3", "timestamp": "2026-02-12T08:15:00Z"}, {"id": "sr_003", "visitor": "v_anon_789", "duration_seconds": 67, "pages_visited": 3, "drop_off_page": "/onboarding/step-4", "timestamp": "2026-02-11T16:00:00Z"}]},
        "assistant_response": "Found 5 abandoned onboarding sessions. Clear pattern:\n\n- **3 of 5 users dropped off at Step 3** (the one asking for company details)\n- Average session before abandonment: 45 seconds\n- Users get through steps 1-2 fine but step 3 is a wall\n\nStep 3 is likely asking for too much information or has a confusing form. Recommend simplifying that step or making some fields optional.",
        "task_type": "data",
        "tags": ["mcp", "pendo", "session-replay", "onboarding"]
    },
    {
        "sample_id": "mcp_pendo_guide_metrics_3",
        "user_request": "How are our in-app guides performing? Which ones have the best completion rates?",
        "reasoning": "Pendo's guideMetrics tool gives engagement data for in-app guides, which helps prioritize which guides are working and which need improvement.",
        "tool_invocation": {"server": "pendo", "tool": "guideMetrics", "input": {"period": "last_30_days"}},
        "tool_result": {"guides": [{"name": "Welcome Tour", "views": 2340, "completions": 1872, "completion_rate": 80.0, "dismissals": 468}, {"name": "New Feature Announcement", "views": 5600, "completions": 1120, "completion_rate": 20.0, "dismissals": 4480}, {"name": "Setup Wizard", "views": 890, "completions": 712, "completion_rate": 80.0, "dismissals": 178}]},
        "assistant_response": "In-app guide performance (last 30 days):\n\n| Guide | Views | Completion | Rate |\n|-------|-------|------------|------|\n| Welcome Tour | 2,340 | 1,872 | 80% |\n| Setup Wizard | 890 | 712 | 80% |\n| New Feature Announcement | 5,600 | 1,120 | 20% |\n\nWelcome Tour and Setup Wizard perform great at 80% completion. The Feature Announcement has 80% dismissal rate - users are closing it without reading. Consider making it less intrusive (tooltip vs. modal) or more targeted to relevant users.",
        "task_type": "data",
        "tags": ["mcp", "pendo", "guides", "engagement"]
    },
]

# ============================================================
# 13. PORT IO - Software catalog
# ============================================================
samples += [
    {
        "sample_id": "mcp_port_catalog_1",
        "user_request": "List all our microservices and their current health scores.",
        "reasoning": "Port IO is an internal developer portal / software catalog. The list_entities tool queries the service catalog for health and compliance data, giving a bird's eye view of infrastructure.",
        "tool_invocation": {"server": "port-io", "tool": "list_entities", "input": {"blueprint": "microservice", "fields": ["title", "health_score", "team", "language"]}},
        "tool_result": {"entities": [{"identifier": "user-service", "title": "User Service", "health_score": 92, "team": "platform", "language": "Go"}, {"identifier": "payment-service", "title": "Payment Service", "health_score": 78, "team": "payments", "language": "Java"}, {"identifier": "notification-service", "title": "Notification Service", "health_score": 65, "team": "platform", "language": "Python"}], "total": 3},
        "assistant_response": "3 microservices in the catalog:\n\n| Service | Team | Language | Health |\n|---------|------|----------|--------|\n| User Service | platform | Go | 92/100 |\n| Payment Service | payments | Java | 78/100 |\n| Notification Service | platform | Python | 65/100 |\n\nNotification Service has the lowest health score (65). Want me to check its scorecard to see what's dragging it down?",
        "task_type": "ops",
        "tags": ["mcp", "port-io", "catalog", "health"]
    },
    {
        "sample_id": "mcp_port_scorecard_2",
        "user_request": "Check the scorecard for the notification service - why is the health score so low?",
        "reasoning": "Port IO scorecards show compliance rules and which ones are passing/failing. This identifies exactly what needs fixing rather than guessing.",
        "tool_invocation": {"server": "port-io", "tool": "get_scorecard", "input": {"blueprint": "microservice", "entity": "notification-service"}},
        "tool_result": {"scorecard": "Production Readiness", "score": 65, "rules": [{"name": "Has CI/CD pipeline", "status": "pass"}, {"name": "Has runbook", "status": "fail"}, {"name": "Has on-call rotation", "status": "fail"}, {"name": "Test coverage > 80%", "status": "fail", "actual": "62%"}, {"name": "No critical vulnerabilities", "status": "pass"}, {"name": "Has monitoring dashboards", "status": "pass"}]},
        "assistant_response": "Notification Service scorecard (Production Readiness: 65/100):\n\n- Pass: CI/CD pipeline, no critical vulns, monitoring dashboards\n- **FAIL: No runbook** - needs documentation for on-call\n- **FAIL: No on-call rotation** - no one assigned for incidents\n- **FAIL: Test coverage 62%** (needs >80%)\n\nThe missing runbook and on-call rotation are the biggest concerns for production readiness. Test coverage needs 18% improvement.",
        "task_type": "ops",
        "tags": ["mcp", "port-io", "scorecard", "compliance"]
    },
    {
        "sample_id": "mcp_port_self_service_3",
        "user_request": "I need to scaffold a new microservice. Does Port have a self-service action for that?",
        "reasoning": "Port IO self-service actions let developers scaffold infrastructure through governed workflows. The list_actions and run_action tools let me find and trigger these actions from the conversation.",
        "tool_invocation": {"server": "port-io", "tool": "list_actions", "input": {"blueprint": "microservice"}},
        "tool_result": {"actions": [{"id": "scaffold-service", "title": "Scaffold New Microservice", "description": "Creates repo, CI/CD, monitoring, and catalog entry", "trigger": "manual"}, {"id": "deploy-to-staging", "title": "Deploy to Staging", "trigger": "manual"}, {"id": "promote-to-prod", "title": "Promote to Production", "trigger": "approval-required"}]},
        "assistant_response": "Yes, there's a 'Scaffold New Microservice' action that creates the repo, CI/CD pipeline, monitoring, and catalog entry all at once. There's also deploy-to-staging (manual) and promote-to-production (requires approval). Want me to run the scaffold action? I'll need the service name, team, and language.",
        "task_type": "ops",
        "tags": ["mcp", "port-io", "self-service", "scaffold"]
    },
]

# ============================================================
# 14. BENEVITY - Nonprofit search
# ============================================================
samples += [
    {
        "sample_id": "mcp_benevity_search_1",
        "user_request": "Find me verified nonprofits near Los Angeles that focus on mental health.",
        "reasoning": "Benevity has a database of 2.3M+ verified nonprofits. The MCP search tool is authless and provides curated, verified results - better than a generic web search which would include unverified organizations.",
        "tool_invocation": {"server": "benevity", "tool": "Benevity Nonprofit Search", "input": {"cause": "mental health", "location": "Los Angeles, CA", "limit": 5}},
        "tool_result": {"nonprofits": [{"name": "NAMI Los Angeles County", "id": "np_001", "cause": "Mental Health", "location": "Los Angeles, CA", "verified": True}, {"name": "Didi Hirsch Mental Health Services", "id": "np_002", "cause": "Mental Health & Crisis Services", "location": "Culver City, CA", "verified": True}, {"name": "LA County Department of Mental Health Foundation", "id": "np_003", "cause": "Mental Health Policy", "location": "Los Angeles, CA", "verified": True}]},
        "assistant_response": "Found 3 verified mental health nonprofits near LA:\n\n1. **NAMI Los Angeles County** - National Alliance on Mental Illness, LA chapter\n2. **Didi Hirsch Mental Health Services** - Mental health and crisis services (Culver City)\n3. **LA County Dept of Mental Health Foundation** - Policy and advocacy\n\nAll verified through Benevity. Want details on any of these, or should I search for a more specific focus area?",
        "task_type": "research",
        "tags": ["mcp", "benevity", "nonprofit", "mental-health"]
    },
    {
        "sample_id": "mcp_benevity_details_2",
        "user_request": "Get me the full details on Didi Hirsch - what programs do they run?",
        "reasoning": "Benevity's Get Nonprofit Details tool provides comprehensive organizational information including programs, financials, and verification status.",
        "tool_invocation": {"server": "benevity", "tool": "Benevity Get Nonprofit Details", "input": {"id": "np_002"}},
        "tool_result": {"name": "Didi Hirsch Mental Health Services", "ein": "95-2557880", "mission": "Providing accessible mental health and substance abuse services since 1942", "programs": ["Crisis Services (Suicide Prevention)", "Outpatient Therapy", "Substance Use Treatment", "Housing & Homeless Services"], "revenue": 48000000, "location": "Culver City, CA", "website": "didihirsch.org", "verified": True},
        "assistant_response": "**Didi Hirsch Mental Health Services**\n- EIN: 95-2557880 (verified)\n- Founded: 1942\n- Revenue: $48M\n- Location: Culver City, CA\n\n**Programs:**\n- Crisis Services (Suicide Prevention)\n- Outpatient Therapy\n- Substance Use Treatment\n- Housing & Homeless Services\n\nThey're a well-established organization with nearly 85 years of operation and a solid $48M revenue base. The crisis services program is particularly notable.",
        "task_type": "research",
        "tags": ["mcp", "benevity", "nonprofit", "details"]
    },
]

# ============================================================
# 15. CANDID - Nonprofit/funder research
# ============================================================
samples += [
    {
        "sample_id": "mcp_candid_grants_1",
        "user_request": "We're a small nonprofit working on climate education. Can you find grant opportunities from foundations that fund environmental education?",
        "reasoning": "Candid has the most comprehensive database of funders and grants. The search_organizations tool can find foundations that specifically fund environmental education, with data on their giving patterns.",
        "tool_invocation": {"server": "candid", "tool": "search_organizations", "input": {"query": "environmental education grants", "type": "funder", "subject": "climate education"}},
        "tool_result": {"organizations": [{"name": "Patagonia Environmental Grants", "type": "corporate_foundation", "total_giving": 89000000, "focus_areas": ["environmental education", "climate action"]}, {"name": "NOAA Environmental Literacy Program", "type": "government", "total_giving": 12000000, "focus_areas": ["environmental literacy", "K-12 education"]}, {"name": "Captain Planet Foundation", "type": "private_foundation", "total_giving": 3500000, "focus_areas": ["environmental education", "youth programs"]}]},
        "assistant_response": "Found 3 funders for environmental/climate education:\n\n1. **Patagonia Environmental Grants** - $89M total giving, corporate foundation. Funds environmental education and climate action.\n2. **NOAA Environmental Literacy Program** - $12M, government. Specifically targets environmental literacy in K-12.\n3. **Captain Planet Foundation** - $3.5M, private foundation. Youth-focused environmental education.\n\nNOAA's program is the best fit for education specifically. Patagonia is the largest but more broadly focused. Want me to dig into any of these for application details?",
        "task_type": "research",
        "tags": ["mcp", "candid", "grants", "nonprofit"]
    },
    {
        "sample_id": "mcp_candid_org_lookup_2",
        "user_request": "Can you look up financial data on the Red Cross? I want to see their overhead ratio.",
        "reasoning": "Candid provides detailed nonprofit financial data including program expenses vs. overhead. This is more authoritative than random web results for nonprofit financial transparency.",
        "tool_invocation": {"server": "candid", "tool": "search_organizations", "input": {"query": "American Red Cross", "type": "nonprofit"}},
        "tool_result": {"organizations": [{"name": "American National Red Cross", "ein": "53-0196605", "total_revenue": 3200000000, "total_expenses": 3100000000, "program_expense_ratio": 0.89, "admin_expense_ratio": 0.04, "fundraising_expense_ratio": 0.07}]},
        "assistant_response": "**American National Red Cross** financial breakdown:\n- Revenue: $3.2B | Expenses: $3.1B\n- **Program expenses: 89%** (direct mission work)\n- Admin overhead: 4%\n- Fundraising: 7%\n\nAn 89% program expense ratio is solid. Industry benchmark is 75%+, so the Red Cross is well above average. Only 4% goes to admin overhead.",
        "task_type": "research",
        "tags": ["mcp", "candid", "nonprofit", "financials"]
    },
    {
        "sample_id": "mcp_candid_knowledge_3",
        "user_request": "What resources does Candid have about starting a 501(c)(3)?",
        "reasoning": "Candid's knowledge_resources tool provides access to their expert guides and articles on nonprofit topics, which is more authoritative than general web searches for this domain.",
        "tool_invocation": {"server": "candid", "tool": "knowledge_resources", "input": {"query": "starting 501c3 nonprofit"}},
        "tool_result": {"resources": [{"title": "How to Start a Nonprofit Organization", "type": "guide", "url": "https://candid.org/start-nonprofit"}, {"title": "501(c)(3) Application Process Step by Step", "type": "article"}, {"title": "State-by-State Nonprofit Registration Requirements", "type": "database"}]},
        "assistant_response": "Candid has 3 relevant resources:\n\n1. **How to Start a Nonprofit Organization** - Comprehensive guide\n2. **501(c)(3) Application Process** - Step-by-step IRS filing guide\n3. **State-by-State Registration Requirements** - Database of requirements per state\n\nThe step-by-step guide is probably your best starting point. Want me to pull up the details on any of these?",
        "task_type": "research",
        "tags": ["mcp", "candid", "nonprofit", "knowledge"]
    },
]

# ============================================================
# 16. LEARNING COMMONS - K-12 education
# ============================================================
samples += [
    {
        "sample_id": "mcp_learning_commons_standard_1",
        "user_request": "I'm teaching 4th grade math in Texas. What does standard 4.OA.A.3 break down into?",
        "reasoning": "Learning Commons Knowledge Graph provides granular breakdown of educational standards into learning components. This is authless and gives precise, authoritative curriculum alignment that a web search couldn't match.",
        "tool_invocation": {"server": "learning-commons", "tool": "find_learning_components_from_standard", "input": {"standardId": "4.OA.A.3", "state": "TX"}},
        "tool_result": {"standard": "4.OA.A.3", "statement": "Solve multistep word problems with whole numbers using the four operations", "learning_components": [{"id": "lc_001", "description": "Identify the operations needed in a multi-step word problem"}, {"id": "lc_002", "description": "Represent word problems using equations with a variable for the unknown"}, {"id": "lc_003", "description": "Solve multi-step equations using order of operations"}, {"id": "lc_004", "description": "Assess reasonableness of answers using estimation"}]},
        "assistant_response": "Standard 4.OA.A.3 (\"Solve multistep word problems with whole numbers\") breaks into 4 learning components:\n\n1. **Identify operations** needed in multi-step problems\n2. **Represent as equations** with variables for unknowns\n3. **Solve multi-step equations** using order of operations\n4. **Assess reasonableness** through estimation\n\nYou could build a lesson around each component. Want me to find the prerequisite skills or generate practice problems for any of these?",
        "task_type": "research",
        "tags": ["mcp", "learning-commons", "education", "standards"]
    },
    {
        "sample_id": "mcp_learning_commons_progression_2",
        "user_request": "A student is struggling with 8.F.B.4 (functions). What are the prerequisite standards they should have mastered first?",
        "reasoning": "Learning Commons tracks learning progressions - the prerequisite chain of standards. This helps identify where a struggling student may have gaps, which is exactly what the teacher needs.",
        "tool_invocation": {"server": "learning-commons", "tool": "find_standards_progression_from_standard", "input": {"standardId": "8.F.B.4"}},
        "tool_result": {"target": "8.F.B.4", "statement": "Construct a function to model a linear relationship", "prerequisites": [{"id": "7.RP.A.2", "statement": "Recognize and represent proportional relationships", "grade": 7}, {"id": "6.EE.C.9", "statement": "Use variables to represent two quantities that change in relationship", "grade": 6}, {"id": "5.OA.B.3", "statement": "Generate two numerical patterns using two given rules", "grade": 5}]},
        "assistant_response": "8.F.B.4 (\"Construct a function to model a linear relationship\") builds on these prerequisites:\n\n1. **Grade 5** - 5.OA.B.3: Generate two numerical patterns using rules\n2. **Grade 6** - 6.EE.C.9: Use variables for quantities that change in relationship\n3. **Grade 7** - 7.RP.A.2: Recognize proportional relationships\n\nStart by assessing whether the student can do proportional relationships (7th grade prerequisite). If not, that's likely where the gap is. Work backward from there.",
        "task_type": "research",
        "tags": ["mcp", "learning-commons", "education", "prerequisites"]
    },
    {
        "sample_id": "mcp_learning_commons_find_standard_3",
        "user_request": "What's the Iowa state standard for teaching persuasive writing in 8th grade?",
        "reasoning": "Learning Commons covers all 50 states' standards. The find_standard_statement tool can look up the specific standard by state and subject, giving authoritative curriculum reference.",
        "tool_invocation": {"server": "learning-commons", "tool": "find_standard_statement", "input": {"state": "IA", "grade": 8, "subject": "ELA", "query": "persuasive writing"}},
        "tool_result": {"standards": [{"id": "W.8.1", "statement": "Write arguments to support claims with clear reasons and relevant evidence", "state": "IA", "grade": 8, "subject": "Writing"}]},
        "assistant_response": "Iowa's 8th grade persuasive writing standard is **W.8.1**: \"Write arguments to support claims with clear reasons and relevant evidence.\"\n\nThis aligns with the Common Core writing standards. Want me to break this into learning components or find the progression from earlier grades?",
        "task_type": "research",
        "tags": ["mcp", "learning-commons", "education", "writing"]
    },
]

# ============================================================
# 17. OPEN TARGETS - Drug discovery
# ============================================================
samples += [
    {
        "sample_id": "mcp_open_targets_disease_1",
        "user_request": "What are the top drug targets for Alzheimer's disease according to Open Targets?",
        "reasoning": "Open Targets Platform aggregates genetics, genomics, and drug data to score target-disease associations. The MCP provides direct GraphQL access to their database, which is more structured and comprehensive than web searching.",
        "tool_invocation": {"server": "open-targets", "tool": "query_open_targets_graphql", "input": {"query": "{ disease(efoId: \"EFO_0000249\") { name associatedTargets(page: {size: 5}) { rows { target { approvedSymbol approvedName } score datatypeScores { id score } } } } }"}},
        "tool_result": {"data": {"disease": {"name": "Alzheimer's disease", "associatedTargets": {"rows": [{"target": {"approvedSymbol": "APP", "approvedName": "amyloid beta precursor protein"}, "score": 0.89}, {"target": {"approvedSymbol": "PSEN1", "approvedName": "presenilin 1"}, "score": 0.85}, {"target": {"approvedSymbol": "APOE", "approvedName": "apolipoprotein E"}, "score": 0.82}, {"target": {"approvedSymbol": "MAPT", "approvedName": "microtubule associated protein tau"}, "score": 0.78}, {"target": {"approvedSymbol": "TREM2", "approvedName": "triggering receptor expressed on myeloid cells 2"}, "score": 0.71}]}}}},
        "assistant_response": "Top 5 drug targets for Alzheimer's disease (by Open Targets association score):\n\n| Target | Gene | Score |\n|--------|------|-------|\n| Amyloid beta precursor protein | APP | 0.89 |\n| Presenilin 1 | PSEN1 | 0.85 |\n| Apolipoprotein E | APOE | 0.82 |\n| Tau protein | MAPT | 0.78 |\n| TREM2 | TREM2 | 0.71 |\n\nAPP and PSEN1 are the classic amyloid pathway targets. TREM2 is the most interesting recent addition - it's an innate immunity target that's gained evidence from GWAS studies. Want me to dig into any specific target's evidence?",
        "task_type": "research",
        "tags": ["mcp", "open-targets", "drug-discovery", "alzheimers"]
    },
    {
        "sample_id": "mcp_open_targets_gene_2",
        "user_request": "What diseases is the BRCA1 gene associated with?",
        "reasoning": "Open Targets provides comprehensive gene-disease associations backed by multiple evidence sources (genetics, literature, clinical). The GraphQL API gives structured, scored results.",
        "tool_invocation": {"server": "open-targets", "tool": "search_entities", "input": {"query": "BRCA1", "entity_type": "target"}},
        "tool_result": {"results": [{"id": "ENSG00000012048", "name": "BRCA1", "description": "BRCA1 DNA repair associated", "top_diseases": [{"name": "breast carcinoma", "score": 0.95}, {"name": "ovarian carcinoma", "score": 0.92}, {"name": "prostate carcinoma", "score": 0.58}, {"name": "pancreatic carcinoma", "score": 0.45}]}]},
        "assistant_response": "BRCA1 (DNA repair associated) disease associations:\n\n| Disease | Association Score |\n|---------|------------------|\n| Breast carcinoma | 0.95 (very strong) |\n| Ovarian carcinoma | 0.92 (very strong) |\n| Prostate carcinoma | 0.58 (moderate) |\n| Pancreatic carcinoma | 0.45 (moderate) |\n\nThe breast and ovarian cancer links are extremely well-established (scores >0.9). The prostate and pancreatic associations are weaker but real. Want me to look at the specific evidence types driving these scores?",
        "task_type": "research",
        "tags": ["mcp", "open-targets", "genetics", "cancer"]
    },
    {
        "sample_id": "mcp_open_targets_batch_3",
        "user_request": "I have a list of 5 genes from a GWAS hit: TREM2, CD33, MS4A6A, CLU, BIN1. Can you batch query their Alzheimer's association scores?",
        "reasoning": "Open Targets' batch_query tool is designed exactly for this - querying multiple targets at once against a disease, which is common in post-GWAS analysis workflows.",
        "tool_invocation": {"server": "open-targets", "tool": "batch_query_open_targets_graphql", "input": {"targets": ["ENSG00000095970", "ENSG00000105383", "ENSG00000110576", "ENSG00000120885", "ENSG00000136717"], "diseaseId": "EFO_0000249"}},
        "tool_result": {"results": [{"symbol": "TREM2", "score": 0.71}, {"symbol": "CD33", "score": 0.64}, {"symbol": "CLU", "score": 0.62}, {"symbol": "BIN1", "score": 0.59}, {"symbol": "MS4A6A", "score": 0.48}]},
        "assistant_response": "Batch results for your 5 GWAS genes vs Alzheimer's:\n\n| Gene | OT Score | Strength |\n|------|----------|----------|\n| TREM2 | 0.71 | Strong |\n| CD33 | 0.64 | Moderate-Strong |\n| CLU | 0.62 | Moderate-Strong |\n| BIN1 | 0.59 | Moderate |\n| MS4A6A | 0.48 | Moderate |\n\nTREM2 leads with strongest association. All 5 genes have meaningful Alzheimer's associations (>0.4), supporting your GWAS findings. TREM2 and CD33 are particularly interesting as they're both innate immunity genes - suggests a neuroimmune pathway worth investigating.",
        "task_type": "research",
        "tags": ["mcp", "open-targets", "gwas", "batch-query"]
    },
]

# ============================================================
# 18. SYNAPSE.ORG - Scientific datasets
# ============================================================
samples += [
    {
        "sample_id": "mcp_synapse_search_1",
        "user_request": "Find genomics datasets related to Parkinson's disease on Synapse.",
        "reasoning": "Synapse.org hosts collaborative research datasets. The MCP search tool provides structured results with metadata and access information, which is more useful than browsing the Synapse website.",
        "tool_invocation": {"server": "synapse", "tool": "search_synapse", "input": {"query": "Parkinson's disease genomics", "type": "dataset"}},
        "tool_result": {"results": [{"id": "syn12345678", "name": "PPMI Genomics Dataset", "description": "Parkinson's Progression Markers Initiative - whole genome sequencing", "project": "PPMI", "size": "2.4TB", "files": 1247}, {"id": "syn23456789", "name": "AMP-PD Whole Blood RNA-seq", "description": "Accelerating Medicines Partnership - transcriptomics", "project": "AMP-PD", "size": "890GB", "files": 634}]},
        "assistant_response": "Found 2 Parkinson's genomics datasets on Synapse:\n\n1. **PPMI Genomics Dataset** (syn12345678)\n   - Whole genome sequencing from Parkinson's Progression Markers Initiative\n   - 2.4TB, 1,247 files\n\n2. **AMP-PD Whole Blood RNA-seq** (syn23456789)\n   - Transcriptomics from Accelerating Medicines Partnership\n   - 890GB, 634 files\n\nBoth are major consortium datasets. PPMI is the gold standard for PD genomics. Want me to check access requirements or get detailed metadata?",
        "task_type": "research",
        "tags": ["mcp", "synapse", "genomics", "parkinsons"]
    },
    {
        "sample_id": "mcp_synapse_provenance_2",
        "user_request": "Get the provenance information for syn12345678 - I need to know how this data was generated.",
        "reasoning": "Synapse tracks data provenance (how datasets were generated, what tools were used, what inputs). The MCP tool provides this lineage information directly.",
        "tool_invocation": {"server": "synapse", "tool": "get_entity_provenance", "input": {"entityId": "syn12345678"}},
        "tool_result": {"entity": "syn12345678", "activity": {"name": "WGS Processing Pipeline v3.2", "description": "BWA-MEM alignment, GATK HaplotypeCaller variant calling", "used": [{"id": "syn11111111", "name": "Raw FASTQ files", "type": "dataset"}], "executed": [{"name": "BWA-MEM 0.7.17"}, {"name": "GATK 4.2.6"}], "generatedBy": "PPMI Bioinformatics Core"}},
        "assistant_response": "Provenance for PPMI Genomics Dataset:\n\n**Pipeline**: WGS Processing Pipeline v3.2\n**Generated by**: PPMI Bioinformatics Core\n\n**Input**: Raw FASTQ files (syn11111111)\n**Tools used**:\n- BWA-MEM 0.7.17 (alignment)\n- GATK 4.2.6 (variant calling)\n\nStandard WGS pipeline - BWA for alignment, GATK HaplotypeCaller for variants. This is a well-validated, reproducible workflow. The raw FASTQs are also on Synapse if you need to reprocess.",
        "task_type": "research",
        "tags": ["mcp", "synapse", "provenance", "genomics"]
    },
    {
        "sample_id": "mcp_synapse_children_3",
        "user_request": "What folders and files are inside the PPMI project on Synapse?",
        "reasoning": "Synapse organizes data in hierarchical projects. The get_entity_children tool lets me browse the project structure without the user needing to navigate the Synapse web interface.",
        "tool_invocation": {"server": "synapse", "tool": "get_entity_children", "input": {"parentId": "syn12345678"}},
        "tool_result": {"children": [{"id": "syn12345679", "name": "Clinical Data", "type": "folder"}, {"id": "syn12345680", "name": "Genomics", "type": "folder"}, {"id": "syn12345681", "name": "Imaging", "type": "folder"}, {"id": "syn12345682", "name": "README.md", "type": "file"}, {"id": "syn12345683", "name": "data_dictionary.csv", "type": "file"}]},
        "assistant_response": "PPMI project contents:\n\n**Folders:**\n- `Clinical Data/` - Clinical assessments and demographics\n- `Genomics/` - WGS, RNA-seq, genotyping data\n- `Imaging/` - Brain imaging datasets\n\n**Files:**\n- `README.md` - Project documentation\n- `data_dictionary.csv` - Variable definitions\n\nStart with the README and data dictionary to understand the structure, then dive into the Genomics folder for your WGS data. Want me to explore any of these?",
        "task_type": "research",
        "tags": ["mcp", "synapse", "project-structure", "data"]
    },
]

# ============================================================
# 19. CHRONOGRAPH - Investment analytics
# ============================================================
samples += [
    {
        "sample_id": "mcp_chronograph_exposure_1",
        "user_request": "What are our top sector exposures in the Client A portfolio?",
        "reasoning": "Chronograph provides portfolio analytics for private investments. The top-exposures tool gives a sector breakdown directly without the user needing to generate a report in the Chronograph UI.",
        "tool_invocation": {"server": "chronograph", "tool": "top-exposures", "input": {"portfolio": "Client A", "dimension": "sector"}},
        "tool_result": {"exposures": [{"sector": "Technology", "nav": 45000000, "pct": 32.1}, {"sector": "Healthcare", "nav": 28000000, "pct": 20.0}, {"sector": "Financial Services", "nav": 21000000, "pct": 15.0}, {"sector": "Consumer", "nav": 18000000, "pct": 12.9}, {"sector": "Industrials", "nav": 14000000, "pct": 10.0}], "total_nav": 140000000},
        "assistant_response": "Client A portfolio sector exposure ($140M total NAV):\n\n| Sector | NAV | Weight |\n|--------|-----|--------|\n| Technology | $45M | 32.1% |\n| Healthcare | $28M | 20.0% |\n| Financial Services | $21M | 15.0% |\n| Consumer | $18M | 12.9% |\n| Industrials | $14M | 10.0% |\n\nTechnology is the dominant exposure at 32%. If you're concerned about concentration risk, the top-2 sectors (Tech + Healthcare) account for 52% of the portfolio.",
        "task_type": "data",
        "tags": ["mcp", "chronograph", "portfolio", "exposure"]
    },
    {
        "sample_id": "mcp_chronograph_performance_2",
        "user_request": "What's the performance track record for Huron Oak Equity V?",
        "reasoning": "Chronograph's investment-metrics tool provides IRR, TVPI, DPI, and other fund performance metrics directly, which is exactly what's needed for fund evaluation.",
        "tool_invocation": {"server": "chronograph", "tool": "investment-metrics", "input": {"fund": "Huron Oak Equity V"}},
        "tool_result": {"fund": "Huron Oak Equity V", "vintage": 2020, "strategy": "Buyout", "metrics": {"irr": 18.4, "tvpi": 1.62, "dpi": 0.85, "rvpi": 0.77, "commitment": 50000000, "called": 42500000, "distributed": 36125000, "nav": 32725000}},
        "assistant_response": "**Huron Oak Equity V** (2020 Vintage, Buyout)\n\n| Metric | Value |\n|--------|-------|\n| IRR | 18.4% |\n| TVPI | 1.62x |\n| DPI | 0.85x |\n| RVPI | 0.77x |\n| Commitment | $50M |\n| Called | $42.5M (85%) |\n| Distributed | $36.1M |\n| NAV | $32.7M |\n\n18.4% IRR and 1.62x TVPI for a 2020 vintage buyout fund is solid performance. They've returned 85% of called capital already (DPI 0.85x) with significant remaining value. On track for a strong final multiple.",
        "task_type": "data",
        "tags": ["mcp", "chronograph", "fund-performance", "irr"]
    },
    {
        "sample_id": "mcp_chronograph_commitment_3",
        "user_request": "Show me our commitment history over the last 5 years - how much have we committed per year?",
        "reasoning": "Chronograph's commitment-history tool provides year-by-year commitment data, which is essential for pacing analysis and future allocation planning.",
        "tool_invocation": {"server": "chronograph", "tool": "commitment-history", "input": {"portfolio": "Client A", "years": 5}},
        "tool_result": {"commitments": [{"year": 2022, "amount": 25000000, "funds": 3}, {"year": 2023, "amount": 35000000, "funds": 4}, {"year": 2024, "amount": 42000000, "funds": 5}, {"year": 2025, "amount": 38000000, "funds": 4}, {"year": 2026, "amount": 15000000, "funds": 2}], "total": 155000000},
        "assistant_response": "Client A commitment history (5 years):\n\n| Year | Committed | # Funds |\n|------|-----------|--------|\n| 2022 | $25M | 3 |\n| 2023 | $35M | 4 |\n| 2024 | $42M | 5 |\n| 2025 | $38M | 4 |\n| 2026 YTD | $15M | 2 |\n| **Total** | **$155M** | **18** |\n\nCommitment pace increased from $25M to $42M peak in 2024, then pulled back slightly. 2026 is early with only $15M so far. Average pace is ~$31M/year. Want me to project the remaining 2026 allocation based on the pacing model?",
        "task_type": "data",
        "tags": ["mcp", "chronograph", "commitments", "pacing"]
    },
]

# ============================================================
# 20. HEX - Data analytics
# ============================================================
samples += [
    {
        "sample_id": "mcp_hex_search_dashboards_1",
        "user_request": "Find our customer analytics dashboards in Hex.",
        "reasoning": "Hex MCP lets me search across all Hex projects to find relevant dashboards, saving the user from browsing through potentially hundreds of projects in the Hex UI.",
        "tool_invocation": {"server": "hex", "tool": "search_projects", "input": {"query": "customer analytics"}},
        "tool_result": {"projects": [{"id": "hex_001", "title": "Customer Retention Dashboard", "lastUpdated": "2026-02-10", "owner": "data-team"}, {"id": "hex_002", "title": "Customer Acquisition Funnel", "lastUpdated": "2026-02-08", "owner": "marketing"}, {"id": "hex_003", "title": "Customer Lifetime Value Analysis", "lastUpdated": "2026-01-30", "owner": "finance"}]},
        "assistant_response": "Found 3 customer analytics projects in Hex:\n\n1. **Customer Retention Dashboard** - Updated Feb 10 (data team)\n2. **Customer Acquisition Funnel** - Updated Feb 8 (marketing)\n3. **Customer Lifetime Value Analysis** - Updated Jan 30 (finance)\n\nWhich one do you want to dig into? I can start a Hex analysis thread on any of these.",
        "task_type": "data",
        "tags": ["mcp", "hex", "dashboards", "analytics"]
    },
    {
        "sample_id": "mcp_hex_analysis_thread_2",
        "user_request": "Start a Hex analysis thread to find out why our churn rate increased last month.",
        "reasoning": "Hex's create_thread tool launches an AI-powered analysis thread that can query data, run analyses, and provide insights. This is more powerful than manual querying because the Hex agent can iterate on the analysis.",
        "tool_invocation": {"server": "hex", "tool": "create_thread", "input": {"question": "Why did our customer churn rate increase in January 2026? Analyze by segment, plan type, and usage patterns.", "projectId": "hex_001"}},
        "tool_result": {"threadId": "thread_abc", "status": "analyzing", "preliminary_findings": "Churn rate increased from 3.2% to 5.1% in January. Initial analysis shows 72% of churned customers were on the Basic plan with < 3 logins in the past 30 days."},
        "assistant_response": "Started a Hex analysis thread on churn:\n\n**Preliminary findings**: Churn jumped from 3.2% to 5.1% in January. 72% of churned customers were on the Basic plan with very low engagement (< 3 logins/month).\n\nThe Hex agent is continuing to analyze by segment and usage patterns. Want me to check back for the full analysis, or ask a follow-up question?",
        "task_type": "data",
        "tags": ["mcp", "hex", "churn-analysis", "thread"]
    },
    {
        "sample_id": "mcp_hex_continue_thread_3",
        "user_request": "Check the results of that churn analysis thread.",
        "reasoning": "The get_thread tool retrieves the completed analysis from the Hex agent, including any SQL queries it ran and visualizations it generated.",
        "tool_invocation": {"server": "hex", "tool": "get_thread", "input": {"threadId": "thread_abc"}},
        "tool_result": {"threadId": "thread_abc", "status": "complete", "findings": {"churn_rate_change": "+1.9pp (3.2% → 5.1%)", "top_factors": [{"factor": "Basic plan, low engagement", "contribution": "72%", "detail": "Users with < 3 logins and no feature adoption in 30 days"}, {"factor": "Price increase impact", "contribution": "18%", "detail": "Basic plan price increased $5/mo in December"}, {"factor": "Competitor migration", "contribution": "10%", "detail": "Exit surveys mention competitor X"}], "recommendation": "Target low-engagement Basic plan users with re-engagement campaign before they churn. Consider grandfathering existing Basic users at old price."}},
        "assistant_response": "Churn analysis complete. The +1.9pp increase breaks down:\n\n1. **Low engagement on Basic plan** (72% of churn) - Users with <3 logins and no feature adoption\n2. **Price increase impact** (18%) - The $5/mo Basic plan increase in December triggered cancellations\n3. **Competitor migration** (10%) - Exit surveys mention competitor X\n\n**Recommendation**: Launch a re-engagement campaign targeting low-engagement Basic users. Consider grandfathering existing Basic users at the old price to stem the price-driven churn.\n\nThe price increase + lack of engagement is a toxic combination. Users who don't see value will leave when the price goes up.",
        "task_type": "data",
        "tags": ["mcp", "hex", "churn", "analysis-results"]
    },
]

# ============================================================
# WRITE THE FILE
# ============================================================
output_path = "/home/shax/Desktop/24D/chatgpt_tool_training_pack/mcp_tool_training_samples.jsonl"
with open(output_path, "w") as f:
    for sample in samples:
        f.write(json.dumps(sample, ensure_ascii=False) + "\n")

print(f"Written {len(samples)} samples to {output_path}")

# Stats
from collections import Counter
servers = Counter(s["tool_invocation"]["server"] for s in samples)
print(f"\nBy server:")
for server, count in sorted(servers.items(), key=lambda x: -x[1]):
    print(f"  {server}: {count}")

print(f"\nBy task type:")
types = Counter(s["task_type"] for s in samples)
for t, count in sorted(types.items(), key=lambda x: -x[1]):
    print(f"  {t}: {count}")
