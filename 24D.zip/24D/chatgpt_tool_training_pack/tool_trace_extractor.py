#!/usr/bin/env python3
"""
Tool Trace Extractor - Parses Claude Code session transcripts into clean tool-call logs.

Extracts: tool invocations, inputs, outputs, durations, file diffs, errors.
Output: JSONL traces for ChatGPT autonomy training.

Usage:
    # Extract from most recent session
    python3 tool_trace_extractor.py

    # Extract from specific session file
    python3 tool_trace_extractor.py /path/to/session.jsonl

    # Extract with subagent traces included
    python3 tool_trace_extractor.py --include-subagents

    # Filter by tool name
    python3 tool_trace_extractor.py --tool Bash
    python3 tool_trace_extractor.py --tool WebFetch,Edit,Write

    # Output as human-readable (default is JSONL)
    python3 tool_trace_extractor.py --format human
"""

import json
import sys
import os
import glob
import argparse
from datetime import datetime, timezone
from pathlib import Path
from collections import defaultdict


def find_latest_session(base_dir=None):
    """Find the most recent session JSONL file."""
    if base_dir is None:
        # Check all Hannah directories, use the most recent
        hannah_base = Path.home() / "Hannah"
        candidates = sorted(hannah_base.glob("Hannah*/projects"), reverse=True)
        base_dir = candidates[0] if candidates else hannah_base / "Hannah4" / "projects"

    pattern = str(base_dir / "**" / "*.jsonl")
    files = glob.glob(pattern, recursive=False)
    # Only top-level session files, not subagent files
    session_files = [f for f in files if "/subagents/" not in f]

    if not session_files:
        # Try one level deeper
        for d in Path(base_dir).iterdir():
            if d.is_dir():
                for f in d.glob("*.jsonl"):
                    if "subagents" not in str(f):
                        session_files.append(str(f))

    if not session_files:
        print("No session files found", file=sys.stderr)
        sys.exit(1)

    return max(session_files, key=os.path.getmtime)


def find_subagent_files(session_file):
    """Find all subagent JSONL files for a session."""
    session_dir = Path(session_file).parent / Path(session_file).stem / "subagents"
    if not session_dir.exists():
        return []
    return sorted(session_dir.glob("agent-*.jsonl"), key=os.path.getmtime)


def parse_session(filepath):
    """Parse a JSONL session file into records."""
    records = []
    with open(filepath, "r") as f:
        for line_num, line in enumerate(f, 1):
            line = line.strip()
            if not line:
                continue
            try:
                record = json.loads(line)
                record["_line"] = line_num
                record["_file"] = str(filepath)
                records.append(record)
            except json.JSONDecodeError:
                pass
    return records


def extract_traces(records, source_label="main"):
    """Extract tool-call traces from parsed records.

    Returns list of trace dicts:
    {
        "timestamp": ISO string,
        "tool": tool name,
        "tool_use_id": matching ID,
        "input": tool input dict,
        "output": tool output string (truncated),
        "output_structured": structured result if available,
        "duration_ms": time between invoke and result,
        "success": bool,
        "error": error message if failed,
        "model": which model made the call,
        "source": "main" or "subagent:ID",
        "file_diff": {original, modified, path} if Write/Edit,
    }
    """
    # Index: tool_use_id -> tool_use record
    tool_uses = {}
    # Index: tool_use_id -> tool_result record
    tool_results = {}

    for record in records:
        rec_type = record.get("type")
        msg = record.get("message", {})
        content = msg.get("content", [])

        if isinstance(content, str):
            continue

        for block in content:
            if not isinstance(block, dict):
                continue

            if block.get("type") == "tool_use":
                tool_id = block.get("id")
                if tool_id:
                    tool_uses[tool_id] = {
                        "record": record,
                        "block": block,
                    }

            elif block.get("type") == "tool_result":
                tool_id = block.get("tool_use_id")
                if tool_id:
                    tool_results[tool_id] = {
                        "record": record,
                        "block": block,
                    }

    # Match tool_use -> tool_result pairs
    traces = []
    for tool_id, use_data in tool_uses.items():
        use_record = use_data["record"]
        use_block = use_data["block"]

        trace = {
            "timestamp": use_record.get("timestamp", ""),
            "tool": use_block.get("name", "unknown"),
            "tool_use_id": tool_id,
            "input": use_block.get("input", {}),
            "output": None,
            "output_structured": None,
            "duration_ms": None,
            "success": None,
            "error": None,
            "model": use_record.get("message", {}).get("model", ""),
            "source": source_label,
            "file_diff": None,
        }

        # Match result
        if tool_id in tool_results:
            res_data = tool_results[tool_id]
            res_record = res_data["record"]
            res_block = res_data["block"]

            # Output content
            output = res_block.get("content", "")
            if isinstance(output, list):
                output = "\n".join(
                    b.get("text", str(b)) if isinstance(b, dict) else str(b)
                    for b in output
                )

            trace["output"] = output[:2000] if len(str(output)) > 2000 else output
            trace["success"] = not res_block.get("is_error", False)

            if res_block.get("is_error"):
                trace["error"] = output[:500]

            # Duration
            try:
                t_use = datetime.fromisoformat(
                    use_record.get("timestamp", "").replace("Z", "+00:00")
                )
                t_res = datetime.fromisoformat(
                    res_record.get("timestamp", "").replace("Z", "+00:00")
                )
                trace["duration_ms"] = int((t_res - t_use).total_seconds() * 1000)
            except (ValueError, TypeError):
                pass

            # Structured result (file diffs, etc.)
            tool_use_result = res_record.get("toolUseResult")
            if tool_use_result and isinstance(tool_use_result, dict):
                result_type = tool_use_result.get("type")
                if result_type == "update":
                    trace["file_diff"] = {
                        "path": tool_use_result.get("filePath", ""),
                        "had_original": bool(tool_use_result.get("originalFile")),
                        "patch_available": bool(
                            tool_use_result.get("structuredPatch")
                        ),
                    }
                elif result_type == "text" and tool_use_result.get("file"):
                    file_info = tool_use_result["file"]
                    trace["output_structured"] = {
                        "type": "file_read",
                        "path": file_info.get("filePath", ""),
                        "lines": file_info.get("numLines", 0),
                        "total_lines": file_info.get("totalLines", 0),
                    }

        traces.append(trace)

    return sorted(traces, key=lambda t: t.get("timestamp", ""))


def format_human(trace):
    """Format a single trace for human reading."""
    lines = []
    ts = trace["timestamp"][:19].replace("T", " ") if trace["timestamp"] else "???"
    tool = trace["tool"]
    source = trace["source"]
    success = "OK" if trace["success"] else "FAIL" if trace["success"] is False else "?"
    dur = f"{trace['duration_ms']}ms" if trace["duration_ms"] is not None else "?"

    lines.append(f"[{ts}] {tool} ({source}) [{success}] [{dur}]")

    # Input summary
    inp = trace["input"]
    if tool == "Bash":
        lines.append(f"  $ {inp.get('command', '???')}")
        if inp.get("description"):
            lines.append(f"  # {inp['description']}")
    elif tool == "Read":
        lines.append(f"  file: {inp.get('file_path', '???')}")
        if inp.get("offset"):
            lines.append(f"  offset: {inp['offset']}, limit: {inp.get('limit', 'all')}")
    elif tool == "Write":
        path = inp.get("file_path", "???")
        content = inp.get("content", "")
        lines.append(f"  file: {path} ({len(content)} chars)")
    elif tool == "Edit":
        path = inp.get("file_path", "???")
        old = inp.get("old_string", "")[:80]
        new = inp.get("new_string", "")[:80]
        lines.append(f"  file: {path}")
        lines.append(f"  - {old}...")
        lines.append(f"  + {new}...")
    elif tool == "Glob":
        lines.append(f"  pattern: {inp.get('pattern', '???')}")
        if inp.get("path"):
            lines.append(f"  in: {inp['path']}")
    elif tool == "Grep":
        lines.append(f"  pattern: {inp.get('pattern', '???')}")
        if inp.get("path"):
            lines.append(f"  in: {inp['path']}")
    elif tool == "WebFetch":
        lines.append(f"  url: {inp.get('url', '???')}")
        lines.append(f"  prompt: {inp.get('prompt', '???')[:100]}")
    elif tool == "WebSearch":
        lines.append(f"  query: {inp.get('query', '???')}")
    elif tool == "Task":
        lines.append(f"  type: {inp.get('subagent_type', '???')}")
        lines.append(f"  desc: {inp.get('description', '???')}")
        prompt = inp.get("prompt", "")[:150]
        lines.append(f"  prompt: {prompt}...")
    elif tool == "TaskCreate":
        lines.append(f"  subject: {inp.get('subject', '???')}")
        if inp.get('description'):
            lines.append(f"  desc: {inp['description'][:150]}")
        if inp.get('activeForm'):
            lines.append(f"  activeForm: {inp['activeForm']}")
    elif tool == "TaskUpdate":
        lines.append(f"  taskId: {inp.get('taskId', '???')}")
        if inp.get('status'):
            lines.append(f"  status: {inp['status']}")
        if inp.get('subject'):
            lines.append(f"  subject: {inp['subject']}")
        if inp.get('addBlockedBy'):
            lines.append(f"  blockedBy: {inp['addBlockedBy']}")
    elif tool == "TaskGet":
        lines.append(f"  taskId: {inp.get('taskId', '???')}")
    elif tool == "TaskList":
        lines.append("  (list all tasks)")
    elif tool == "TaskOutput":
        lines.append(f"  task_id: {inp.get('task_id', '???')}")
        lines.append(f"  block: {inp.get('block', True)}")
    elif tool == "TaskStop":
        lines.append(f"  task_id: {inp.get('task_id', '???')}")
    elif tool == "Skill":
        lines.append(f"  skill: {inp.get('skill', '???')}")
        if inp.get('args'):
            lines.append(f"  args: {inp['args'][:150]}")
    elif tool == "AskUserQuestion":
        questions = inp.get('questions', [])
        for q in questions[:3]:
            lines.append(f"  Q: {q.get('question', '???')[:100]}")
            opts = q.get('options', [])
            for o in opts[:4]:
                lines.append(f"    - {o.get('label', '???')}")
    elif tool == "EnterPlanMode":
        lines.append("  (entering plan mode)")
    elif tool == "ExitPlanMode":
        lines.append("  (exiting plan mode, requesting approval)")
    elif tool == "NotebookEdit":
        lines.append(f"  notebook: {inp.get('notebook_path', '???')}")
        lines.append(f"  mode: {inp.get('edit_mode', 'replace')}")
        if inp.get('cell_type'):
            lines.append(f"  cell_type: {inp['cell_type']}")
    else:
        for k, v in inp.items():
            val = str(v)[:100]
            lines.append(f"  {k}: {val}")

    # Output summary
    if trace["error"]:
        lines.append(f"  ERROR: {trace['error'][:200]}")
    elif trace["output"]:
        out = str(trace["output"])
        if len(out) > 200:
            lines.append(f"  -> {out[:200]}... ({len(out)} chars)")
        else:
            lines.append(f"  -> {out}")

    if trace["file_diff"]:
        lines.append(f"  DIFF: {trace['file_diff']['path']}")

    return "\n".join(lines)


def main():
    parser = argparse.ArgumentParser(
        description="Extract tool-call traces from Claude Code session transcripts"
    )
    parser.add_argument(
        "session_file", nargs="?", help="Path to session JSONL file (default: most recent)"
    )
    parser.add_argument(
        "--include-subagents", action="store_true", help="Include subagent traces"
    )
    parser.add_argument(
        "--tool", help="Filter by tool name (comma-separated, e.g. Bash,Edit,Write)"
    )
    parser.add_argument(
        "--format",
        choices=["jsonl", "human", "summary"],
        default="jsonl",
        help="Output format (default: jsonl)",
    )
    parser.add_argument(
        "--output", "-o", help="Output file (default: stdout)"
    )
    parser.add_argument(
        "--last", type=int, help="Only show last N traces"
    )
    parser.add_argument(
        "--errors-only", action="store_true", help="Only show failed tool calls"
    )

    args = parser.parse_args()

    # Find session file
    session_file = args.session_file or find_latest_session()
    print(f"Parsing: {session_file}", file=sys.stderr)

    # Parse main session
    records = parse_session(session_file)
    all_traces = extract_traces(records, source_label="main")

    # Parse subagents if requested
    if args.include_subagents:
        subagent_files = find_subagent_files(session_file)
        print(f"Found {len(subagent_files)} subagent files", file=sys.stderr)
        for sf in subagent_files:
            agent_id = sf.stem.replace("agent-", "")
            sub_records = parse_session(sf)
            sub_traces = extract_traces(sub_records, source_label=f"subagent:{agent_id}")
            all_traces.extend(sub_traces)

    # Sort by timestamp
    all_traces.sort(key=lambda t: t.get("timestamp", ""))

    # Apply filters
    if args.tool:
        tool_filter = set(args.tool.split(","))
        all_traces = [t for t in all_traces if t["tool"] in tool_filter]

    if args.errors_only:
        all_traces = [t for t in all_traces if t["success"] is False]

    if args.last:
        all_traces = all_traces[-args.last :]

    # Stats
    tool_counts = defaultdict(int)
    error_count = 0
    for t in all_traces:
        tool_counts[t["tool"]] += 1
        if t["success"] is False:
            error_count += 1

    print(
        f"Extracted {len(all_traces)} traces ({error_count} errors) from {len(records)} records",
        file=sys.stderr,
    )

    # Output
    out = open(args.output, "w") if args.output else sys.stdout

    if args.format == "summary":
        out.write(f"Session: {session_file}\n")
        out.write(f"Records: {len(records)}\n")
        out.write(f"Tool calls: {len(all_traces)}\n")
        out.write(f"Errors: {error_count}\n")
        out.write(f"\nBy tool:\n")
        for tool, count in sorted(tool_counts.items(), key=lambda x: -x[1]):
            out.write(f"  {tool}: {count}\n")

    elif args.format == "human":
        for trace in all_traces:
            out.write(format_human(trace) + "\n\n")

    elif args.format == "jsonl":
        for trace in all_traces:
            out.write(json.dumps(trace, default=str) + "\n")

    if args.output:
        out.close()
        print(f"Written to {args.output}", file=sys.stderr)


if __name__ == "__main__":
    main()
