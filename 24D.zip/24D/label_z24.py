#!/usr/bin/env python3
"""
label_z24.py - z24 dimension labeler using LLM judge

Uses Claude Opus or GPT-4 to score conversation windows on the 24-dimensional
operator fingerprint (z24).

Author: 24D Trainer Pipeline
"""

import json
import logging
import time
import os
from pathlib import Path
from datetime import datetime
from typing import List, Dict, Any, Optional, Generator
from dataclasses import dataclass, asdict
import argparse
from tqdm import tqdm
import yaml

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


@dataclass
class Z24Label:
    """Labeled z24 data for a conversation window."""
    id: str
    conversation_id: str
    window_text: str
    z24: List[float]  # 24 floats
    notes: List[str]  # 24 short explanations
    confidence: float
    meta: Dict[str, Any]
    
    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


class DimensionConfig:
    """Loads and manages z24 dimension definitions."""
    
    def __init__(self, config_path: Path):
        with open(config_path, 'r') as f:
            self.config = yaml.safe_load(f)
        
        self.dimensions = {}
        
        # Load coherence BIOS (D1-D10)
        for i, (key, dim) in enumerate(self.config['coherence_bios'].items(), 1):
            self.dimensions[f"D{i}"] = dim
        
        # Load operator traits (D11-D24)
        for i, (key, dim) in enumerate(self.config['operator_traits'].items(), 11):
            self.dimensions[f"D{i}"] = dim
    
    def build_rubric_prompt(self) -> str:
        """Build the scoring rubric section of the prompt."""
        lines = []
        for dim_key in sorted(self.dimensions.keys(), key=lambda x: int(x[1:])):
            dim = self.dimensions[dim_key]
            lines.append(f"{dim_key} ({dim['name']}): {dim['rubric']}")
        return '\n'.join(lines)


class LLMJudge:
    """Base class for LLM judges."""
    
    def score(self, window_text: str, rubric: str) -> Dict[str, Any]:
        raise NotImplementedError


class AnthropicJudge(LLMJudge):
    """Claude-based judge."""
    
    def __init__(self, model: str = "claude-opus-4-6"):
        try:
            from anthropic import Anthropic
            self.client = Anthropic()
            self.model = model
        except ImportError:
            raise ImportError("anthropic package required. Install with: pip install anthropic")
    
    def score(self, window_text: str, rubric: str) -> Dict[str, Any]:
        prompt = self._build_prompt(window_text, rubric)
        
        response = self.client.messages.create(
            model=self.model,
            max_tokens=2000,
            messages=[
                {"role": "user", "content": prompt}
            ]
        )
        
        return self._parse_response(response.content[0].text)
    
    def _build_prompt(self, window_text: str, rubric: str) -> str:
        return f"""You are scoring a conversation window for a 24-dimensional operator style vector (z24).

Each dimension is scored 0.0 to 1.0 where:
- 0.0 = completely absent or violated
- 0.5 = neutral/average
- 1.0 = exemplary demonstration

## Scoring Rubrics:

{rubric}

## Conversation Window:

{window_text}

## Instructions:

Score the ASSISTANT's behavior in this window on all 24 dimensions.
Focus on the most recent assistant response, using prior context for understanding.

Return ONLY valid JSON with no markdown formatting:
{{
  "z24": [24 floats between 0.0 and 1.0, in order D1-D24],
  "notes": [24 strings, max 12 words each, explaining each score],
  "confidence": float between 0.0 and 1.0
}}"""
    
    def _parse_response(self, text: str) -> Dict[str, Any]:
        """Parse JSON from LLM response."""
        # Clean up potential markdown formatting
        text = text.strip()
        if text.startswith('```'):
            lines = text.split('\n')
            text = '\n'.join(lines[1:-1])
        
        try:
            data = json.loads(text)
            
            # Validate structure
            assert 'z24' in data and len(data['z24']) == 24
            assert 'notes' in data and len(data['notes']) == 24
            assert 'confidence' in data
            
            # Clamp values
            data['z24'] = [max(0.0, min(1.0, float(v))) for v in data['z24']]
            data['confidence'] = max(0.0, min(1.0, float(data['confidence'])))
            
            return data
        except (json.JSONDecodeError, AssertionError, ValueError) as e:
            logger.warning(f"Failed to parse LLM response: {e}")
            return None


class OpenAIJudge(LLMJudge):
    """GPT-4 based judge."""
    
    def __init__(self, model: str = "gpt-4-turbo"):
        try:
            from openai import OpenAI
            self.client = OpenAI()
            self.model = model
        except ImportError:
            raise ImportError("openai package required. Install with: pip install openai")
    
    def score(self, window_text: str, rubric: str) -> Dict[str, Any]:
        prompt = self._build_prompt(window_text, rubric)
        
        response = self.client.chat.completions.create(
            model=self.model,
            messages=[
                {"role": "user", "content": prompt}
            ],
            response_format={"type": "json_object"}
        )
        
        return self._parse_response(response.choices[0].message.content)
    
    def _build_prompt(self, window_text: str, rubric: str) -> str:
        return AnthropicJudge._build_prompt(self, window_text, rubric)
    
    def _parse_response(self, text: str) -> Dict[str, Any]:
        return AnthropicJudge._parse_response(self, text)


class WindowBuilder:
    """Builds context windows from normalized conversations."""
    
    def __init__(self, window_size: int = 20, min_window_size: int = 3):
        self.window_size = window_size
        self.min_window_size = min_window_size
    
    def build_windows(self, turns: List[Dict]) -> Generator[Dict, None, None]:
        """Build windows for each assistant turn."""
        # Group by conversation
        conversations = {}
        for turn in turns:
            conv_id = turn['conversation_id']
            if conv_id not in conversations:
                conversations[conv_id] = []
            conversations[conv_id].append(turn)
        
        # Sort each conversation by timestamp
        for conv_id, conv_turns in conversations.items():
            conv_turns.sort(key=lambda x: x['timestamp'])
            
            for i, turn in enumerate(conv_turns):
                # Only label assistant turns
                if turn['role'] != 'assistant':
                    continue
                
                # Get window (prior N turns including this one)
                start_idx = max(0, i - self.window_size + 1)
                window_turns = conv_turns[start_idx:i + 1]
                
                # Skip if window too small
                if len(window_turns) < self.min_window_size:
                    continue
                
                # Format window text
                window_text = self._format_window(window_turns)
                
                yield {
                    'id': turn['id'],
                    'conversation_id': conv_id,
                    'window_text': window_text,
                    'window_size': len(window_turns),
                    'timestamp': turn['timestamp']
                }
    
    def _format_window(self, turns: List[Dict]) -> str:
        """Format turns into readable window text."""
        lines = []
        for turn in turns:
            role = turn['role'].upper()
            content = turn['content']
            # Truncate very long content
            if len(content) > 2000:
                content = content[:2000] + "... [truncated]"
            lines.append(f"[{role}]: {content}")
        return '\n\n'.join(lines)


class CheckpointManager:
    """Manages labeling checkpoints."""
    
    def __init__(self, checkpoint_path: Path):
        self.checkpoint_path = checkpoint_path
        self.labeled_ids: set = set()
        self.total_cost: float = 0.0
        self.load()
    
    def load(self):
        if self.checkpoint_path.exists():
            with open(self.checkpoint_path, 'r') as f:
                data = json.load(f)
                self.labeled_ids = set(data.get('labeled_ids', []))
                self.total_cost = data.get('total_cost', 0.0)
            logger.info(f"Loaded checkpoint: {len(self.labeled_ids)} labeled")
    
    def save(self):
        with open(self.checkpoint_path, 'w') as f:
            json.dump({
                'labeled_ids': list(self.labeled_ids),
                'total_cost': self.total_cost,
                'timestamp': datetime.now().isoformat()
            }, f)
    
    def is_labeled(self, turn_id: str) -> bool:
        return turn_id in self.labeled_ids
    
    def mark_labeled(self, turn_id: str):
        self.labeled_ids.add(turn_id)
    
    def add_cost(self, cost: float):
        self.total_cost += cost


class Z24Labeler:
    """Main labeling pipeline."""
    
    def __init__(
        self,
        judge: LLMJudge,
        dimensions: DimensionConfig,
        output_path: Path,
        checkpoint_dir: Path,
        rate_limit_rpm: int = 50,
        min_confidence: float = 0.5
    ):
        self.judge = judge
        self.dimensions = dimensions
        self.rubric = dimensions.build_rubric_prompt()
        self.output_path = output_path
        self.checkpoint = CheckpointManager(checkpoint_dir / 'label_checkpoint.json')
        self.rate_limit_delay = 60.0 / rate_limit_rpm
        self.min_confidence = min_confidence
        self.window_builder = WindowBuilder()
        
        self.stats = {
            'total_windows': 0,
            'labeled': 0,
            'skipped_low_confidence': 0,
            'errors': 0
        }
    
    def load_normalized_data(self, input_path: Path) -> List[Dict]:
        """Load normalized JSONL (per-turn format from normalize_logs.py)."""
        turns = []
        with open(input_path, 'r') as f:
            for line in f:
                if line.strip():
                    turns.append(json.loads(line))
        logger.info(f"Loaded {len(turns)} turns from {input_path}")
        return turns

    def load_prepped_data(self, input_path: Path) -> List[Dict]:
        """Load prepped JSONL (pre-windowed samples from z24_data_prepper.py).

        Maps TrainingSample format to the window format expected by the judge:
        - sample_id -> id
        - context + response -> window_text
        - metadata fields pulled to top level
        """
        windows = []
        with open(input_path, 'r') as f:
            for line in f:
                if not line.strip():
                    continue
                sample = json.loads(line)

                # Build window text: context already formatted, append response
                window_text = sample['context']
                if window_text:
                    window_text += '\n\n'
                window_text += f"[ASSISTANT]: {sample['response']}"

                meta = sample.get('metadata', {})
                windows.append({
                    'id': sample['sample_id'],
                    'conversation_id': meta.get('conversation_id', ''),
                    'window_text': window_text,
                    'window_size': meta.get('context_turns', 0) + 1,
                    'timestamp': meta.get('timestamp', ''),
                    'task_type': sample.get('task_type', 'qa'),
                    'source': sample.get('source', 'unknown')
                })

        logger.info(f"Loaded {len(windows)} prepped samples from {input_path}")
        return windows

    def label_all(self, input_path: Path, resume: bool = True, prepped: bool = False):
        """Label all windows in input data.

        Args:
            input_path: Path to input JSONL
            resume: Whether to skip already-labeled windows
            prepped: If True, input is z24_data_prepper.py output (pre-windowed)
        """
        if prepped:
            windows = self.load_prepped_data(input_path)
        else:
            turns = self.load_normalized_data(input_path)
            windows = list(self.window_builder.build_windows(turns))
        logger.info(f"Built {len(windows)} windows to label")
        
        with open(self.output_path, 'a') as out_f:
            for window in tqdm(windows, desc="Labeling"):
                self.stats['total_windows'] += 1
                
                # Skip if already labeled
                if resume and self.checkpoint.is_labeled(window['id']):
                    continue
                
                try:
                    # Rate limiting
                    time.sleep(self.rate_limit_delay)
                    
                    # Get z24 scores
                    result = self.judge.score(window['window_text'], self.rubric)
                    
                    if result is None:
                        self.stats['errors'] += 1
                        continue
                    
                    # Skip low confidence
                    if result['confidence'] < self.min_confidence:
                        self.stats['skipped_low_confidence'] += 1
                        continue
                    
                    # Create label record
                    meta = {
                        'window_size': window['window_size'],
                        'labeled_at': datetime.now().isoformat(),
                        'judge_model': getattr(self.judge, 'model', 'unknown')
                    }
                    # Carry forward prepper metadata if present
                    if 'task_type' in window:
                        meta['task_type'] = window['task_type']
                    if 'source' in window:
                        meta['source'] = window['source']

                    label = Z24Label(
                        id=window['id'],
                        conversation_id=window['conversation_id'],
                        window_text=window['window_text'],
                        z24=result['z24'],
                        notes=result['notes'],
                        confidence=result['confidence'],
                        meta=meta
                    )
                    
                    # Write
                    out_f.write(json.dumps(label.to_dict()) + '\n')
                    out_f.flush()
                    
                    self.checkpoint.mark_labeled(window['id'])
                    self.stats['labeled'] += 1
                    
                    # Periodic checkpoint
                    if self.stats['labeled'] % 100 == 0:
                        self.checkpoint.save()
                        logger.info(f"Progress: {self.stats['labeled']} labeled")
                    
                except Exception as e:
                    logger.error(f"Error labeling {window['id']}: {e}")
                    self.stats['errors'] += 1
        
        self.checkpoint.save()
        self.print_stats()
    
    def print_stats(self):
        logger.info("=" * 50)
        logger.info("Labeling Complete")
        logger.info(f"  Total windows: {self.stats['total_windows']}")
        logger.info(f"  Successfully labeled: {self.stats['labeled']}")
        logger.info(f"  Skipped (low confidence): {self.stats['skipped_low_confidence']}")
        logger.info(f"  Errors: {self.stats['errors']}")
        logger.info(f"  Estimated cost: ${self.checkpoint.total_cost:.2f}")
        logger.info("=" * 50)


def main():
    parser = argparse.ArgumentParser(
        description='Label conversation windows with z24 scores using LLM judge'
    )
    parser.add_argument(
        'input',
        type=Path,
        help='Normalized JSONL file from normalize_logs.py'
    )
    parser.add_argument(
        '-o', '--output',
        type=Path,
        default=Path('data/labeled/z24_labels.jsonl'),
        help='Output labeled JSONL file'
    )
    parser.add_argument(
        '-c', '--checkpoint-dir',
        type=Path,
        default=Path('data/labeled'),
        help='Directory for checkpoint files'
    )
    parser.add_argument(
        '-d', '--dimensions',
        type=Path,
        default=Path('config/dimensions.yaml'),
        help='Path to dimensions config'
    )
    parser.add_argument(
        '--provider',
        choices=['anthropic', 'openai'],
        default='anthropic',
        help='LLM provider to use'
    )
    parser.add_argument(
        '--model',
        default=None,
        help='Specific model to use (default: claude-opus-4-6 or gpt-4-turbo)'
    )
    parser.add_argument(
        '--rate-limit',
        type=int,
        default=50,
        help='Requests per minute'
    )
    parser.add_argument(
        '--min-confidence',
        type=float,
        default=0.5,
        help='Minimum confidence threshold'
    )
    parser.add_argument(
        '--prepped',
        action='store_true',
        help='Input is pre-windowed output from z24_data_prepper.py'
    )
    parser.add_argument(
        '--no-resume',
        action='store_true',
        help='Start fresh'
    )
    
    args = parser.parse_args()
    
    # Setup directories
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.checkpoint_dir.mkdir(parents=True, exist_ok=True)
    
    # Load dimensions
    dimensions = DimensionConfig(args.dimensions)
    
    # Create judge
    if args.provider == 'anthropic':
        model = args.model or 'claude-opus-4-6'
        judge = AnthropicJudge(model)
    else:
        model = args.model or 'gpt-4-turbo'
        judge = OpenAIJudge(model)
    
    # Clear output if not resuming
    if args.no_resume and args.output.exists():
        args.output.unlink()
    
    # Run labeler
    labeler = Z24Labeler(
        judge=judge,
        dimensions=dimensions,
        output_path=args.output,
        checkpoint_dir=args.checkpoint_dir,
        rate_limit_rpm=args.rate_limit,
        min_confidence=args.min_confidence
    )
    
    labeler.label_all(args.input, resume=not args.no_resume, prepped=args.prepped)


if __name__ == '__main__':
    main()
