
"""
z24_dataset.py

Data pipeline for Z24 training.

- Supports JSON (list of records) and JSONL (one record per line)
- Schema per record:
    {
      "context": "...",
      "response": "...",
      "labels": { "D1": 0.8, ..., "D24": 0.3 }   # partial labels allowed
    }

Outputs per sample:
  - input_ids, attention_mask, (optional) token_type_ids
  - labels: FloatTensor[24] (missing labels filled with 0)
  - label_mask: BoolTensor[24] (True where label exists)

Dependencies: torch, transformers, numpy
Python: 3.10+
"""

from __future__ import annotations

import json
import os
import random
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Sequence, Tuple, Union

import numpy as np
import torch
from torch.utils.data import Dataset, DataLoader, Subset
from transformers import PreTrainedTokenizerBase


DIMENSION_KEYS: List[str] = [f"D{i}" for i in range(1, 25)]


def _normalize_dim_key(k: str) -> str:
    return k.strip().replace(" ", "").replace("-", "_")


def _extract_dim_value(labels: Dict[str, Any], dim_index_1based: int) -> Optional[float]:
    """
    Robustly extract a dimension label from a labels dict.

    Accepts keys like:
      - "D1"
      - "d1"
      - "D1_Truth"
      - "D1_TRUTH"
      - "D01"
      - "dimension_1"
    """
    if not labels:
        return None

    target_prefixes = [
        f"d{dim_index_1based}",
        f"d{dim_index_1based:02d}",
        f"dimension_{dim_index_1based}",
    ]

    # Direct hits first
    for key in [f"D{dim_index_1based}", f"d{dim_index_1based}", f"D{dim_index_1based:02d}", f"d{dim_index_1based:02d}"]:
        if key in labels:
            try:
                return float(labels[key])
            except Exception:
                return None

    # Prefix search
    for k, v in labels.items():
        nk = _normalize_dim_key(str(k)).lower()
        if any(nk == p or nk.startswith(p + "_") for p in target_prefixes):
            try:
                return float(v)
            except Exception:
                return None

    return None


@dataclass
class Z24Sample:
    context: str
    response: str
    labels: Dict[str, Any]


class Z24Dataset(Dataset):
    """
    Z24 Dataset that supports JSON and JSONL input.

    For JSONL, it builds an offset index for random access without loading all content.
    """

    def __init__(
        self,
        data_path: Union[str, os.PathLike],
        tokenizer: PreTrainedTokenizerBase,
        max_length: int = 512,
        pair_format: str = "text_pair",
        concat_template: str = "[CONTEXT]\n{context}\n\n[RESPONSE]\n{response}",
        build_index: bool = True,
        index_cache_path: Optional[Union[str, os.PathLike]] = None,
    ) -> None:
        super().__init__()
        self.data_path = Path(data_path)
        self.tokenizer = tokenizer
        self.max_length = int(max_length)
        self.pair_format = pair_format
        self.concat_template = concat_template

        if not self.data_path.exists():
            raise FileNotFoundError(f"Data file not found: {self.data_path}")

        self.is_jsonl = self.data_path.suffix.lower() in {".jsonl", ".jl", ".jsonlines"}
        self._json_data: Optional[List[Dict[str, Any]]] = None
        self._offsets: Optional[List[int]] = None

        if self.is_jsonl:
            self._init_jsonl_index(build_index=build_index, index_cache_path=index_cache_path)
        else:
            with self.data_path.open("r", encoding="utf-8") as f:
                loaded = json.load(f)
            if not isinstance(loaded, list):
                raise ValueError("JSON file must contain a list of records.")
            self._json_data = loaded

    def _init_jsonl_index(self, build_index: bool, index_cache_path: Optional[Union[str, os.PathLike]]) -> None:
        cache_path = Path(index_cache_path) if index_cache_path is not None else self.data_path.with_suffix(self.data_path.suffix + ".idx")
        if cache_path.exists():
            try:
                offsets = np.load(cache_path, allow_pickle=False)
                self._offsets = [int(x) for x in offsets.tolist()]
                return
            except Exception:
                # fallback to rebuild
                pass

        if not build_index:
            raise ValueError("JSONL dataset requires an index (offsets) for random access.")

        offsets: List[int] = []
        with self.data_path.open("rb") as f:
            pos = f.tell()
            line = f.readline()
            while line:
                offsets.append(pos)
                pos = f.tell()
                line = f.readline()

        self._offsets = offsets
        try:
            np.save(cache_path, np.array(offsets, dtype=np.int64), allow_pickle=False)
        except Exception:
            # Caching is optional
            pass

    def __len__(self) -> int:
        if self.is_jsonl:
            assert self._offsets is not None
            return len(self._offsets)
        assert self._json_data is not None
        return len(self._json_data)

    def _read_jsonl_line(self, idx: int) -> Dict[str, Any]:
        assert self._offsets is not None
        offset = self._offsets[idx]
        with self.data_path.open("rb") as f:
            f.seek(offset)
            line = f.readline()
        try:
            return json.loads(line.decode("utf-8"))
        except json.JSONDecodeError as e:
            raise ValueError(f"Invalid JSON on line {idx} in {self.data_path}: {e}")

    def _get_record(self, idx: int) -> Dict[str, Any]:
        if self.is_jsonl:
            return self._read_jsonl_line(idx)
        assert self._json_data is not None
        return self._json_data[idx]

    def __getitem__(self, idx: int) -> Dict[str, Any]:
        rec = self._get_record(idx)

        context = str(rec.get("context", ""))
        response = str(rec.get("response", ""))
        labels_dict = rec.get("labels", {}) or {}

        # Tokenize
        if self.pair_format == "text_pair":
            encoded = self.tokenizer(
                context,
                response,
                truncation="longest_first",
                max_length=self.max_length,
                padding=False,
                return_tensors=None,
            )
        elif self.pair_format == "concat":
            text = self.concat_template.format(context=context, response=response)
            encoded = self.tokenizer(
                text,
                truncation=True,
                max_length=self.max_length,
                padding=False,
                return_tensors=None,
            )
        else:
            raise ValueError(f"Unknown pair_format: {self.pair_format}")

        # Build labels + mask
        labels = torch.zeros(24, dtype=torch.float32)
        mask = torch.zeros(24, dtype=torch.bool)

        for i in range(1, 25):
            v = _extract_dim_value(labels_dict, i)
            if v is None:
                continue
            # Clamp to [0,1] defensively
            v = float(max(0.0, min(1.0, v)))
            labels[i - 1] = v
            mask[i - 1] = True

        item: Dict[str, Any] = {
            "input_ids": torch.tensor(encoded["input_ids"], dtype=torch.long),
            "attention_mask": torch.tensor(encoded["attention_mask"], dtype=torch.long),
            "labels": labels,
            "label_mask": mask,
        }

        if "token_type_ids" in encoded:
            item["token_type_ids"] = torch.tensor(encoded["token_type_ids"], dtype=torch.long)

        return item


def make_collate_fn(tokenizer: PreTrainedTokenizerBase) -> Callable[[Sequence[Dict[str, Any]]], Dict[str, Any]]:
    """
    Collate function to dynamically pad batch using tokenizer.pad().
    """

    def collate(batch: Sequence[Dict[str, Any]]) -> Dict[str, Any]:
        # Separate model inputs from labels
        model_inputs: List[Dict[str, Any]] = []
        labels = []
        masks = []
        has_token_type = "token_type_ids" in batch[0]

        for ex in batch:
            mi = {
                "input_ids": ex["input_ids"],
                "attention_mask": ex["attention_mask"],
            }
            if has_token_type and "token_type_ids" in ex:
                mi["token_type_ids"] = ex["token_type_ids"]
            model_inputs.append(mi)
            labels.append(ex["labels"])
            masks.append(ex["label_mask"])

        padded = tokenizer.pad(model_inputs, padding=True, return_tensors="pt")

        out: Dict[str, Any] = dict(padded)
        out["labels"] = torch.stack(labels, dim=0)
        out["label_mask"] = torch.stack(masks, dim=0)
        return out

    return collate


def get_z24_dataloaders(
    data_path: Union[str, os.PathLike],
    tokenizer: PreTrainedTokenizerBase,
    batch_size: int = 32,
    split_ratios: Tuple[float, float, float] = (0.7, 0.15, 0.15),
    max_length: int = 512,
    seed: int = 42,
    num_workers: int = 2,
    pin_memory: bool = True,
) -> Tuple[DataLoader, DataLoader, DataLoader]:
    """
    Build train/val/test DataLoaders from a single dataset file.

    Splits are random but deterministic via `seed`.

    Returns:
        train_loader, val_loader, test_loader
    """
    if not np.isclose(sum(split_ratios), 1.0):
        raise ValueError(f"split_ratios must sum to 1.0, got {split_ratios}")

    dataset = Z24Dataset(data_path=data_path, tokenizer=tokenizer, max_length=max_length)

    n = len(dataset)
    idxs = list(range(n))
    rng = random.Random(seed)
    rng.shuffle(idxs)

    n_train = int(split_ratios[0] * n)
    n_val = int(split_ratios[1] * n)
    n_test = n - n_train - n_val

    train_idxs = idxs[:n_train]
    val_idxs = idxs[n_train:n_train + n_val]
    test_idxs = idxs[n_train + n_val:]

    train_ds = Subset(dataset, train_idxs)
    val_ds = Subset(dataset, val_idxs)
    test_ds = Subset(dataset, test_idxs)

    collate_fn = make_collate_fn(tokenizer)

    train_loader = DataLoader(
        train_ds,
        batch_size=batch_size,
        shuffle=True,
        num_workers=num_workers,
        pin_memory=pin_memory,
        collate_fn=collate_fn,
        drop_last=False,
    )
    val_loader = DataLoader(
        val_ds,
        batch_size=batch_size,
        shuffle=False,
        num_workers=num_workers,
        pin_memory=pin_memory,
        collate_fn=collate_fn,
        drop_last=False,
    )
    test_loader = DataLoader(
        test_ds,
        batch_size=batch_size,
        shuffle=False,
        num_workers=num_workers,
        pin_memory=pin_memory,
        collate_fn=collate_fn,
        drop_last=False,
    )

    return train_loader, val_loader, test_loader
