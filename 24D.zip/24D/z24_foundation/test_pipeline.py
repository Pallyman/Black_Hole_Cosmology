
"""
test_pipeline.py

End-to-end smoke test for the Z24 stack:
- Create a tiny synthetic dataset (10 samples)
- Initialize tokenizer + model
- Build dataloaders
- Train for 1 epoch
- Evaluate and print report

Run:
    python test_pipeline.py

Dependencies: torch, transformers, numpy, scikit-learn, tqdm
"""

from __future__ import annotations

import json
import os
import random
from pathlib import Path
from typing import Dict, List

import numpy as np
import torch
from transformers import AutoTokenizer

from z24_encoder import Z24Encoder
from z24_dataset import get_z24_dataloaders
from z24_trainer import Z24Trainer
from z24_evaluator import Z24Evaluator


def _make_synth_record(i: int) -> Dict:
    context = f"User request #{i}: Please summarize the key points and provide actionable steps."
    response = (
        f"Here are the key points for request #{i}:\n"
        f"1) Identify goals\n"
        f"2) Gather evidence\n"
        f"3) Provide steps\n"
        f"Source: https://example.com\n"
    )
    labels = {f"D{d}": float(np.clip(np.random.rand(), 0.0, 1.0)) for d in range(1, 25)}

    # Randomly drop some labels to test partial-label handling
    for d in range(1, 25):
        if random.random() < 0.2:
            labels.pop(f"D{d}", None)

    return {"context": context, "response": response, "labels": labels}


def test_z24_pipeline(tmp_path: str = "./_z24_synth_data.jsonl") -> None:
    """
    End-to-end smoke test.
    Run this to verify all components work together.
    """
    random.seed(0)
    np.random.seed(0)
    torch.manual_seed(0)

    # 1) Create synthetic JSONL dataset
    path = Path(tmp_path)
    records: List[Dict] = [_make_synth_record(i) for i in range(10)]
    with path.open("w", encoding="utf-8") as f:
        for r in records:
            f.write(json.dumps(r) + "\n")

    # 2) Init tokenizer + dataloaders
    encoder_name = "sentence-transformers/all-MiniLM-L6-v2"
    tokenizer = AutoTokenizer.from_pretrained(encoder_name, use_fast=True)

    train_loader, val_loader, test_loader = get_z24_dataloaders(
        data_path=str(path),
        tokenizer=tokenizer,
        batch_size=4,
        split_ratios=(0.7, 0.2, 0.1),
        max_length=256,
        seed=42,
        num_workers=0,
    )

    # 3) Init model
    model = Z24Encoder(encoder_name=encoder_name)

    # 4) Train
    config = {
        "device": "cuda" if torch.cuda.is_available() else "cpu",
        "lr": 2e-5,
        "weight_decay": 0.01,
        "max_grad_norm": 1.0,
        "use_fp16": True,
        "gradient_accumulation_steps": 1,
        "num_epochs": 1,
        "warmup_ratio": 0.1,
        "log_every": 1,
        "val_every": 0,  # disable mid-epoch validation for tiny test
        "save_dir": "./_z24_checkpoints_test",
        "loss_type": "mse",  # or "heteroscedastic"
        "verbose": True,
    }
    trainer = Z24Trainer(model=model, train_loader=train_loader, val_loader=val_loader, config=config)
    trainer.train(num_epochs=1)

    # 5) Evaluate
    evaluator = Z24Evaluator(model=model, test_loader=test_loader, device=config["device"])
    metrics = evaluator.evaluate()
    report = evaluator.generate_report(metrics)

    print(report)

    # Cleanup (optional)
    # path.unlink(missing_ok=True)


if __name__ == "__main__":
    test_z24_pipeline()
