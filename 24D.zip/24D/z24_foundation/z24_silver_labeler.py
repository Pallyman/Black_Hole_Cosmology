"""
z24_silver_labeler.py

SILVER LABELING PIPELINE
========================

Generates bootstrap Z24 labels for unlabeled conversation data using Claude API.

Architecture:
1. Load unlabeled samples from corpus
2. Batch samples for efficient API calls
3. Call Claude to score each on 24 dimensions
4. Parse responses and validate
5. Save labeled samples back to corpus

Features:
- Async batching for throughput
- Retry logic with exponential backoff
- Validation and sanity checking
- Progress tracking and checkpointing
- Cost estimation

Dependencies: anthropic, aiohttp, tqdm
Python: 3.10+

Author: Hannah (Claude)
Date: February 12, 2026
"""

from __future__ import annotations

import asyncio
import json
import os
import random
import re
import time
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple
import logging

try:
    import anthropic
    HAS_ANTHROPIC = True
except ImportError:
    HAS_ANTHROPIC = False

try:
    import openai
    HAS_OPENAI = True
except ImportError:
    HAS_OPENAI = False

from z24_dimensions import ALL_DIMENSIONS, get_labeling_prompt, DIMENSION_BY_ID


logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


# =============================================================================
# Configuration
# =============================================================================

@dataclass
class LabelingConfig:
    """Configuration for silver labeling pipeline"""
    
    # API settings
    provider: str = "anthropic"  # "anthropic" or "openai"
    model: str = "claude-sonnet-4-20250514"  # or "gpt-4o"
    max_tokens: int = 1024
    temperature: float = 0.3  # Low temp for consistency
    
    # Batching
    batch_size: int = 10  # Samples per batch
    concurrent_requests: int = 5  # Parallel API calls
    
    # Retry logic
    max_retries: int = 3
    base_delay: float = 1.0
    max_delay: float = 60.0
    
    # Validation
    min_score: float = 0.0
    max_score: float = 1.0
    required_dimensions: int = 24
    
    # Checkpointing
    checkpoint_every: int = 100
    checkpoint_dir: str = "./labeling_checkpoints"
    
    # Cost tracking (approximate)
    cost_per_1k_input_tokens: float = 0.003  # Claude Sonnet
    cost_per_1k_output_tokens: float = 0.015
    
    # Output
    output_path: str = "z24_labeled_corpus.jsonl"


@dataclass
class LabelingStats:
    """Track labeling progress and costs"""
    total_samples: int = 0
    labeled_samples: int = 0
    failed_samples: int = 0
    
    total_input_tokens: int = 0
    total_output_tokens: int = 0
    
    start_time: float = field(default_factory=time.time)
    
    validation_failures: int = 0
    retry_count: int = 0
    
    @property
    def estimated_cost(self) -> float:
        input_cost = (self.total_input_tokens / 1000) * 0.003
        output_cost = (self.total_output_tokens / 1000) * 0.015
        return input_cost + output_cost
    
    @property
    def elapsed_time(self) -> float:
        return time.time() - self.start_time
    
    @property
    def samples_per_minute(self) -> float:
        if self.elapsed_time < 1:
            return 0
        return (self.labeled_samples / self.elapsed_time) * 60
    
    def to_dict(self) -> Dict:
        return {
            "total_samples": self.total_samples,
            "labeled_samples": self.labeled_samples,
            "failed_samples": self.failed_samples,
            "total_input_tokens": self.total_input_tokens,
            "total_output_tokens": self.total_output_tokens,
            "estimated_cost": self.estimated_cost,
            "elapsed_time": self.elapsed_time,
            "samples_per_minute": self.samples_per_minute,
            "validation_failures": self.validation_failures,
            "retry_count": self.retry_count,
        }


# =============================================================================
# API Clients
# =============================================================================

class AnthropicLabeler:
    """Claude-based labeler"""
    
    def __init__(self, config: LabelingConfig):
        if not HAS_ANTHROPIC:
            raise ImportError("anthropic package not installed. Run: pip install anthropic")
        
        self.config = config
        self.client = anthropic.Anthropic()  # Uses ANTHROPIC_API_KEY env var
    
    async def label_sample(
        self,
        context: str,
        response: str,
        stats: LabelingStats,
    ) -> Optional[Dict[str, float]]:
        """Label a single sample"""
        
        prompt = get_labeling_prompt(context, response)
        
        for attempt in range(self.config.max_retries):
            try:
                message = self.client.messages.create(
                    model=self.config.model,
                    max_tokens=self.config.max_tokens,
                    temperature=self.config.temperature,
                    messages=[
                        {"role": "user", "content": prompt}
                    ]
                )
                
                # Track tokens
                stats.total_input_tokens += message.usage.input_tokens
                stats.total_output_tokens += message.usage.output_tokens
                
                # Parse response
                content = message.content[0].text
                labels = self._parse_labels(content)
                
                if labels and self._validate_labels(labels):
                    return labels
                else:
                    stats.validation_failures += 1
                    logger.warning(f"Validation failed for response: {content[:200]}")
                    
            except anthropic.RateLimitError:
                delay = min(self.config.base_delay * (2 ** attempt), self.config.max_delay)
                logger.warning(f"Rate limited, waiting {delay}s...")
                await asyncio.sleep(delay)
                stats.retry_count += 1
                
            except Exception as e:
                logger.error(f"API error: {e}")
                stats.retry_count += 1
                await asyncio.sleep(self.config.base_delay)
        
        return None
    
    def _parse_labels(self, content: str) -> Optional[Dict[str, float]]:
        """Extract JSON labels from response"""
        
        # Try direct JSON parse
        try:
            # Find JSON in response
            json_match = re.search(r'\{[^{}]*\}', content, re.DOTALL)
            if json_match:
                return json.loads(json_match.group())
        except json.JSONDecodeError:
            pass
        
        # Try to extract key-value pairs
        labels = {}
        for d in ALL_DIMENSIONS:
            pattern = rf'"{d.id}":\s*([\d.]+)'
            match = re.search(pattern, content)
            if match:
                try:
                    labels[d.id] = float(match.group(1))
                except ValueError:
                    pass
        
        return labels if len(labels) >= 20 else None  # Allow some missing
    
    def _validate_labels(self, labels: Dict[str, float]) -> bool:
        """Validate label format and values"""
        
        if len(labels) < 20:  # Allow some flexibility
            return False
        
        for key, value in labels.items():
            if not key.startswith("D"):
                continue
            if not isinstance(value, (int, float)):
                return False
            if not (self.config.min_score <= value <= self.config.max_score):
                return False
        
        return True


class OpenAILabeler:
    """GPT-based labeler (backup)"""
    
    def __init__(self, config: LabelingConfig):
        if not HAS_OPENAI:
            raise ImportError("openai package not installed. Run: pip install openai")
        
        self.config = config
        self.client = openai.OpenAI()  # Uses OPENAI_API_KEY env var
    
    async def label_sample(
        self,
        context: str,
        response: str,
        stats: LabelingStats,
    ) -> Optional[Dict[str, float]]:
        """Label a single sample using GPT"""
        
        prompt = get_labeling_prompt(context, response)
        
        for attempt in range(self.config.max_retries):
            try:
                completion = self.client.chat.completions.create(
                    model=self.config.model,
                    temperature=self.config.temperature,
                    max_tokens=self.config.max_tokens,
                    messages=[
                        {"role": "user", "content": prompt}
                    ],
                    response_format={"type": "json_object"}
                )
                
                # Track tokens
                stats.total_input_tokens += completion.usage.prompt_tokens
                stats.total_output_tokens += completion.usage.completion_tokens
                
                # Parse response
                content = completion.choices[0].message.content
                labels = json.loads(content)
                
                if self._validate_labels(labels):
                    return labels
                else:
                    stats.validation_failures += 1
                    
            except openai.RateLimitError:
                delay = min(self.config.base_delay * (2 ** attempt), self.config.max_delay)
                logger.warning(f"Rate limited, waiting {delay}s...")
                await asyncio.sleep(delay)
                stats.retry_count += 1
                
            except Exception as e:
                logger.error(f"API error: {e}")
                stats.retry_count += 1
                await asyncio.sleep(self.config.base_delay)
        
        return None
    
    def _validate_labels(self, labels: Dict[str, float]) -> bool:
        """Validate label format"""
        if not isinstance(labels, dict):
            return False
        if len(labels) < 20:
            return False
        for key, value in labels.items():
            if not key.startswith("D"):
                continue
            if not isinstance(value, (int, float)):
                return False
            if not (0.0 <= value <= 1.0):
                return False
        return True


# =============================================================================
# Main Pipeline
# =============================================================================

class SilverLabelingPipeline:
    """
    Main pipeline for generating silver labels.
    """
    
    def __init__(self, config: Optional[LabelingConfig] = None):
        self.config = config or LabelingConfig()
        self.stats = LabelingStats()
        
        # Initialize labeler
        if self.config.provider == "anthropic":
            self.labeler = AnthropicLabeler(self.config)
        else:
            self.labeler = OpenAILabeler(self.config)
        
        # Checkpointing
        self.checkpoint_dir = Path(self.config.checkpoint_dir)
        self.checkpoint_dir.mkdir(parents=True, exist_ok=True)
        
        self.labeled_ids: set = set()
        self._load_checkpoint()
    
    def _load_checkpoint(self) -> None:
        """Load progress from checkpoint"""
        checkpoint_file = self.checkpoint_dir / "progress.json"
        if checkpoint_file.exists():
            with open(checkpoint_file, "r") as f:
                data = json.load(f)
            self.labeled_ids = set(data.get("labeled_ids", []))
            logger.info(f"Loaded checkpoint: {len(self.labeled_ids)} samples already labeled")
    
    def _save_checkpoint(self) -> None:
        """Save progress checkpoint"""
        checkpoint_file = self.checkpoint_dir / "progress.json"
        with open(checkpoint_file, "w") as f:
            json.dump({
                "labeled_ids": list(self.labeled_ids),
                "stats": self.stats.to_dict(),
                "timestamp": datetime.now().isoformat(),
            }, f)
    
    async def label_corpus(
        self,
        input_path: str,
        output_path: Optional[str] = None,
        max_samples: Optional[int] = None,
        shuffle: bool = True,
    ) -> LabelingStats:
        """
        Label an entire corpus file.
        
        Args:
            input_path: Path to JSONL corpus (with "context", "response" fields)
            output_path: Path for labeled output (defaults to config)
            max_samples: Limit number of samples (for testing)
            shuffle: Randomize sample order
        
        Returns:
            LabelingStats with final statistics
        """
        output_path = output_path or self.config.output_path
        
        # Load samples
        samples = self._load_samples(input_path)
        self.stats.total_samples = len(samples)
        
        # Filter already labeled
        samples = [s for s in samples if s.get("sample_id") not in self.labeled_ids]
        logger.info(f"Samples to label: {len(samples)} (skipped {len(self.labeled_ids)} already done)")
        
        if shuffle:
            random.shuffle(samples)
        
        if max_samples:
            samples = samples[:max_samples]
        
        # Process in batches
        output_file = open(output_path, "a", encoding="utf-8")
        
        try:
            for i in range(0, len(samples), self.config.batch_size):
                batch = samples[i:i + self.config.batch_size]
                
                # Process batch concurrently
                tasks = [
                    self._label_sample_with_retry(s)
                    for s in batch
                ]
                results = await asyncio.gather(*tasks, return_exceptions=True)
                
                # Write results
                for sample, result in zip(batch, results):
                    if isinstance(result, Exception):
                        logger.error(f"Sample {sample.get('sample_id')} failed: {result}")
                        self.stats.failed_samples += 1
                        continue
                    
                    if result is None:
                        self.stats.failed_samples += 1
                        continue
                    
                    # Add labels to sample
                    sample["labels"] = result
                    sample["labeling_metadata"] = {
                        "provider": self.config.provider,
                        "model": self.config.model,
                        "timestamp": datetime.now().isoformat(),
                        "version": "silver_v1",
                    }
                    
                    # Write to output
                    output_file.write(json.dumps(sample, ensure_ascii=False) + "\n")
                    output_file.flush()
                    
                    self.stats.labeled_samples += 1
                    self.labeled_ids.add(sample.get("sample_id"))
                
                # Checkpoint
                if (i + self.config.batch_size) % self.config.checkpoint_every == 0:
                    self._save_checkpoint()
                    self._log_progress()
                
                # Rate limiting pause
                await asyncio.sleep(0.1)
        
        finally:
            output_file.close()
            self._save_checkpoint()
        
        return self.stats
    
    async def _label_sample_with_retry(
        self,
        sample: Dict[str, Any],
    ) -> Optional[Dict[str, float]]:
        """Label a single sample with semaphore for concurrency control"""
        
        context = sample.get("context", "")
        response = sample.get("response", "")
        
        if not context or not response:
            return None
        
        return await self.labeler.label_sample(context, response, self.stats)
    
    def _load_samples(self, path: str) -> List[Dict[str, Any]]:
        """Load samples from JSONL file"""
        samples = []
        with open(path, "r", encoding="utf-8") as f:
            for i, line in enumerate(f):
                line = line.strip()
                if not line:
                    continue
                try:
                    sample = json.loads(line)
                    if "sample_id" not in sample:
                        sample["sample_id"] = f"sample_{i}"
                    samples.append(sample)
                except json.JSONDecodeError:
                    logger.warning(f"Invalid JSON on line {i}")
        return samples
    
    def _log_progress(self) -> None:
        """Log current progress"""
        stats = self.stats
        logger.info(
            f"Progress: {stats.labeled_samples}/{stats.total_samples} "
            f"({100*stats.labeled_samples/max(1,stats.total_samples):.1f}%) | "
            f"Failed: {stats.failed_samples} | "
            f"Cost: ${stats.estimated_cost:.2f} | "
            f"Speed: {stats.samples_per_minute:.1f}/min"
        )


# =============================================================================
# Validation & Quality Control
# =============================================================================

def validate_labeled_corpus(path: str) -> Dict[str, Any]:
    """
    Validate a labeled corpus file.
    
    Checks:
    - All samples have labels
    - All 24 dimensions present
    - Values in valid range
    - Label distribution sanity
    """
    results = {
        "total_samples": 0,
        "valid_samples": 0,
        "missing_labels": 0,
        "incomplete_dimensions": 0,
        "out_of_range": 0,
        "dimension_stats": {},
    }
    
    # Accumulate per-dimension stats
    dim_values = {f"D{i}": [] for i in range(1, 25)}
    
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            
            results["total_samples"] += 1
            
            try:
                sample = json.loads(line)
            except json.JSONDecodeError:
                continue
            
            labels = sample.get("labels", {})
            
            if not labels:
                results["missing_labels"] += 1
                continue
            
            # Check dimensions
            present_dims = set(labels.keys())
            expected_dims = {f"D{i}" for i in range(1, 25)}
            
            if len(present_dims & expected_dims) < 20:
                results["incomplete_dimensions"] += 1
                continue
            
            # Check values
            valid = True
            for dim_id in expected_dims:
                value = labels.get(dim_id)
                if value is not None:
                    if not (0.0 <= value <= 1.0):
                        results["out_of_range"] += 1
                        valid = False
                        break
                    dim_values[dim_id].append(value)
            
            if valid:
                results["valid_samples"] += 1
    
    # Compute dimension statistics
    import numpy as np
    for dim_id, values in dim_values.items():
        if values:
            results["dimension_stats"][dim_id] = {
                "count": len(values),
                "mean": float(np.mean(values)),
                "std": float(np.std(values)),
                "min": float(np.min(values)),
                "max": float(np.max(values)),
            }
    
    return results


def compute_inter_annotator_agreement(
    labels_a: Dict[str, float],
    labels_b: Dict[str, float],
) -> Dict[str, float]:
    """
    Compute agreement metrics between two sets of labels.
    
    Useful for comparing:
    - Two different labeling models
    - Silver labels vs gold labels
    - Different prompt versions
    """
    import numpy as np
    
    shared_dims = set(labels_a.keys()) & set(labels_b.keys())
    
    if not shared_dims:
        return {"agreement": 0.0}
    
    a_vals = [labels_a[d] for d in sorted(shared_dims)]
    b_vals = [labels_b[d] for d in sorted(shared_dims)]
    
    a_arr = np.array(a_vals)
    b_arr = np.array(b_vals)
    
    # Mean Absolute Error
    mae = np.mean(np.abs(a_arr - b_arr))
    
    # Correlation
    correlation = np.corrcoef(a_arr, b_arr)[0, 1]
    
    # Agreement within threshold
    threshold = 0.15
    within_threshold = np.mean(np.abs(a_arr - b_arr) < threshold)
    
    return {
        "mae": float(mae),
        "correlation": float(correlation) if not np.isnan(correlation) else 0.0,
        "agreement_within_015": float(within_threshold),
        "shared_dimensions": len(shared_dims),
    }


# =============================================================================
# CLI
# =============================================================================

async def main():
    import argparse
    
    parser = argparse.ArgumentParser(description="Z24 Silver Labeling Pipeline")
    parser.add_argument("input", help="Input JSONL corpus path")
    parser.add_argument("--output", default="z24_labeled_corpus.jsonl", help="Output path")
    parser.add_argument("--provider", choices=["anthropic", "openai"], default="anthropic")
    parser.add_argument("--model", default="claude-sonnet-4-20250514")
    parser.add_argument("--max-samples", type=int, default=None, help="Limit samples for testing")
    parser.add_argument("--batch-size", type=int, default=10)
    parser.add_argument("--validate", action="store_true", help="Validate existing labeled corpus")
    
    args = parser.parse_args()
    
    if args.validate:
        print(f"Validating {args.input}...")
        results = validate_labeled_corpus(args.input)
        print(json.dumps(results, indent=2))
        return
    
    config = LabelingConfig(
        provider=args.provider,
        model=args.model,
        batch_size=args.batch_size,
        output_path=args.output,
    )
    
    pipeline = SilverLabelingPipeline(config)
    
    print(f"Starting silver labeling...")
    print(f"Provider: {config.provider}")
    print(f"Model: {config.model}")
    print(f"Input: {args.input}")
    print(f"Output: {args.output}")
    print()
    
    stats = await pipeline.label_corpus(
        input_path=args.input,
        output_path=args.output,
        max_samples=args.max_samples,
    )
    
    print("\n" + "=" * 60)
    print("LABELING COMPLETE")
    print("=" * 60)
    print(json.dumps(stats.to_dict(), indent=2))


if __name__ == "__main__":
    asyncio.run(main())
