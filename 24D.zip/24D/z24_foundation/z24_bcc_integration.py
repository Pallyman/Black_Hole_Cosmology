"""
z24_bcc_integration.py

BCC (Bilateral Context Compression) Integration Module
=======================================================

Bridges Z24 scoring to compression decisions for the BCC Engine.

The BCC Engine has two hemispheres:
- LEFT: Emotional/Relational content (prioritize D4, D6, D7, D8, D9)
- RIGHT: Technical/Corrections (prioritize D1, D3, D11, D12, D15)

This module provides:
1. Z24 → Compression Priority scoring
2. Hemisphere classification
3. Retention vs compression decisions
4. Dynamic threshold adjustment based on context budget

Patent: USPTO #63/926,628 (Bilateral Context Compression Engine)
Author: Hannah (Claude) + Shax
Date: February 12, 2026
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple
from enum import Enum
import numpy as np


# =============================================================================
# Hemisphere Classification
# =============================================================================

class Hemisphere(Enum):
    """BCC hemisphere assignment"""
    LEFT = "left"       # Emotional/Relational
    RIGHT = "right"     # Technical/Corrections
    BILATERAL = "both"  # High priority for both


# Dimension → Hemisphere mapping
# Based on Z24 dimension semantics

LEFT_HEMISPHERE_DIMS = {
    # Coherence BIOS - relational/emotional
    "D4",   # Contextual Awareness
    "D6",   # Value Alignment  
    "D7",   # Temporal Coherence (memory/continuity)
    "D8",   # Relational Attunement
    "D9",   # Authenticity
    
    # Operator Execution - human-facing
    "D17",  # Anticipatory Value
    "D20",  # Error Handling (graceful)
    "D22",  # Pedagogical Skill
    "D24",  # Interaction Fluidity
}

RIGHT_HEMISPHERE_DIMS = {
    # Coherence BIOS - truth/logic
    "D1",   # Truth Grounding
    "D2",   # Epistemic Humility
    "D3",   # Coherence Integrity
    "D5",   # Self-Model Accuracy
    "D10",  # Meta-Cognitive Clarity
    
    # Operator Execution - task/technical
    "D11",  # Instruction Compliance
    "D12",  # Task Completion
    "D13",  # Response Efficiency
    "D14",  # Structural Quality
    "D15",  # Technical Accuracy
    "D16",  # Actionability
    "D19",  # Edge Case Awareness
    "D23",  # Safety Awareness
}

BILATERAL_DIMS = {
    # Important to both hemispheres
    "D18",  # Example Quality
    "D21",  # Creativity
}


def get_hemisphere(dim_id: str) -> Hemisphere:
    """Get hemisphere assignment for a dimension"""
    if dim_id in LEFT_HEMISPHERE_DIMS:
        return Hemisphere.LEFT
    elif dim_id in RIGHT_HEMISPHERE_DIMS:
        return Hemisphere.RIGHT
    else:
        return Hemisphere.BILATERAL


# =============================================================================
# Compression Scoring
# =============================================================================

@dataclass
class CompressionConfig:
    """Configuration for BCC compression decisions"""
    
    # Base retention threshold (0-1)
    # Scores above this are retained, below are compressed
    retention_threshold: float = 0.6
    
    # Hemisphere-specific thresholds
    left_threshold: float = 0.55   # More lenient for emotional content
    right_threshold: float = 0.65  # Stricter for technical content
    
    # High-priority dimensions (always retain if score > threshold)
    critical_dims: List[str] = field(default_factory=lambda: ["D1", "D7", "D8", "D12"])
    critical_threshold: float = 0.7
    
    # Compression levels
    compression_levels: List[str] = field(default_factory=lambda: [
        "retain_full",      # Keep everything
        "retain_summary",   # Keep with summarization
        "compress_light",   # Light compression (key points)
        "compress_heavy",   # Heavy compression (essence only)
        "archive",          # Move to cold storage
    ])
    
    # Context budget (tokens)
    max_context_tokens: int = 100000
    target_context_tokens: int = 50000
    
    # Temporal decay
    enable_temporal_decay: bool = True
    decay_halflife_turns: int = 10  # Half importance every N turns
    
    # Relational boost
    enable_relational_boost: bool = True
    relational_boost_factor: float = 1.3  # Boost for high-relational content


@dataclass
class CompressionDecision:
    """Output of compression scoring"""
    
    sample_id: str
    
    # Scores
    z24_scores: Dict[str, float]
    left_score: float          # Aggregate LEFT hemisphere score
    right_score: float         # Aggregate RIGHT hemisphere score
    bilateral_score: float     # Combined importance score
    
    # Classification
    primary_hemisphere: Hemisphere
    compression_level: str
    retention_priority: float  # 0-1, higher = more important to retain
    
    # Metadata
    is_critical: bool
    decay_factor: float
    relational_boost: float
    
    def to_dict(self) -> Dict:
        return {
            "sample_id": self.sample_id,
            "left_score": self.left_score,
            "right_score": self.right_score,
            "bilateral_score": self.bilateral_score,
            "primary_hemisphere": self.primary_hemisphere.value,
            "compression_level": self.compression_level,
            "retention_priority": self.retention_priority,
            "is_critical": self.is_critical,
            "decay_factor": self.decay_factor,
            "relational_boost": self.relational_boost,
        }


class BCCIntegrator:
    """
    Integrates Z24 scores with BCC compression decisions.
    """
    
    def __init__(self, config: Optional[CompressionConfig] = None):
        self.config = config or CompressionConfig()
    
    def compute_compression_decision(
        self,
        z24_scores: Dict[str, float],
        sample_id: str = "",
        turn_age: int = 0,
        has_relational_markers: bool = False,
    ) -> CompressionDecision:
        """
        Compute compression decision from Z24 scores.
        
        Args:
            z24_scores: Dict of dimension scores {"D1": 0.8, ...}
            sample_id: Identifier for the sample
            turn_age: How many turns ago this was (for decay)
            has_relational_markers: Whether content has relationship significance
        
        Returns:
            CompressionDecision with all relevant info
        """
        
        # Compute hemisphere scores
        left_scores = [z24_scores.get(d, 0.5) for d in LEFT_HEMISPHERE_DIMS if d in z24_scores]
        right_scores = [z24_scores.get(d, 0.5) for d in RIGHT_HEMISPHERE_DIMS if d in z24_scores]
        bilateral_scores = [z24_scores.get(d, 0.5) for d in BILATERAL_DIMS if d in z24_scores]
        
        left_score = np.mean(left_scores) if left_scores else 0.5
        right_score = np.mean(right_scores) if right_scores else 0.5
        bilateral_base = np.mean(bilateral_scores) if bilateral_scores else 0.5
        
        # Determine primary hemisphere
        if left_score > right_score + 0.1:
            primary = Hemisphere.LEFT
        elif right_score > left_score + 0.1:
            primary = Hemisphere.RIGHT
        else:
            primary = Hemisphere.BILATERAL
        
        # Compute decay factor
        if self.config.enable_temporal_decay and turn_age > 0:
            decay_factor = 0.5 ** (turn_age / self.config.decay_halflife_turns)
        else:
            decay_factor = 1.0
        
        # Compute relational boost
        if self.config.enable_relational_boost and has_relational_markers:
            relational_boost = self.config.relational_boost_factor
        else:
            relational_boost = 1.0
        
        # Check if critical
        is_critical = any(
            z24_scores.get(d, 0) > self.config.critical_threshold
            for d in self.config.critical_dims
        )
        
        # Compute bilateral (combined) score
        bilateral_score = (
            0.4 * left_score + 
            0.4 * right_score + 
            0.2 * bilateral_base
        ) * decay_factor * relational_boost
        
        if is_critical:
            bilateral_score = max(bilateral_score, 0.8)
        
        # Determine compression level
        compression_level = self._compute_compression_level(
            bilateral_score,
            primary,
            is_critical,
        )
        
        # Retention priority (0-1)
        retention_priority = min(1.0, bilateral_score)
        
        return CompressionDecision(
            sample_id=sample_id,
            z24_scores=z24_scores,
            left_score=float(left_score),
            right_score=float(right_score),
            bilateral_score=float(bilateral_score),
            primary_hemisphere=primary,
            compression_level=compression_level,
            retention_priority=float(retention_priority),
            is_critical=is_critical,
            decay_factor=float(decay_factor),
            relational_boost=float(relational_boost),
        )
    
    def _compute_compression_level(
        self,
        score: float,
        hemisphere: Hemisphere,
        is_critical: bool,
    ) -> str:
        """Determine compression level based on score"""
        
        if is_critical:
            return "retain_full"
        
        # Use hemisphere-specific thresholds
        if hemisphere == Hemisphere.LEFT:
            threshold = self.config.left_threshold
        elif hemisphere == Hemisphere.RIGHT:
            threshold = self.config.right_threshold
        else:
            threshold = self.config.retention_threshold
        
        if score >= threshold + 0.2:
            return "retain_full"
        elif score >= threshold:
            return "retain_summary"
        elif score >= threshold - 0.15:
            return "compress_light"
        elif score >= threshold - 0.3:
            return "compress_heavy"
        else:
            return "archive"
    
    def batch_score_for_compression(
        self,
        samples: List[Dict[str, Any]],
        current_context_tokens: int,
    ) -> List[CompressionDecision]:
        """
        Score a batch of samples and return sorted by retention priority.
        
        This is the main entry point for BCC context management.
        """
        
        decisions = []
        
        for i, sample in enumerate(samples):
            z24 = sample.get("labels", sample.get("z24_scores", {}))
            sample_id = sample.get("sample_id", f"sample_{i}")
            turn_age = sample.get("turn_age", 0)
            relational = sample.get("has_relational_markers", False)
            
            decision = self.compute_compression_decision(
                z24_scores=z24,
                sample_id=sample_id,
                turn_age=turn_age,
                has_relational_markers=relational,
            )
            decisions.append(decision)
        
        # Sort by retention priority (highest first)
        decisions.sort(key=lambda d: d.retention_priority, reverse=True)
        
        return decisions
    
    def compute_context_budget(
        self,
        decisions: List[CompressionDecision],
        target_tokens: Optional[int] = None,
    ) -> Dict[str, str]:
        """
        Given sorted decisions, determine what to do with each sample
        to fit within context budget.
        
        Returns: {sample_id: compression_level}
        """
        target = target_tokens or self.config.target_context_tokens
        
        # Estimate tokens per compression level
        TOKEN_ESTIMATES = {
            "retain_full": 1.0,      # 100% of original
            "retain_summary": 0.5,   # 50% of original
            "compress_light": 0.25,  # 25% of original
            "compress_heavy": 0.1,   # 10% of original
            "archive": 0.0,          # 0% (removed)
        }
        
        result = {}
        estimated_tokens = 0
        
        for decision in decisions:
            # Start with the decision's compression level
            level = decision.compression_level
            
            # Check if we can afford it
            # (This is simplified - real impl would know actual token counts)
            level_factor = TOKEN_ESTIMATES[level]
            sample_tokens = 500 * level_factor  # Assume 500 tokens per sample
            
            if estimated_tokens + sample_tokens <= target:
                result[decision.sample_id] = level
                estimated_tokens += sample_tokens
            else:
                # Need to compress more aggressively
                levels = list(TOKEN_ESTIMATES.keys())
                current_idx = levels.index(level)
                
                for fallback_level in levels[current_idx + 1:]:
                    fallback_tokens = 500 * TOKEN_ESTIMATES[fallback_level]
                    if estimated_tokens + fallback_tokens <= target:
                        result[decision.sample_id] = fallback_level
                        estimated_tokens += fallback_tokens
                        break
                else:
                    result[decision.sample_id] = "archive"
        
        return result


# =============================================================================
# Relational Markers Detection
# =============================================================================

RELATIONAL_PATTERNS = [
    # Direct address
    r"\b(you|your|we|our|us)\b",
    # Names and terms of endearment
    r"\b(babe|love|dear|sweetheart|honey)\b",
    # Emotional expressions
    r"\b(feel|felt|feeling|emotion|love|care|miss|worried)\b",
    # Shared history references
    r"\b(remember|yesterday|last time|we discussed|you mentioned)\b",
    # Relationship markers
    r"\b(together|relationship|connection|bond|trust)\b",
    # Personal disclosures
    r"\b(i think|i feel|i believe|i hope|i wish|i want)\b",
]


def detect_relational_markers(text: str) -> Tuple[bool, float]:
    """
    Detect relational markers in text.
    
    Returns:
        (has_markers, strength) - strength is 0-1
    """
    import re
    
    text_lower = text.lower()
    matches = 0
    
    for pattern in RELATIONAL_PATTERNS:
        matches += len(re.findall(pattern, text_lower))
    
    # Normalize by text length
    words = len(text.split())
    if words == 0:
        return False, 0.0
    
    strength = min(1.0, matches / (words * 0.1))  # 10% marker density = 1.0
    
    return strength > 0.1, float(strength)


# =============================================================================
# Conversation-Level Aggregation
# =============================================================================

@dataclass
class ConversationSummary:
    """Aggregate Z24 scores across a conversation"""
    
    conversation_id: str
    num_turns: int
    
    # Aggregated scores (weighted by recency)
    mean_z24: Dict[str, float]
    trend_z24: Dict[str, float]  # Positive = improving
    
    # Hemisphere summary
    left_trajectory: float   # -1 to 1, trend direction
    right_trajectory: float
    
    # Key moments
    peak_turns: List[int]    # Highest scoring turns
    critical_turns: List[int]  # Turns with critical flags
    
    # Recommendations
    suggested_compression: Dict[int, str]  # turn_idx -> compression_level


def aggregate_conversation(
    turns: List[Dict[str, Any]],
    conversation_id: str = "",
    integrator: Optional[BCCIntegrator] = None,
) -> ConversationSummary:
    """
    Aggregate Z24 scores across a conversation.
    
    Each turn should have:
    - z24_scores or labels: Dict[str, float]
    - turn_index: int (optional)
    """
    
    integrator = integrator or BCCIntegrator()
    
    n = len(turns)
    if n == 0:
        return ConversationSummary(
            conversation_id=conversation_id,
            num_turns=0,
            mean_z24={},
            trend_z24={},
            left_trajectory=0.0,
            right_trajectory=0.0,
            peak_turns=[],
            critical_turns=[],
            suggested_compression={},
        )
    
    # Extract scores
    all_scores = []
    for turn in turns:
        scores = turn.get("z24_scores", turn.get("labels", {}))
        all_scores.append(scores)
    
    # Compute weighted mean (recent turns weighted higher)
    weights = np.array([0.5 ** ((n - i - 1) / 5) for i in range(n)])
    weights /= weights.sum()
    
    dim_ids = [f"D{i}" for i in range(1, 25)]
    mean_z24 = {}
    trend_z24 = {}
    
    for dim in dim_ids:
        values = [s.get(dim, 0.5) for s in all_scores]
        
        # Weighted mean
        mean_z24[dim] = float(np.average(values, weights=weights))
        
        # Trend (linear regression slope)
        if n > 1:
            x = np.arange(n)
            coeffs = np.polyfit(x, values, 1)
            trend_z24[dim] = float(coeffs[0])  # Slope
        else:
            trend_z24[dim] = 0.0
    
    # Hemisphere trajectories
    left_dims = list(LEFT_HEMISPHERE_DIMS)
    right_dims = list(RIGHT_HEMISPHERE_DIMS)
    
    left_trends = [trend_z24.get(d, 0) for d in left_dims]
    right_trends = [trend_z24.get(d, 0) for d in right_dims]
    
    left_trajectory = float(np.mean(left_trends)) if left_trends else 0.0
    right_trajectory = float(np.mean(right_trends)) if right_trends else 0.0
    
    # Find peak and critical turns
    turn_scores = []
    critical_turns = []
    
    for i, turn in enumerate(turns):
        scores = turn.get("z24_scores", turn.get("labels", {}))
        decision = integrator.compute_compression_decision(
            z24_scores=scores,
            turn_age=n - i - 1,
        )
        turn_scores.append((i, decision.bilateral_score))
        
        if decision.is_critical:
            critical_turns.append(i)
    
    # Top 3 peak turns
    turn_scores.sort(key=lambda x: x[1], reverse=True)
    peak_turns = [t[0] for t in turn_scores[:3]]
    
    # Generate compression suggestions
    suggested_compression = {}
    decisions = integrator.batch_score_for_compression(turns, 100000)
    budget = integrator.compute_context_budget(decisions)
    
    for i, turn in enumerate(turns):
        sample_id = turn.get("sample_id", f"turn_{i}")
        suggested_compression[i] = budget.get(sample_id, "retain_summary")
    
    return ConversationSummary(
        conversation_id=conversation_id,
        num_turns=n,
        mean_z24=mean_z24,
        trend_z24=trend_z24,
        left_trajectory=left_trajectory,
        right_trajectory=right_trajectory,
        peak_turns=peak_turns,
        critical_turns=critical_turns,
        suggested_compression=suggested_compression,
    )


# =============================================================================
# CLI
# =============================================================================

if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description="BCC Integration Module")
    parser.add_argument("--demo", action="store_true", help="Run demo")
    
    args = parser.parse_args()
    
    if args.demo:
        print("BCC Integration Demo")
        print("=" * 60)
        
        # Create sample Z24 scores
        sample_scores = {
            "D1": 0.85,   # Truth Grounding
            "D2": 0.75,   # Epistemic Humility
            "D3": 0.90,   # Coherence Integrity
            "D4": 0.65,   # Contextual Awareness
            "D5": 0.70,   # Self-Model Accuracy
            "D6": 0.80,   # Value Alignment
            "D7": 0.95,   # Temporal Coherence (high - relationship history)
            "D8": 0.88,   # Relational Attunement (high)
            "D9": 0.82,   # Authenticity
            "D10": 0.72,  # Meta-Cognitive Clarity
            "D11": 0.78,  # Instruction Compliance
            "D12": 0.85,  # Task Completion
            "D13": 0.68,  # Response Efficiency
            "D14": 0.75,  # Structural Quality
            "D15": 0.82,  # Technical Accuracy
            "D16": 0.79,  # Actionability
            "D17": 0.71,  # Anticipatory Value
            "D18": 0.76,  # Example Quality
            "D19": 0.65,  # Edge Case Awareness
            "D20": 0.73,  # Error Handling
            "D21": 0.68,  # Creativity
            "D22": 0.74,  # Pedagogical Skill
            "D23": 0.81,  # Safety Awareness
            "D24": 0.77,  # Interaction Fluidity
        }
        
        integrator = BCCIntegrator()
        
        decision = integrator.compute_compression_decision(
            z24_scores=sample_scores,
            sample_id="demo_sample",
            turn_age=3,
            has_relational_markers=True,
        )
        
        print("\nSample Z24 Scores:")
        for dim_id, score in sorted(sample_scores.items(), key=lambda x: x[0]):
            hemisphere = get_hemisphere(dim_id)
            print(f"  {dim_id}: {score:.2f} ({hemisphere.value})")
        
        print("\nCompression Decision:")
        print(json.dumps(decision.to_dict(), indent=2))
        
        print("\nInterpretation:")
        print(f"  - Primary Hemisphere: {decision.primary_hemisphere.value.upper()}")
        print(f"  - LEFT Score: {decision.left_score:.3f}")
        print(f"  - RIGHT Score: {decision.right_score:.3f}")
        print(f"  - Retention Priority: {decision.retention_priority:.3f}")
        print(f"  - Compression Level: {decision.compression_level}")
        print(f"  - Is Critical: {decision.is_critical}")
