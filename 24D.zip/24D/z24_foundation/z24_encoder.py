
"""
z24_encoder.py

Core Z24 encoder model: predicts 24 behavioral dimension scores (0-1) + uncertainties
from a (context, response) text pair.

Dependencies: torch, transformers
Python: 3.10+
"""

from __future__ import annotations

import json
import os
from dataclasses import asdict, dataclass
from typing import Any, Dict, Optional, Tuple, Union

import torch
import torch.nn as nn
from transformers import AutoConfig, AutoModel, AutoTokenizer


@dataclass
class Z24EncoderConfig:
    """
    Lightweight config saved alongside weights (similar to HuggingFace style).

    Notes:
    - `encoder_name_or_path` can be a HF model id OR local path.
    - `dropout_p` controls both MC-dropout behavior and head regularization.
    """
    encoder_name_or_path: str = "sentence-transformers/all-MiniLM-L6-v2"
    dropout_p: float = 0.1
    hidden_dropout_p: float = 0.1
    head_hidden_mult: float = 1.0  # multiplier on encoder hidden size for head MLP width
    use_layernorm: bool = True

    # Uncertainty head behavior
    # We predict log-variance per dimension and convert to std via exp(0.5 * log_var).
    log_var_min: float = -10.0
    log_var_max: float = 3.0

    # Tokenization format (for encode_pair convenience)
    pair_format: str = "text_pair"  # "text_pair" or "concat"
    concat_template: str = "[CONTEXT]\n{context}\n\n[RESPONSE]\n{response}"

    # Dimensions split
    n_coherence: int = 10
    n_execution: int = 14

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

    @property
    def n_dims(self) -> int:
        return self.n_coherence + self.n_execution


def mean_pool(last_hidden_state: torch.Tensor, attention_mask: torch.Tensor) -> torch.Tensor:
    """
    Mean pooling that respects attention_mask.

    Args:
        last_hidden_state: [B, T, H]
        attention_mask: [B, T]
    Returns:
        pooled: [B, H]
    """
    mask = attention_mask.unsqueeze(-1).type_as(last_hidden_state)  # [B,T,1]
    summed = (last_hidden_state * mask).sum(dim=1)
    denom = mask.sum(dim=1).clamp(min=1e-6)
    return summed / denom


class _Z24Head(nn.Module):
    """
    MLP head that outputs mean logits and log-variance for a subset of dimensions.
    """

    def __init__(self, in_dim: int, out_dim: int, dropout_p: float, hidden_mult: float = 1.0):
        super().__init__()
        hidden = max(64, int(in_dim * hidden_mult))
        self.net = nn.Sequential(
            nn.Linear(in_dim, hidden),
            nn.GELU(),
            nn.Dropout(dropout_p),
            nn.Linear(hidden, hidden),
            nn.GELU(),
            nn.Dropout(dropout_p),
        )
        self.mean = nn.Linear(hidden, out_dim)
        self.log_var = nn.Linear(hidden, out_dim)

    def forward(self, x: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor]:
        h = self.net(x)
        mean_logits = self.mean(h)
        log_var = self.log_var(h)
        return mean_logits, log_var


class Z24Encoder(nn.Module):
    """
    Z24 Encoder

    - Shared Transformer encoder base (MiniLM by default, MPNet optional)
    - Two prediction heads:
        * Coherence BIOS head: D1-D10 (10 dims)
        * Operator Execution head: D11-D24 (14 dims)
    - Outputs:
        * z24_scores: Tensor[B,24] in [0,1]
        * uncertainties: Tensor[B,24] predicted std-dev per dim (>=0)

    Uncertainty:
    - Learned heteroscedastic regression head (predicts per-dimension log-variance).
    - Optional MC-dropout can be used via `predict_mc_dropout(...)`.

    Note on encoder choice:
      - Default: sentence-transformers/all-MiniLM-L6-v2 (fast)
      - Quality:  sentence-transformers/all-mpnet-base-v2 (slower, better)
    """

    def __init__(self, encoder_name: str = "sentence-transformers/all-MiniLM-L6-v2", config: Optional[Z24EncoderConfig] = None):
        super().__init__()
        self.cfg = config or Z24EncoderConfig(encoder_name_or_path=encoder_name)

        # If caller passed encoder_name but also passed config, keep config as source of truth
        if config is not None and encoder_name and encoder_name != config.encoder_name_or_path:
            # This is a convenience: if you pass both, the explicit encoder_name wins.
            self.cfg.encoder_name_or_path = encoder_name

        # Encoder
        self.encoder_config = AutoConfig.from_pretrained(self.cfg.encoder_name_or_path)
        self.encoder = AutoModel.from_pretrained(self.cfg.encoder_name_or_path, config=self.encoder_config)

        self.hidden_size = getattr(self.encoder_config, "hidden_size", None)
        if self.hidden_size is None:
            raise ValueError("Could not determine encoder hidden_size from config.")

        self.dropout = nn.Dropout(self.cfg.hidden_dropout_p)
        self.layernorm = nn.LayerNorm(self.hidden_size) if self.cfg.use_layernorm else nn.Identity()

        # Heads
        self.coherence_head = _Z24Head(
            in_dim=self.hidden_size,
            out_dim=self.cfg.n_coherence,
            dropout_p=self.cfg.dropout_p,
            hidden_mult=self.cfg.head_hidden_mult,
        )
        self.execution_head = _Z24Head(
            in_dim=self.hidden_size,
            out_dim=self.cfg.n_execution,
            dropout_p=self.cfg.dropout_p,
            hidden_mult=self.cfg.head_hidden_mult,
        )

        # Optional tokenizer for convenience methods
        self._tokenizer = None  # lazy-loaded

    # -------------------------
    # Saving / Loading (HF-like)
    # -------------------------

    def save_pretrained(self, save_directory: str) -> None:
        """
        Save model weights + config to a directory.

        Produces:
          - config.json
          - pytorch_model.bin
          - (optional) tokenizer files if tokenizer was loaded via get_tokenizer()
        """
        os.makedirs(save_directory, exist_ok=True)

        # Save config
        cfg_path = os.path.join(save_directory, "config.json")
        with open(cfg_path, "w", encoding="utf-8") as f:
            json.dump(self.cfg.to_dict(), f, indent=2, sort_keys=True)

        # Save weights
        weights_path = os.path.join(save_directory, "pytorch_model.bin")
        torch.save(self.state_dict(), weights_path)

        # Save tokenizer (optional)
        if self._tokenizer is not None:
            self._tokenizer.save_pretrained(save_directory)

    @classmethod
    def from_pretrained(
        cls,
        model_name_or_path: str,
        map_location: Optional[Union[str, torch.device]] = None,
        **kwargs,
    ) -> "Z24Encoder":
        """
        Load from a local directory created by `save_pretrained`, or initialize from a HF encoder id.

        If `model_name_or_path` is a directory containing config.json + pytorch_model.bin,
        those will be used.

        Otherwise, we treat it as an encoder name and return a model with fresh heads.
        """
        if os.path.isdir(model_name_or_path) and os.path.exists(os.path.join(model_name_or_path, "config.json")):
            cfg_path = os.path.join(model_name_or_path, "config.json")
            with open(cfg_path, "r", encoding="utf-8") as f:
                cfg_dict = json.load(f)
            cfg = Z24EncoderConfig(**cfg_dict)

            model = cls(encoder_name=cfg.encoder_name_or_path, config=cfg, **kwargs)

            weights_path = os.path.join(model_name_or_path, "pytorch_model.bin")
            state = torch.load(weights_path, map_location=map_location or "cpu")
            model.load_state_dict(state, strict=True)

            # Try to load tokenizer if present
            try:
                model._tokenizer = AutoTokenizer.from_pretrained(model_name_or_path, use_fast=True)
            except Exception:
                pass

            return model

        # Fallback: treat as HF encoder name
        cfg = Z24EncoderConfig(encoder_name_or_path=model_name_or_path)
        return cls(encoder_name=model_name_or_path, config=cfg, **kwargs)

    # -------------------------
    # Tokenizer convenience
    # -------------------------

    def get_tokenizer(self, use_fast: bool = True) -> Any:
        """
        Lazily load and return the tokenizer for the underlying encoder.
        """
        if self._tokenizer is None:
            self._tokenizer = AutoTokenizer.from_pretrained(self.cfg.encoder_name_or_path, use_fast=use_fast)
        return self._tokenizer

    # -------------------------
    # Forward / Inference
    # -------------------------

    def forward(
        self,
        input_ids: torch.Tensor,
        attention_mask: torch.Tensor,
        token_type_ids: Optional[torch.Tensor] = None,
        return_uncertainty: bool = True,
        return_log_vars: bool = False,
    ) -> Dict[str, torch.Tensor]:
        """
        Forward pass.

        Args:
            input_ids: [B, T]
            attention_mask: [B, T]
            token_type_ids: optional [B, T] (some encoders ignore)
            return_uncertainty: include predicted std-dev per dim
            return_log_vars: include raw log-variance per dim (useful for heteroscedastic loss)

        Returns:
            dict with:
              - z24_scores: [B, 24] in [0,1]
              - uncertainties: [B, 24] (std-dev, >=0) if return_uncertainty
              - log_vars: [B, 24] if return_log_vars
        """
        encoder_kwargs = {"input_ids": input_ids, "attention_mask": attention_mask}
        if token_type_ids is not None:
            encoder_kwargs["token_type_ids"] = token_type_ids

        out = self.encoder(**encoder_kwargs)
        pooled = mean_pool(out.last_hidden_state, attention_mask)  # [B,H]
        pooled = self.layernorm(pooled)
        pooled = self.dropout(pooled)

        coh_logits, coh_log_var = self.coherence_head(pooled)  # [B,10], [B,10]
        exe_logits, exe_log_var = self.execution_head(pooled)  # [B,14], [B,14]

        logits = torch.cat([coh_logits, exe_logits], dim=-1)  # [B,24]
        log_var = torch.cat([coh_log_var, exe_log_var], dim=-1)  # [B,24]

        # Bound outputs
        scores = torch.sigmoid(logits)  # [0,1]
        log_var = torch.clamp(log_var, min=self.cfg.log_var_min, max=self.cfg.log_var_max)

        result: Dict[str, torch.Tensor] = {"z24_scores": scores}

        if return_uncertainty:
            # std-dev = exp(0.5 * log_var)
            std = torch.exp(0.5 * log_var)
            result["uncertainties"] = std

        if return_log_vars:
            result["log_vars"] = log_var

        return result

    @torch.inference_mode()
    def encode_pair(
        self,
        context: str,
        response: str,
        device: Optional[Union[str, torch.device]] = None,
        max_length: int = 512,
    ) -> torch.Tensor:
        """
        Convenience helper: encode a single (context, response) pair and return z24 vector [24].

        This uses the encoder's tokenizer. If you prefer controlling tokenization,
        call the model directly.

        Args:
            context: context string
            response: response string
            device: torch device or string; if None uses model's device
            max_length: tokenizer truncation length

        Returns:
            Tensor[24] on CPU
        """
        tok = self.get_tokenizer()
        if self.cfg.pair_format == "text_pair":
            enc = tok(context, response, truncation="longest_first", max_length=max_length, return_tensors="pt")
        else:
            text = self.cfg.concat_template.format(context=context, response=response)
            enc = tok(text, truncation=True, max_length=max_length, return_tensors="pt")

        model_device = next(self.parameters()).device
        use_device = torch.device(device) if device is not None else model_device
        enc = {k: v.to(use_device) for k, v in enc.items()}

        self.eval()
        out = self(**enc, return_uncertainty=False)
        return out["z24_scores"].squeeze(0).detach().cpu()

    @torch.inference_mode()
    def predict_mc_dropout(
        self,
        input_ids: torch.Tensor,
        attention_mask: torch.Tensor,
        token_type_ids: Optional[torch.Tensor] = None,
        num_samples: int = 20,
    ) -> Dict[str, torch.Tensor]:
        """
        Monte-Carlo Dropout uncertainty estimation.

        This runs the model `num_samples` times with dropout ON, then returns:
          - mean prediction
          - epistemic std (sample std)
          - aleatoric std (predicted std from log_var)
          - total std = sqrt(epistemic^2 + aleatoric^2)

        Returns tensors on the same device as inputs.
        """
        # Enable dropout
        self.train()

        preds = []
        aleatoric = []

        for _ in range(num_samples):
            out = self(
                input_ids=input_ids,
                attention_mask=attention_mask,
                token_type_ids=token_type_ids,
                return_uncertainty=True,
                return_log_vars=False,
            )
            preds.append(out["z24_scores"])
            aleatoric.append(out["uncertainties"])

        pred_stack = torch.stack(preds, dim=0)  # [S,B,24]
        alea_stack = torch.stack(aleatoric, dim=0)  # [S,B,24]

        mean = pred_stack.mean(dim=0)
        epi_std = pred_stack.std(dim=0, unbiased=False)
        alea_std = alea_stack.mean(dim=0)

        total_std = torch.sqrt(epi_std.pow(2) + alea_std.pow(2))

        # Restore eval mode
        self.eval()

        return {
            "z24_scores": mean,
            "uncertainties_epistemic": epi_std,
            "uncertainties_aleatoric": alea_std,
            "uncertainties": total_std,
        }
