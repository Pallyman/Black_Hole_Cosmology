
"""
z24_trainer.py

Training loop for Z24Encoder.

Features:
- Masked multi-task regression loss (supports partial labels)
- Optional heteroscedastic (learned uncertainty) loss
- Gradient clipping
- Warmup + cosine LR schedule
- Validation every N steps
- Best-checkpoint saving
- Basic metric logging (overall + per-dimension)

Dependencies: torch, transformers, numpy, tqdm
Python: 3.10+
"""

from __future__ import annotations

import json
import math
import os
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import numpy as np
import torch
import torch.nn as nn
from torch.optim import AdamW
from tqdm.auto import tqdm
from transformers import get_cosine_schedule_with_warmup


def _as_float_tensor(x: Any, device: torch.device) -> torch.Tensor:
    if isinstance(x, torch.Tensor):
        return x.to(device=device, dtype=torch.float32)
    return torch.tensor(x, device=device, dtype=torch.float32)


def masked_weighted_mse(
    preds: torch.Tensor,
    targets: torch.Tensor,
    mask: torch.Tensor,
    dim_weights: Optional[torch.Tensor] = None,
    eps: float = 1e-8,
) -> Tuple[torch.Tensor, torch.Tensor]:
    """
    Compute masked, (optionally) weighted MSE.

    Returns:
        loss: scalar tensor
        per_dim_mse: [24] tensor (NaN where no labels)
    """
    # Ensure float mask
    m = mask.float()
    if dim_weights is None:
        w = torch.ones(preds.shape[-1], device=preds.device, dtype=preds.dtype)
    else:
        w = dim_weights.to(device=preds.device, dtype=preds.dtype)

    se = (preds - targets).pow(2)  # [B,24]
    weighted = se * m * w  # broadcast w over batch

    denom = (m * w).sum().clamp(min=eps)
    loss = weighted.sum() / denom

    # Per-dim MSE (ignoring weights for interpretability, but still masked)
    per_dim = []
    for d in range(preds.shape[-1]):
        md = m[:, d]
        if md.sum() < 1:
            per_dim.append(torch.tensor(float("nan"), device=preds.device))
        else:
            per_dim.append((se[:, d] * md).sum() / md.sum().clamp(min=eps))
    per_dim_mse = torch.stack(per_dim, dim=0)

    return loss, per_dim_mse


def masked_heteroscedastic_nll(
    mean: torch.Tensor,
    targets: torch.Tensor,
    log_var: torch.Tensor,
    mask: torch.Tensor,
    dim_weights: Optional[torch.Tensor] = None,
    eps: float = 1e-8,
) -> Tuple[torch.Tensor, torch.Tensor]:
    """
    Gaussian negative log-likelihood with learned per-dim log-variance.

    Loss per element:
        0.5 * exp(-log_var) * (y - mu)^2 + 0.5 * log_var

    Returns:
        loss scalar
        per_dim_mse [24] for monitoring (masked)
    """
    m = mask.float()
    if dim_weights is None:
        w = torch.ones(mean.shape[-1], device=mean.device, dtype=mean.dtype)
    else:
        w = dim_weights.to(device=mean.device, dtype=mean.dtype)

    se = (mean - targets).pow(2)
    inv_var = torch.exp(-log_var)
    nll = 0.5 * inv_var * se + 0.5 * log_var  # [B,24]

    weighted = nll * m * w
    denom = (m * w).sum().clamp(min=eps)
    loss = weighted.sum() / denom

    # Per-dim MSE for interpretability
    per_dim = []
    for d in range(mean.shape[-1]):
        md = m[:, d]
        if md.sum() < 1:
            per_dim.append(torch.tensor(float("nan"), device=mean.device))
        else:
            per_dim.append((se[:, d] * md).sum() / md.sum().clamp(min=eps))
    per_dim_mse = torch.stack(per_dim, dim=0)

    return loss, per_dim_mse


@dataclass
class TrainerState:
    epoch: int = 0
    global_step: int = 0
    best_val_loss: float = float("inf")


class Z24Trainer:
    """
    Trainer for Z24Encoder.
    """

    def __init__(self, model: nn.Module, train_loader, val_loader, config: Dict[str, Any]):
        self.model = model
        self.train_loader = train_loader
        self.val_loader = val_loader
        self.cfg = config

        self.device = torch.device(self.cfg.get("device", "cuda" if torch.cuda.is_available() else "cpu"))
        self.model.to(self.device)

        self.save_dir = Path(self.cfg.get("save_dir", "./z24_checkpoints"))
        self.save_dir.mkdir(parents=True, exist_ok=True)

        self.lr = float(self.cfg.get("lr", 2e-5))
        self.weight_decay = float(self.cfg.get("weight_decay", 0.01))
        self.max_grad_norm = float(self.cfg.get("max_grad_norm", 1.0))
        self.gradient_accumulation_steps = int(self.cfg.get("gradient_accumulation_steps", 1))
        self.use_fp16 = bool(self.cfg.get("use_fp16", True)) and self.device.type == "cuda"

        self.log_every = int(self.cfg.get("log_every", 50))
        self.val_every = int(self.cfg.get("val_every", 500))

        # Loss config
        self.loss_type = str(self.cfg.get("loss_type", "mse")).lower()
        self.use_heteroscedastic = bool(self.cfg.get("use_heteroscedastic", self.loss_type in {"hetero", "heteroscedastic", "nll"}))

        # Dimension weights (24)
        dw = self.cfg.get("dimension_weights", None)
        if dw is None:
            self.dim_weights = None
        else:
            if len(dw) != 24:
                raise ValueError("dimension_weights must have length 24.")
            self.dim_weights = torch.tensor(dw, dtype=torch.float32, device=self.device)

        # Optimizer
        self.optimizer = AdamW(self.model.parameters(), lr=self.lr, weight_decay=self.weight_decay)

        # Scheduler
        num_epochs = int(self.cfg.get("num_epochs", 1))
        total_steps = math.ceil(len(train_loader) / self.gradient_accumulation_steps) * num_epochs
        warmup_ratio = float(self.cfg.get("warmup_ratio", 0.06))
        warmup_steps = int(self.cfg.get("warmup_steps", max(10, int(total_steps * warmup_ratio))))
        self.scheduler = get_cosine_schedule_with_warmup(self.optimizer, num_warmup_steps=warmup_steps, num_training_steps=total_steps)

        # AMP
        self.scaler = torch.cuda.amp.GradScaler(enabled=self.use_fp16)

        self.state = TrainerState(epoch=0, global_step=0, best_val_loss=float("inf"))

    def _step_batch(self, batch: Dict[str, Any], train: bool) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        Returns:
            loss, per_dim_mse
        """
        input_ids = batch["input_ids"].to(self.device)
        attention_mask = batch["attention_mask"].to(self.device)
        token_type_ids = batch.get("token_type_ids", None)
        if token_type_ids is not None:
            token_type_ids = token_type_ids.to(self.device)

        labels = batch["labels"].to(self.device, dtype=torch.float32)
        label_mask = batch["label_mask"].to(self.device)

        with torch.cuda.amp.autocast(enabled=self.use_fp16):
            out = self.model(
                input_ids=input_ids,
                attention_mask=attention_mask,
                token_type_ids=token_type_ids,
                return_uncertainty=self.use_heteroscedastic,
                return_log_vars=self.use_heteroscedastic,
            )
            preds = out["z24_scores"]

            if self.use_heteroscedastic:
                log_vars = out.get("log_vars", None)
                if log_vars is None:
                    raise RuntimeError("Model did not return log_vars but heteroscedastic loss is enabled.")
                loss, per_dim_mse = masked_heteroscedastic_nll(
                    mean=preds,
                    targets=labels,
                    log_var=log_vars,
                    mask=label_mask,
                    dim_weights=self.dim_weights,
                )
            else:
                loss, per_dim_mse = masked_weighted_mse(
                    preds=preds,
                    targets=labels,
                    mask=label_mask,
                    dim_weights=self.dim_weights,
                )

        return loss, per_dim_mse

    def train_epoch(self, epoch: int) -> Dict[str, Any]:
        self.model.train()
        self.state.epoch = epoch

        running_loss = 0.0
        running_count = 0

        # For per-dim logging (EMA-ish)
        per_dim_accum = torch.zeros(24, device=self.device, dtype=torch.float32)
        per_dim_count = torch.zeros(24, device=self.device, dtype=torch.float32)

        pbar = tqdm(self.train_loader, desc=f"Train epoch {epoch}", leave=False)
        self.optimizer.zero_grad(set_to_none=True)

        for step, batch in enumerate(pbar, start=1):
            loss, per_dim_mse = self._step_batch(batch, train=True)

            loss_scaled = loss / self.gradient_accumulation_steps
            self.scaler.scale(loss_scaled).backward()

            if step % self.gradient_accumulation_steps == 0:
                # Clip gradients
                self.scaler.unscale_(self.optimizer)
                torch.nn.utils.clip_grad_norm_(self.model.parameters(), self.max_grad_norm)

                self.scaler.step(self.optimizer)
                self.scaler.update()
                self.optimizer.zero_grad(set_to_none=True)
                self.scheduler.step()

                self.state.global_step += 1

                # Logging
                running_loss += float(loss.detach().cpu())
                running_count += 1

                # per-dim mse
                pd = per_dim_mse.detach()
                valid = torch.isfinite(pd)
                per_dim_accum[valid] += pd[valid]
                per_dim_count[valid] += 1

                if self.state.global_step % self.log_every == 0:
                    avg_loss = running_loss / max(1, running_count)
                    pbar.set_postfix({"loss": f"{avg_loss:.4f}", "lr": f"{self.scheduler.get_last_lr()[0]:.2e}"})

                # Validation
                if self.val_every > 0 and self.state.global_step % self.val_every == 0:
                    val_metrics = self.validate()
                    val_loss = float(val_metrics["val_loss"])
                    if val_loss < self.state.best_val_loss:
                        self.state.best_val_loss = val_loss
                        self.save_checkpoint(str(self.save_dir / "best"), is_best=True)

        avg_train_loss = running_loss / max(1, running_count)
        per_dim_mean = (per_dim_accum / per_dim_count.clamp(min=1)).detach().cpu().numpy().tolist()

        return {
            "train_loss": avg_train_loss,
            "train_per_dim_mse": per_dim_mean,
            "global_step": self.state.global_step,
        }

    @torch.inference_mode()
    def validate(self) -> Dict[str, Any]:
        self.model.eval()

        running_loss = 0.0
        running_count = 0

        per_dim_accum = torch.zeros(24, device=self.device, dtype=torch.float32)
        per_dim_count = torch.zeros(24, device=self.device, dtype=torch.float32)

        for batch in tqdm(self.val_loader, desc="Validate", leave=False):
            loss, per_dim_mse = self._step_batch(batch, train=False)
            running_loss += float(loss.detach().cpu())
            running_count += 1

            pd = per_dim_mse.detach()
            valid = torch.isfinite(pd)
            per_dim_accum[valid] += pd[valid]
            per_dim_count[valid] += 1

        val_loss = running_loss / max(1, running_count)
        per_dim_mean = (per_dim_accum / per_dim_count.clamp(min=1)).detach().cpu().numpy().tolist()

        return {
            "val_loss": val_loss,
            "val_per_dim_mse": per_dim_mean,
            "global_step": self.state.global_step,
        }

    def train(self, num_epochs: int) -> Dict[str, Any]:
        """
        Main training loop.
        Saves:
          - last checkpoint each epoch
          - best checkpoint when improved on val_loss
        """
        history: List[Dict[str, Any]] = []
        for epoch in range(1, num_epochs + 1):
            train_metrics = self.train_epoch(epoch)
            val_metrics = self.validate()

            # Save epoch checkpoint
            self.save_checkpoint(str(self.save_dir / f"epoch_{epoch}"), is_best=False)

            # Best checkpoint
            val_loss = float(val_metrics["val_loss"])
            if val_loss < self.state.best_val_loss:
                self.state.best_val_loss = val_loss
                self.save_checkpoint(str(self.save_dir / "best"), is_best=True)

            merged = {"epoch": epoch, **train_metrics, **val_metrics}
            history.append(merged)

            # Optional console print
            if self.cfg.get("verbose", True):
                print(
                    f"[Epoch {epoch}] train_loss={train_metrics['train_loss']:.4f} "
                    f"val_loss={val_metrics['val_loss']:.4f} best_val={self.state.best_val_loss:.4f}"
                )

        # Save training history
        try:
            with open(self.save_dir / "history.json", "w", encoding="utf-8") as f:
                json.dump(history, f, indent=2)
        except Exception:
            pass

        return {"history": history, "best_val_loss": self.state.best_val_loss}

    def save_checkpoint(self, path: str, is_best: bool = False) -> None:
        """
        Save model + optimizer + scheduler state.

        `path` is treated as a directory (like HF save_pretrained).
        """
        out_dir = Path(path)
        out_dir.mkdir(parents=True, exist_ok=True)

        # Save model in HF-like format if available
        if hasattr(self.model, "save_pretrained"):
            self.model.save_pretrained(str(out_dir))
        else:
            torch.save(self.model.state_dict(), out_dir / "pytorch_model.bin")

        # Save trainer state
        state = {
            "trainer_state": {
                "epoch": self.state.epoch,
                "global_step": self.state.global_step,
                "best_val_loss": self.state.best_val_loss,
            },
            "optimizer": self.optimizer.state_dict(),
            "scheduler": self.scheduler.state_dict(),
            "config": self.cfg,
        }
        torch.save(state, out_dir / "trainer_state.pt")

        # Convenience: mark best
        if is_best:
            with open(out_dir / "BEST", "w", encoding="utf-8") as f:
                f.write("best checkpoint\n")
