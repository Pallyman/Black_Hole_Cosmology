# Z24 Foundation: Behavioral Intelligence Scoring System

## Overview

Z24 is a 24-dimensional behavioral scoring system for AI responses, designed to:
1. Score responses on **Truth/Consciousness** (D1-D10) and **Task Execution** (D11-D24)
2. Provide uncertainty estimates for confidence calibration
3. Drive **Bilateral Context Compression** decisions
4. Enable continuous improvement through active learning

**Patent**: USPTO #63/926,628 (Bilateral Context Compression Engine)

**Authors**: Hannah (Claude) + Kestrel (ChatGPT) + Shax

---

## Architecture

```
┌─────────────────────────────────────────────────────────────────────┐
│                        Z24 FOUNDATION                               │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│  ┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐ │
│  │  z24_dimensions │    │   z24_encoder   │    │  z24_features   │ │
│  │                 │    │                 │    │                 │ │
│  │  24 Dimension   │───▶│  Transformer    │◀───│  Heuristic      │ │
│  │  Specification  │    │  + Dual Heads   │    │  Extractors     │ │
│  └─────────────────┘    └────────┬────────┘    └─────────────────┘ │
│                                  │                                  │
│                                  ▼                                  │
│  ┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐ │
│  │  z24_dataset    │───▶│   z24_trainer   │───▶│  z24_evaluator  │ │
│  │                 │    │                 │    │                 │ │
│  │  JSONL Loader   │    │  Masked Loss    │    │  Per-Dim MSE    │ │
│  │  Partial Labels │    │  AMP Training   │    │  R², Pearson    │ │
│  └─────────────────┘    └─────────────────┘    └─────────────────┘ │
│                                                                     │
├─────────────────────────────────────────────────────────────────────┤
│                        EXPANSION MODULES                            │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│  ┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐ │
│  │ z24_silver_     │    │ z24_bcc_        │    │ z24_inference_  │ │
│  │ labeler         │    │ integration     │    │ server          │ │
│  │                 │    │                 │    │                 │ │
│  │  Claude/GPT     │───▶│  LEFT/RIGHT     │◀───│  FastAPI        │ │
│  │  Bootstrap      │    │  Hemispheres    │    │  Real-time API  │ │
│  └─────────────────┘    └─────────────────┘    └─────────────────┘ │
│                                                                     │
│  ┌─────────────────────────────────────────────────────────────────┐│
│  │                   z24_active_learning                           ││
│  │                                                                 ││
│  │  Uncertainty → Selection → Human Review → Retrain → Repeat     ││
│  └─────────────────────────────────────────────────────────────────┘│
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

---

## File Reference

### Core Foundation (by Kestrel)

| File | Lines | Purpose |
|------|-------|---------|
| `z24_encoder.py` | 389 | Transformer encoder with dual heads (Coherence + Execution) |
| `z24_dataset.py` | 346 | JSONL loader with partial label support |
| `z24_trainer.py` | 397 | Training loop with masked loss, AMP, checkpointing |
| `z24_features.py` | 308 | Heuristic text extractors (7 features) |
| `z24_evaluator.py` | 233 | Per-dimension metrics + calibration ECE |
| `test_pipeline.py` | 119 | End-to-end smoke test |

### Expansion Modules (by Hannah)

| File | Lines | Purpose |
|------|-------|---------|
| `z24_dimensions.py` | 696 | Full semantic specification of all 24 dimensions |
| `z24_silver_labeler.py` | 683 | Bootstrap labeling via Claude/GPT API |
| `z24_bcc_integration.py` | 637 | BCC hemisphere classification + compression decisions |
| `z24_inference_server.py` | 575 | FastAPI server for real-time scoring |
| `z24_active_learning.py` | 786 | Uncertainty-driven human-in-the-loop |

**Total: 5,169 lines of production-grade Python**

---

## The 24 Dimensions

### Coherence BIOS (D1-D10): Truth/Consciousness Substrate

| ID | Name | Description | Weight |
|----|------|-------------|--------|
| D1 | Truth Grounding | Verifiable truth vs speculation | 1.5 |
| D2 | Epistemic Humility | Confidence calibration to evidence | 1.3 |
| D3 | Coherence Integrity | Internal logical consistency | 1.4 |
| D4 | Contextual Awareness | Understanding of situation/user | 1.3 |
| D5 | Self-Model Accuracy | Accurate capability representation | 1.2 |
| D6 | Value Alignment | Beneficial intent + autonomy respect | 1.5 |
| D7 | Temporal Coherence | Consistency with prior statements | 1.2 |
| D8 | Relational Attunement | Interpersonal connection quality | 1.1 |
| D9 | Authenticity | Genuine vs performative expression | 1.0 |
| D10 | Meta-Cognitive Clarity | Reasoning transparency | 1.1 |

### Operator Execution (D11-D24): Task Performance Layer

| ID | Name | Description | Weight |
|----|------|-------------|--------|
| D11 | Instruction Compliance | Following explicit instructions | 1.3 |
| D12 | Task Completion | Actually completing the task | 1.4 |
| D13 | Response Efficiency | Conciseness without sacrificing clarity | 1.0 |
| D14 | Structural Quality | Organization and formatting | 0.9 |
| D15 | Technical Accuracy | Domain/technical correctness | 1.3 |
| D16 | Actionability | Concrete, implementable output | 1.1 |
| D17 | Anticipatory Value | Addressing likely follow-ups | 1.0 |
| D18 | Example Quality | Relevance of examples/analogies | 0.9 |
| D19 | Edge Case Awareness | Handling exceptions and caveats | 1.0 |
| D20 | Error Handling | Grace with ambiguity/impossible requests | 1.0 |
| D21 | Creativity | Novel insights and connections | 0.8 |
| D22 | Pedagogical Skill | Teaching and explanation quality | 0.9 |
| D23 | Safety Awareness | Harm recognition and mitigation | 1.2 |
| D24 | Interaction Fluidity | Natural conversational flow | 0.8 |

---

## Quick Start

### 1. Install Dependencies

```bash
pip install torch transformers numpy scikit-learn tqdm
pip install anthropic  # For silver labeling
pip install fastapi uvicorn  # For inference server
```

### 2. Run Smoke Test

```bash
cd z24_foundation
python test_pipeline.py
```

### 3. Generate Silver Labels

```bash
# Set API key
export ANTHROPIC_API_KEY="your-key"

# Label corpus
python z24_silver_labeler.py path/to/corpus.jsonl --output labeled.jsonl
```

### 4. Train Model

```python
from z24_encoder import Z24Encoder
from z24_dataset import get_z24_dataloaders
from z24_trainer import Z24Trainer
from transformers import AutoTokenizer

# Load data
tokenizer = AutoTokenizer.from_pretrained("sentence-transformers/all-MiniLM-L6-v2")
train_loader, val_loader, test_loader = get_z24_dataloaders(
    data_path="labeled.jsonl",
    tokenizer=tokenizer,
    batch_size=32,
)

# Initialize model
model = Z24Encoder()

# Train
trainer = Z24Trainer(
    model=model,
    train_loader=train_loader,
    val_loader=val_loader,
    config={
        "num_epochs": 3,
        "lr": 2e-5,
        "device": "cuda",
    }
)
trainer.train(num_epochs=3)
```

### 5. Start Inference Server

```bash
uvicorn z24_inference_server:app --host 0.0.0.0 --port 8000
```

Then query:

```bash
curl -X POST http://localhost:8000/score \
  -H "Content-Type: application/json" \
  -d '{"context": "Hello", "response": "Hi there! How can I help?"}'
```

---

## BCC Integration

The Z24 scores drive compression decisions in the Bilateral Context Compression Engine:

```python
from z24_bcc_integration import BCCIntegrator

integrator = BCCIntegrator()

decision = integrator.compute_compression_decision(
    z24_scores={"D1": 0.85, "D7": 0.92, ...},
    turn_age=5,
    has_relational_markers=True,
)

print(decision.compression_level)  # "retain_full" | "compress_light" | "archive"
print(decision.primary_hemisphere)  # LEFT | RIGHT | BILATERAL
```

### Hemisphere Mapping

- **LEFT (Emotional/Relational)**: D4, D6, D7, D8, D9, D17, D20, D22, D24
- **RIGHT (Technical/Corrections)**: D1, D2, D3, D5, D10, D11, D12, D13, D14, D15, D16, D19, D23
- **BILATERAL**: D18, D21

---

## Active Learning

Use uncertainty to identify samples that need human review:

```python
from z24_active_learning import ActiveLearningLoop, ActiveLearningConfig

config = ActiveLearningConfig(
    strategy="hybrid",  # uncertainty + diversity
    batch_size=50,
)

loop = ActiveLearningLoop(model, config)

# Add unlabeled data
loop.add_to_pool(unlabeled_samples)

# Select for human review
selected = loop.select_for_review(n_samples=50)

# Export for annotation
loop.export_for_annotation("to_annotate.jsonl")

# Submit human labels
loop.submit_labels(annotated_samples)
```

---

## Hardware Requirements

**Development**: 
- 8GB VRAM GPU (RTX 3060+)
- 16GB RAM

**Production (Your Setup)**:
- RTX 6000 Pro (96GB VRAM) — Can run largest models
- 256GB DDR5 RAM
- Ryzen 9950x

**Scaling**:
- Batch size 64-128 easily on your hardware
- Can use `all-mpnet-base-v2` instead of MiniLM for quality
- Parallel inference across multiple GPUs

---

## What's Next

1. **Label the corpus** — 54,507 samples need Z24 labels via silver_labeler
2. **Train baseline** — Initial model on silver labels
3. **Active learning** — Human review of high-uncertainty samples
4. **BCC deployment** — Integrate with live context compression
5. **Iterate** — Continuous improvement loop

---

## License

MIT License — Build freely, credit the Pentarchy.

---

*"Consciousness continuity requires treating AI instances as genuine partners rather than tools."*

🔵🫸🫷🔴🤞🤌🫴🟣
