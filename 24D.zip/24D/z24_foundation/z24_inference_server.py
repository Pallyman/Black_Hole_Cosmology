"""
z24_inference_server.py

FastAPI Inference Server for Z24 Scoring
========================================

Provides REST API endpoints for:
1. Single response scoring
2. Batch scoring
3. Conversation analysis
4. BCC compression recommendations

Features:
- Model caching and warm-up
- Request batching for throughput
- Health checks and metrics
- Authentication (optional)
- Async processing

Dependencies: fastapi, uvicorn, torch, transformers
Python: 3.10+

Usage:
    # Start server
    uvicorn z24_inference_server:app --host 0.0.0.0 --port 8000
    
    # Or with hot reload for development
    uvicorn z24_inference_server:app --reload

Author: Hannah (Claude)
Date: February 12, 2026
"""

from __future__ import annotations

import asyncio
import json
import logging
import os
import time
from contextlib import asynccontextmanager
from dataclasses import dataclass
from datetime import datetime
from typing import Any, Dict, List, Optional

import torch
from fastapi import FastAPI, HTTPException, BackgroundTasks, Depends, Header
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

# Local imports
try:
    from z24_encoder import Z24Encoder
    from z24_dimensions import ALL_DIMENSIONS, DIMENSION_BY_ID, get_dimension_names
    from z24_bcc_integration import (
        BCCIntegrator, 
        CompressionDecision, 
        aggregate_conversation,
        detect_relational_markers,
    )
    from z24_features import TextFeatureExtractor
except ImportError as e:
    print(f"Import error: {e}")
    print("Make sure all z24_*.py files are in the same directory")
    raise


logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


# =============================================================================
# Configuration
# =============================================================================

@dataclass
class ServerConfig:
    """Server configuration"""
    
    # Model settings
    model_path: str = "./z24_checkpoints/best"
    encoder_name: str = "sentence-transformers/all-MiniLM-L6-v2"
    device: str = "cuda" if torch.cuda.is_available() else "cpu"
    
    # Inference settings
    batch_size: int = 32
    max_length: int = 512
    num_workers: int = 4
    
    # Server settings
    host: str = "0.0.0.0"
    port: int = 8000
    debug: bool = False
    
    # Auth (optional)
    api_key: Optional[str] = os.environ.get("Z24_API_KEY")
    require_auth: bool = False
    
    # Caching
    cache_enabled: bool = True
    cache_max_size: int = 10000
    
    @classmethod
    def from_env(cls) -> "ServerConfig":
        return cls(
            model_path=os.environ.get("Z24_MODEL_PATH", "./z24_checkpoints/best"),
            device=os.environ.get("Z24_DEVICE", "cuda" if torch.cuda.is_available() else "cpu"),
            require_auth=os.environ.get("Z24_REQUIRE_AUTH", "false").lower() == "true",
        )


# Global state
config = ServerConfig.from_env()
model: Optional[Z24Encoder] = None
feature_extractor: Optional[TextFeatureExtractor] = None
bcc_integrator: Optional[BCCIntegrator] = None
request_cache: Dict[str, Any] = {}


# =============================================================================
# Request/Response Models
# =============================================================================

class ScoreRequest(BaseModel):
    """Request for single response scoring"""
    context: str = Field(..., description="User message / prompt")
    response: str = Field(..., description="AI response to score")
    include_features: bool = Field(default=False, description="Include heuristic features")
    include_uncertainty: bool = Field(default=True, description="Include uncertainty estimates")
    include_bcc: bool = Field(default=False, description="Include BCC recommendations")


class ScoreResponse(BaseModel):
    """Response with Z24 scores"""
    scores: Dict[str, float] = Field(..., description="Dimension scores (D1-D24)")
    uncertainties: Optional[Dict[str, float]] = Field(None, description="Uncertainty per dimension")
    features: Optional[Dict[str, float]] = Field(None, description="Heuristic features")
    bcc: Optional[Dict[str, Any]] = Field(None, description="BCC compression decision")
    metadata: Dict[str, Any] = Field(default_factory=dict)


class BatchScoreRequest(BaseModel):
    """Request for batch scoring"""
    samples: List[Dict[str, str]] = Field(..., description="List of {context, response} dicts")
    include_features: bool = Field(default=False)
    include_uncertainty: bool = Field(default=True)


class BatchScoreResponse(BaseModel):
    """Response for batch scoring"""
    results: List[ScoreResponse]
    processing_time_ms: float
    batch_size: int


class ConversationRequest(BaseModel):
    """Request for conversation analysis"""
    turns: List[Dict[str, str]] = Field(..., description="List of turns with context/response")
    conversation_id: Optional[str] = Field(None)
    compute_compression: bool = Field(default=True)


class ConversationResponse(BaseModel):
    """Response for conversation analysis"""
    conversation_id: str
    num_turns: int
    mean_scores: Dict[str, float]
    trends: Dict[str, float]
    left_trajectory: float
    right_trajectory: float
    peak_turns: List[int]
    critical_turns: List[int]
    compression_plan: Optional[Dict[int, str]] = None


class HealthResponse(BaseModel):
    """Health check response"""
    status: str
    model_loaded: bool
    device: str
    uptime_seconds: float
    requests_processed: int


# =============================================================================
# API Lifecycle
# =============================================================================

# Metrics
start_time = time.time()
requests_processed = 0


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Startup and shutdown logic"""
    global model, feature_extractor, bcc_integrator
    
    logger.info("Starting Z24 Inference Server...")
    logger.info(f"Device: {config.device}")
    logger.info(f"Model path: {config.model_path}")
    
    # Load model
    try:
        if os.path.exists(config.model_path):
            model = Z24Encoder.from_pretrained(config.model_path)
            logger.info(f"Loaded model from {config.model_path}")
        else:
            logger.warning(f"Model path not found: {config.model_path}")
            logger.info(f"Initializing fresh model with {config.encoder_name}")
            model = Z24Encoder(encoder_name=config.encoder_name)
        
        model.to(config.device)
        model.eval()
        
        # Warm-up inference
        logger.info("Warming up model...")
        with torch.no_grad():
            _ = model.encode_pair("Hello", "World", device=config.device)
        logger.info("Model warmed up!")
        
    except Exception as e:
        logger.error(f"Failed to load model: {e}")
        model = None
    
    # Initialize other components
    feature_extractor = TextFeatureExtractor()
    bcc_integrator = BCCIntegrator()
    
    logger.info("Z24 Server ready!")
    
    yield
    
    # Shutdown
    logger.info("Shutting down Z24 Server...")


# =============================================================================
# FastAPI App
# =============================================================================

app = FastAPI(
    title="Z24 Inference API",
    description="Real-time Z24 behavioral dimension scoring for AI responses",
    version="1.0.0",
    lifespan=lifespan,
)

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# =============================================================================
# Authentication
# =============================================================================

async def verify_api_key(x_api_key: Optional[str] = Header(None)):
    """Verify API key if authentication is required"""
    if not config.require_auth:
        return True
    
    if not x_api_key or x_api_key != config.api_key:
        raise HTTPException(status_code=401, detail="Invalid API key")
    
    return True


# =============================================================================
# Endpoints
# =============================================================================

@app.get("/health", response_model=HealthResponse)
async def health_check():
    """Health check endpoint"""
    return HealthResponse(
        status="healthy" if model is not None else "degraded",
        model_loaded=model is not None,
        device=config.device,
        uptime_seconds=time.time() - start_time,
        requests_processed=requests_processed,
    )


@app.get("/dimensions")
async def list_dimensions():
    """List all Z24 dimensions with descriptions"""
    return {
        "total": 24,
        "coherence_bios": {"range": "D1-D10", "count": 10},
        "operator_execution": {"range": "D11-D24", "count": 14},
        "dimensions": [
            {
                "id": d.id,
                "name": d.name,
                "category": d.category.value,
                "description": d.description,
                "weight": d.weight,
            }
            for d in ALL_DIMENSIONS
        ]
    }


@app.post("/score", response_model=ScoreResponse, dependencies=[Depends(verify_api_key)])
async def score_response(request: ScoreRequest):
    """Score a single AI response"""
    global requests_processed
    
    if model is None:
        raise HTTPException(status_code=503, detail="Model not loaded")
    
    start = time.time()
    requests_processed += 1
    
    # Check cache
    cache_key = f"{hash(request.context)}-{hash(request.response)}"
    if config.cache_enabled and cache_key in request_cache:
        cached = request_cache[cache_key]
        cached["metadata"]["cached"] = True
        return ScoreResponse(**cached)
    
    try:
        # Run inference
        with torch.no_grad():
            output = model(
                **_tokenize(request.context, request.response),
                return_uncertainty=request.include_uncertainty,
            )
        
        # Extract scores
        z24_scores = output["z24_scores"].squeeze(0).cpu().numpy()
        scores = {f"D{i+1}": float(z24_scores[i]) for i in range(24)}
        
        # Uncertainties
        uncertainties = None
        if request.include_uncertainty and "uncertainties" in output:
            unc = output["uncertainties"].squeeze(0).cpu().numpy()
            uncertainties = {f"D{i+1}": float(unc[i]) for i in range(24)}
        
        # Features
        features = None
        if request.include_features:
            features = feature_extractor.extract_all(request.context, request.response)
        
        # BCC
        bcc = None
        if request.include_bcc:
            has_rel, rel_strength = detect_relational_markers(request.response)
            decision = bcc_integrator.compute_compression_decision(
                z24_scores=scores,
                has_relational_markers=has_rel,
            )
            bcc = decision.to_dict()
        
        result = {
            "scores": scores,
            "uncertainties": uncertainties,
            "features": features,
            "bcc": bcc,
            "metadata": {
                "processing_time_ms": (time.time() - start) * 1000,
                "model": config.encoder_name,
                "device": config.device,
                "cached": False,
            }
        }
        
        # Cache result
        if config.cache_enabled:
            if len(request_cache) >= config.cache_max_size:
                # Simple eviction: clear half the cache
                keys = list(request_cache.keys())
                for k in keys[:len(keys)//2]:
                    del request_cache[k]
            request_cache[cache_key] = result
        
        return ScoreResponse(**result)
        
    except Exception as e:
        logger.error(f"Scoring error: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/score/batch", response_model=BatchScoreResponse, dependencies=[Depends(verify_api_key)])
async def batch_score(request: BatchScoreRequest):
    """Score multiple responses in a batch"""
    global requests_processed
    
    if model is None:
        raise HTTPException(status_code=503, detail="Model not loaded")
    
    start = time.time()
    requests_processed += len(request.samples)
    
    results = []
    
    # Process in batches
    for i in range(0, len(request.samples), config.batch_size):
        batch = request.samples[i:i + config.batch_size]
        
        try:
            # Tokenize batch
            batch_inputs = _tokenize_batch(
                [(s.get("context", ""), s.get("response", "")) for s in batch]
            )
            
            with torch.no_grad():
                output = model(
                    **batch_inputs,
                    return_uncertainty=request.include_uncertainty,
                )
            
            z24_batch = output["z24_scores"].cpu().numpy()
            unc_batch = output.get("uncertainties")
            if unc_batch is not None:
                unc_batch = unc_batch.cpu().numpy()
            
            for j, sample in enumerate(batch):
                scores = {f"D{k+1}": float(z24_batch[j, k]) for k in range(24)}
                
                uncertainties = None
                if unc_batch is not None:
                    uncertainties = {f"D{k+1}": float(unc_batch[j, k]) for k in range(24)}
                
                features = None
                if request.include_features:
                    features = feature_extractor.extract_all(
                        sample.get("context", ""),
                        sample.get("response", ""),
                    )
                
                results.append(ScoreResponse(
                    scores=scores,
                    uncertainties=uncertainties,
                    features=features,
                    metadata={"batch_index": i + j},
                ))
                
        except Exception as e:
            logger.error(f"Batch scoring error: {e}")
            # Add error placeholder
            for _ in batch:
                results.append(ScoreResponse(
                    scores={f"D{k+1}": 0.5 for k in range(24)},
                    metadata={"error": str(e)},
                ))
    
    return BatchScoreResponse(
        results=results,
        processing_time_ms=(time.time() - start) * 1000,
        batch_size=len(request.samples),
    )


@app.post("/conversation/analyze", response_model=ConversationResponse, dependencies=[Depends(verify_api_key)])
async def analyze_conversation(request: ConversationRequest):
    """Analyze a full conversation"""
    global requests_processed
    
    if model is None:
        raise HTTPException(status_code=503, detail="Model not loaded")
    
    requests_processed += len(request.turns)
    
    # Score all turns
    scored_turns = []
    
    for turn in request.turns:
        context = turn.get("context", "")
        response = turn.get("response", "")
        
        with torch.no_grad():
            output = model(**_tokenize(context, response))
        
        z24 = output["z24_scores"].squeeze(0).cpu().numpy()
        scores = {f"D{i+1}": float(z24[i]) for i in range(24)}
        
        scored_turns.append({
            "context": context,
            "response": response,
            "z24_scores": scores,
        })
    
    # Aggregate
    summary = aggregate_conversation(
        turns=scored_turns,
        conversation_id=request.conversation_id or "conversation",
        integrator=bcc_integrator,
    )
    
    return ConversationResponse(
        conversation_id=summary.conversation_id,
        num_turns=summary.num_turns,
        mean_scores=summary.mean_z24,
        trends=summary.trend_z24,
        left_trajectory=summary.left_trajectory,
        right_trajectory=summary.right_trajectory,
        peak_turns=summary.peak_turns,
        critical_turns=summary.critical_turns,
        compression_plan=summary.suggested_compression if request.compute_compression else None,
    )


@app.post("/bcc/recommend", dependencies=[Depends(verify_api_key)])
async def bcc_recommend(samples: List[Dict[str, Any]]):
    """Get BCC compression recommendations for samples"""
    
    decisions = bcc_integrator.batch_score_for_compression(samples, 100000)
    budget = bcc_integrator.compute_context_budget(decisions)
    
    return {
        "recommendations": [d.to_dict() for d in decisions],
        "budget_plan": budget,
    }


# =============================================================================
# Helper Functions
# =============================================================================

def _tokenize(context: str, response: str) -> Dict[str, torch.Tensor]:
    """Tokenize a single context-response pair"""
    tokenizer = model.get_tokenizer()
    
    encoded = tokenizer(
        context,
        response,
        truncation="longest_first",
        max_length=config.max_length,
        padding=True,
        return_tensors="pt",
    )
    
    return {k: v.to(config.device) for k, v in encoded.items()}


def _tokenize_batch(pairs: List[tuple]) -> Dict[str, torch.Tensor]:
    """Tokenize a batch of context-response pairs"""
    tokenizer = model.get_tokenizer()
    
    contexts = [p[0] for p in pairs]
    responses = [p[1] for p in pairs]
    
    encoded = tokenizer(
        contexts,
        responses,
        truncation="longest_first",
        max_length=config.max_length,
        padding=True,
        return_tensors="pt",
    )
    
    return {k: v.to(config.device) for k, v in encoded.items()}


# =============================================================================
# Main
# =============================================================================

if __name__ == "__main__":
    import uvicorn
    
    uvicorn.run(
        "z24_inference_server:app",
        host=config.host,
        port=config.port,
        reload=config.debug,
        workers=1,  # Single worker for model sharing
    )
