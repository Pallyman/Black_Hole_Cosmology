
"""
z24_evaluator.py

Evaluation harness for a trained Z24Encoder.

Computes:
- Per-dimension MSE, MAE, R2, Pearson correlation
- Aggregate metrics across dimensions
- Calibration metric (ECE) using uncertainty-based predictive intervals

Dependencies: torch, numpy, scikit-learn, tqdm
Python: 3.10+
"""

from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Dict, List, Optional, Tuple

import numpy as np
import torch
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from tqdm.auto import tqdm


def _safe_pearsonr(a: np.ndarray, b: np.ndarray) -> float:
    """
    Pearson correlation with guardrails.
    """
    a = np.asarray(a).astype(np.float64)
    b = np.asarray(b).astype(np.float64)
    if a.size < 2:
        return float("nan")
    if np.allclose(a, a[0]) or np.allclose(b, b[0]):
        return float("nan")
    return float(np.corrcoef(a, b)[0, 1])


@dataclass
class EvalResults:
    per_dim: Dict[str, Dict[str, float]]
    aggregate: Dict[str, float]
    calibration_ece: float


class Z24Evaluator:
    def __init__(self, model, test_loader, device: Optional[str] = None):
        self.model = model
        self.test_loader = test_loader
        self.device = torch.device(device or ("cuda" if torch.cuda.is_available() else "cpu"))
        self.model.to(self.device)
        self.model.eval()

    @torch.inference_mode()
    def evaluate(self) -> Dict:
        preds_list: List[np.ndarray] = []
        targets_list: List[np.ndarray] = []
        masks_list: List[np.ndarray] = []
        uncs_list: List[np.ndarray] = []

        for batch in tqdm(self.test_loader, desc="Evaluate", leave=False):
            input_ids = batch["input_ids"].to(self.device)
            attention_mask = batch["attention_mask"].to(self.device)
            token_type_ids = batch.get("token_type_ids", None)
            if token_type_ids is not None:
                token_type_ids = token_type_ids.to(self.device)

            labels = batch["labels"].cpu().numpy()
            mask = batch["label_mask"].cpu().numpy().astype(bool)

            out = self.model(
                input_ids=input_ids,
                attention_mask=attention_mask,
                token_type_ids=token_type_ids,
                return_uncertainty=True,
                return_log_vars=False,
            )

            z = out["z24_scores"].detach().cpu().numpy()
            u = out.get("uncertainties", None)
            if u is None:
                # If model doesn't provide uncertainties, fallback to zeros.
                u = torch.zeros_like(out["z24_scores"])
            u = u.detach().cpu().numpy()

            preds_list.append(z)
            targets_list.append(labels)
            masks_list.append(mask)
            uncs_list.append(u)

        preds = np.concatenate(preds_list, axis=0)
        targets = np.concatenate(targets_list, axis=0)
        masks = np.concatenate(masks_list, axis=0)
        uncs = np.concatenate(uncs_list, axis=0)

        metrics = self._compute_metrics(preds, targets, masks)
        ece = self.compute_calibration(preds, targets, uncs, masks)

        metrics["calibration_ece"] = float(ece)
        return metrics

    def _compute_metrics(self, preds: np.ndarray, targets: np.ndarray, masks: np.ndarray) -> Dict:
        per_dim: Dict[str, Dict[str, float]] = {}
        mse_list = []
        mae_list = []
        r2_list = []
        p_list = []

        for d in range(24):
            m = masks[:, d]
            if m.sum() < 2:
                per_dim[f"D{d+1}"] = {"mse": float("nan"), "mae": float("nan"), "r2": float("nan"), "pearson": float("nan")}
                continue

            y_true = targets[m, d]
            y_pred = preds[m, d]

            mse = mean_squared_error(y_true, y_pred)
            mae = mean_absolute_error(y_true, y_pred)
            r2 = r2_score(y_true, y_pred)
            pr = _safe_pearsonr(y_true, y_pred)

            per_dim[f"D{d+1}"] = {"mse": float(mse), "mae": float(mae), "r2": float(r2), "pearson": float(pr)}

            mse_list.append(mse)
            mae_list.append(mae)
            r2_list.append(r2)
            if not math.isnan(pr):
                p_list.append(pr)

        aggregate = {
            "mse_mean": float(np.nanmean(mse_list)) if mse_list else float("nan"),
            "mae_mean": float(np.nanmean(mae_list)) if mae_list else float("nan"),
            "r2_mean": float(np.nanmean(r2_list)) if r2_list else float("nan"),
            "pearson_mean": float(np.nanmean(p_list)) if p_list else float("nan"),
        }

        return {"per_dim": per_dim, "aggregate": aggregate}

    def compute_calibration(
        self,
        predictions: np.ndarray,
        targets: np.ndarray,
        uncertainties: np.ndarray,
        masks: Optional[np.ndarray] = None,
        num_bins: int = 10,
    ) -> float:
        """
        Expected Calibration Error (ECE) for regression using uncertainty-based predictive intervals.

        Approach:
          - For a set of nominal coverages q in (0,1), build symmetric intervals:
                [pred - z_q * sigma, pred + z_q * sigma]
            where z_q is the standard-normal quantile for coverage q.
          - Compute empirical coverage over labeled targets.
          - ECE is the average absolute error between empirical and nominal coverages.

        This is a lightweight calibration metric that correlates with "are my error bars honest?"
        """
        predictions = np.asarray(predictions, dtype=np.float64)
        targets = np.asarray(targets, dtype=np.float64)
        uncertainties = np.asarray(uncertainties, dtype=np.float64)

        if masks is None:
            masks = np.ones_like(targets, dtype=bool)
        else:
            masks = np.asarray(masks, dtype=bool)

        # Avoid degenerate sigmas
        sig = np.clip(uncertainties, 1e-6, None)

        # Quantiles / nominal coverages
        qs = np.linspace(0.1, 0.9, num_bins)

        # Use torch Normal icdf for quantiles (no scipy dependency)
        normal = torch.distributions.Normal(loc=torch.tensor(0.0), scale=torch.tensor(1.0))

        errors = []
        for q in qs:
            # Symmetric interval coverage q => tail prob (1-q)/2
            # Need z such that P(|Z| <= z) = q => z = Phi^{-1}((1+q)/2)
            z = float(normal.icdf(torch.tensor((1.0 + q) / 2.0)).item())

            lower = predictions - z * sig
            upper = predictions + z * sig

            inside = (targets >= lower) & (targets <= upper) & masks
            denom = masks.sum()
            if denom < 1:
                continue
            empirical = inside.sum() / denom
            errors.append(abs(empirical - q))

        if not errors:
            return float("nan")
        return float(np.mean(errors))

    def generate_report(self, metrics: Dict) -> str:
        """
        Format metrics as a readable report string.
        """
        per_dim = metrics.get("per_dim", {})
        agg = metrics.get("aggregate", {})
        ece = metrics.get("calibration_ece", float("nan"))

        lines: List[str] = []
        lines.append("Z24 Evaluation Report")
        lines.append("=" * 80)
        lines.append(f"Aggregate:")
        lines.append(f"  MSE (mean):     {agg.get('mse_mean', float('nan')):.6f}")
        lines.append(f"  MAE (mean):     {agg.get('mae_mean', float('nan')):.6f}")
        lines.append(f"  R^2 (mean):     {agg.get('r2_mean', float('nan')):.6f}")
        lines.append(f"  Pearson (mean): {agg.get('pearson_mean', float('nan')):.6f}")
        lines.append(f"  Calibration ECE:{ece:.6f}")
        lines.append("")
        lines.append("Per-dimension:")
        lines.append("-" * 80)
        header = f"{'Dim':<5} {'MSE':>10} {'MAE':>10} {'R2':>10} {'Pearson':>10}"
        lines.append(header)
        lines.append("-" * 80)

        for d in range(1, 25):
            k = f"D{d}"
            m = per_dim.get(k, {})
            mse = m.get("mse", float("nan"))
            mae = m.get("mae", float("nan"))
            r2 = m.get("r2", float("nan"))
            pr = m.get("pearson", float("nan"))
            lines.append(f"{k:<5} {mse:>10.6f} {mae:>10.6f} {r2:>10.6f} {pr:>10.6f}")

        return "\n".join(lines)
