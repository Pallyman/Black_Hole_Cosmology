"""
z24_active_learning.py

Active Learning Loop for Z24
============================

Uses model uncertainty to identify samples that would benefit most from human review.

Architecture:
1. Score unlabeled samples with uncertainty estimation
2. Rank by acquisition function (uncertainty, diversity, etc.)
3. Present top-k samples for human annotation
4. Incorporate new labels and retrain
5. Repeat

Acquisition Functions:
- Uncertainty sampling (highest uncertainty)
- Diversity sampling (coverage of feature space)
- Hybrid (uncertainty + diversity)
- Expected model change

Features:
- Async batch processing
- Human-in-the-loop interface
- Automatic retraining triggers
- Progress tracking

Dependencies: torch, numpy, scikit-learn
Python: 3.10+

Author: Hannah (Claude)
Date: February 12, 2026
"""

from __future__ import annotations

import json
import logging
import os
import random
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Tuple
from enum import Enum

import numpy as np
import torch
from sklearn.cluster import KMeans
from sklearn.metrics.pairwise import cosine_similarity

try:
    from z24_encoder import Z24Encoder
    from z24_dimensions import ALL_DIMENSIONS
except ImportError:
    pass


logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


# =============================================================================
# Configuration
# =============================================================================

class AcquisitionStrategy(Enum):
    """Strategies for selecting samples"""
    UNCERTAINTY = "uncertainty"           # Highest total uncertainty
    UNCERTAINTY_MARGIN = "margin"         # Smallest margin between dimensions
    DIVERSITY = "diversity"               # K-means diversity
    HYBRID = "hybrid"                     # Uncertainty + diversity
    EXPECTED_CHANGE = "expected_change"   # Expected model improvement
    RANDOM = "random"                     # Random baseline


@dataclass
class ActiveLearningConfig:
    """Configuration for active learning"""
    
    # Selection
    strategy: AcquisitionStrategy = AcquisitionStrategy.HYBRID
    batch_size: int = 50              # Samples per annotation batch
    uncertainty_weight: float = 0.6   # For hybrid strategy
    diversity_weight: float = 0.4
    
    # Thresholds
    high_uncertainty_threshold: float = 0.25   # Flag if uncertainty > this
    low_confidence_threshold: float = 0.6      # Flag if max score < this
    
    # Retraining
    retrain_after_n_labels: int = 200
    min_samples_for_retrain: int = 100
    
    # Paths
    pool_path: str = "unlabeled_pool.jsonl"
    labeled_path: str = "labeled_data.jsonl"
    review_queue_path: str = "review_queue.jsonl"
    
    # Human interface
    enable_web_interface: bool = False
    web_port: int = 8080


@dataclass
class SampleCandidate:
    """A sample being considered for annotation"""
    
    sample_id: str
    context: str
    response: str
    
    # Uncertainty metrics
    total_uncertainty: float
    per_dim_uncertainty: Dict[str, float]
    uncertainty_margin: float   # Difference between most and least uncertain
    
    # Scores (if available from model)
    predicted_scores: Optional[Dict[str, float]] = None
    
    # Diversity metrics
    embedding: Optional[np.ndarray] = None
    cluster_id: Optional[int] = None
    distance_to_centroid: float = 0.0
    
    # Acquisition score
    acquisition_score: float = 0.0
    
    # Metadata
    source: str = ""
    timestamp: str = ""
    
    def to_dict(self) -> Dict:
        return {
            "sample_id": self.sample_id,
            "context": self.context,
            "response": self.response,
            "total_uncertainty": self.total_uncertainty,
            "uncertainty_margin": self.uncertainty_margin,
            "acquisition_score": self.acquisition_score,
            "predicted_scores": self.predicted_scores,
            "source": self.source,
        }


# =============================================================================
# Acquisition Functions
# =============================================================================

def uncertainty_acquisition(candidates: List[SampleCandidate]) -> List[SampleCandidate]:
    """
    Rank by total uncertainty (highest first).
    Simple but effective baseline.
    """
    for c in candidates:
        c.acquisition_score = c.total_uncertainty
    
    return sorted(candidates, key=lambda x: x.acquisition_score, reverse=True)


def margin_acquisition(candidates: List[SampleCandidate]) -> List[SampleCandidate]:
    """
    Rank by uncertainty margin (lowest margin = most uncertain overall).
    Identifies samples where model is equally confused across dimensions.
    """
    for c in candidates:
        if c.per_dim_uncertainty:
            uncertainties = list(c.per_dim_uncertainty.values())
            c.acquisition_score = 1.0 - (max(uncertainties) - min(uncertainties))
        else:
            c.acquisition_score = c.total_uncertainty
    
    return sorted(candidates, key=lambda x: x.acquisition_score, reverse=True)


def diversity_acquisition(
    candidates: List[SampleCandidate],
    n_select: int,
    n_clusters: int = 10,
) -> List[SampleCandidate]:
    """
    Select diverse samples using K-means clustering.
    Pick samples closest to each cluster centroid.
    """
    if not candidates or not candidates[0].embedding is not None:
        logger.warning("No embeddings available for diversity sampling")
        return random.sample(candidates, min(n_select, len(candidates)))
    
    # Stack embeddings
    embeddings = np.stack([c.embedding for c in candidates if c.embedding is not None])
    
    # Cluster
    n_clusters = min(n_clusters, len(candidates), n_select)
    kmeans = KMeans(n_clusters=n_clusters, random_state=42, n_init=10)
    cluster_labels = kmeans.fit_predict(embeddings)
    
    # Assign cluster info
    for i, c in enumerate(candidates):
        if c.embedding is not None:
            c.cluster_id = int(cluster_labels[i])
            centroid = kmeans.cluster_centers_[c.cluster_id]
            c.distance_to_centroid = float(np.linalg.norm(c.embedding - centroid))
    
    # Select closest to each centroid
    selected = []
    for cluster_id in range(n_clusters):
        cluster_candidates = [c for c in candidates if c.cluster_id == cluster_id]
        if cluster_candidates:
            # Sort by distance to centroid (closest first)
            cluster_candidates.sort(key=lambda x: x.distance_to_centroid)
            selected.append(cluster_candidates[0])
    
    # Fill remaining slots with random high-uncertainty samples
    remaining = [c for c in candidates if c not in selected]
    remaining.sort(key=lambda x: x.total_uncertainty, reverse=True)
    
    while len(selected) < n_select and remaining:
        selected.append(remaining.pop(0))
    
    # Set acquisition scores
    for i, c in enumerate(selected):
        c.acquisition_score = 1.0 - (i / len(selected))
    
    return selected


def hybrid_acquisition(
    candidates: List[SampleCandidate],
    n_select: int,
    uncertainty_weight: float = 0.6,
    diversity_weight: float = 0.4,
) -> List[SampleCandidate]:
    """
    Combine uncertainty and diversity.
    
    Score = uncertainty_weight * norm_uncertainty + diversity_weight * norm_diversity
    """
    # Normalize uncertainty scores
    uncertainties = [c.total_uncertainty for c in candidates]
    u_min, u_max = min(uncertainties), max(uncertainties)
    u_range = u_max - u_min if u_max > u_min else 1.0
    
    for c in candidates:
        c.acquisition_score = uncertainty_weight * ((c.total_uncertainty - u_min) / u_range)
    
    # Add diversity component if embeddings available
    if candidates and candidates[0].embedding is not None:
        embeddings = np.stack([c.embedding for c in candidates if c.embedding is not None])
        
        # Compute pairwise distances
        # Higher distance to existing selected = more diverse
        selected_indices = []
        
        for _ in range(min(n_select, len(candidates))):
            if not selected_indices:
                # First selection: highest uncertainty
                best_idx = max(range(len(candidates)), key=lambda i: candidates[i].acquisition_score)
            else:
                # Compute min distance to any selected sample
                selected_embeddings = embeddings[selected_indices]
                
                best_idx = -1
                best_score = -1
                
                for i, c in enumerate(candidates):
                    if i in selected_indices:
                        continue
                    
                    # Min distance to selected
                    distances = np.linalg.norm(embeddings[i] - selected_embeddings, axis=1)
                    min_distance = distances.min()
                    
                    # Combined score
                    diversity_score = min_distance / (embeddings.std() + 1e-6)
                    combined = (
                        uncertainty_weight * c.acquisition_score +
                        diversity_weight * diversity_score
                    )
                    
                    if combined > best_score:
                        best_score = combined
                        best_idx = i
            
            if best_idx >= 0:
                selected_indices.append(best_idx)
        
        # Reorder by selection order
        result = [candidates[i] for i in selected_indices]
        for i, c in enumerate(result):
            c.acquisition_score = 1.0 - (i / len(result))
        
        return result
    
    # Fallback to pure uncertainty
    return sorted(candidates, key=lambda x: x.acquisition_score, reverse=True)[:n_select]


ACQUISITION_FUNCTIONS = {
    AcquisitionStrategy.UNCERTAINTY: uncertainty_acquisition,
    AcquisitionStrategy.UNCERTAINTY_MARGIN: margin_acquisition,
    AcquisitionStrategy.DIVERSITY: diversity_acquisition,
    AcquisitionStrategy.HYBRID: hybrid_acquisition,
    AcquisitionStrategy.RANDOM: lambda c: random.sample(c, len(c)),
}


# =============================================================================
# Active Learning Loop
# =============================================================================

class ActiveLearningLoop:
    """
    Main active learning controller.
    """
    
    def __init__(
        self,
        model: Z24Encoder,
        config: Optional[ActiveLearningConfig] = None,
    ):
        self.model = model
        self.config = config or ActiveLearningConfig()
        self.device = next(model.parameters()).device
        
        # State
        self.pool: List[Dict[str, Any]] = []
        self.labeled: List[Dict[str, Any]] = []
        self.review_queue: List[SampleCandidate] = []
        
        self.labels_since_retrain = 0
        self.total_labels = 0
        self.iteration = 0
        
        self._load_state()
    
    def _load_state(self) -> None:
        """Load pool and labeled data from disk"""
        if os.path.exists(self.config.pool_path):
            with open(self.config.pool_path, "r") as f:
                self.pool = [json.loads(line) for line in f if line.strip()]
            logger.info(f"Loaded {len(self.pool)} samples from pool")
        
        if os.path.exists(self.config.labeled_path):
            with open(self.config.labeled_path, "r") as f:
                self.labeled = [json.loads(line) for line in f if line.strip()]
            self.total_labels = len(self.labeled)
            logger.info(f"Loaded {len(self.labeled)} labeled samples")
    
    def _save_state(self) -> None:
        """Save state to disk"""
        with open(self.config.pool_path, "w") as f:
            for sample in self.pool:
                f.write(json.dumps(sample) + "\n")
        
        with open(self.config.labeled_path, "w") as f:
            for sample in self.labeled:
                f.write(json.dumps(sample) + "\n")
    
    def add_to_pool(self, samples: List[Dict[str, Any]]) -> int:
        """Add unlabeled samples to the pool"""
        added = 0
        existing_ids = {s.get("sample_id") for s in self.pool}
        
        for sample in samples:
            sample_id = sample.get("sample_id", f"sample_{len(self.pool)}")
            if sample_id not in existing_ids:
                sample["sample_id"] = sample_id
                self.pool.append(sample)
                added += 1
        
        self._save_state()
        logger.info(f"Added {added} samples to pool (total: {len(self.pool)})")
        return added
    
    @torch.inference_mode()
    def score_pool(self, batch_size: int = 32) -> List[SampleCandidate]:
        """
        Score all pool samples and compute uncertainty.
        Returns list of SampleCandidates ready for acquisition.
        """
        self.model.eval()
        candidates = []
        
        for i in range(0, len(self.pool), batch_size):
            batch = self.pool[i:i + batch_size]
            
            # Tokenize
            tokenizer = self.model.get_tokenizer()
            contexts = [s.get("context", "") for s in batch]
            responses = [s.get("response", "") for s in batch]
            
            encoded = tokenizer(
                contexts,
                responses,
                truncation="longest_first",
                max_length=512,
                padding=True,
                return_tensors="pt",
            )
            encoded = {k: v.to(self.device) for k, v in encoded.items()}
            
            # Forward with MC dropout for better uncertainty
            output = self.model.predict_mc_dropout(
                input_ids=encoded["input_ids"],
                attention_mask=encoded["attention_mask"],
                token_type_ids=encoded.get("token_type_ids"),
                num_samples=10,
            )
            
            scores = output["z24_scores"].cpu().numpy()
            uncertainties = output["uncertainties"].cpu().numpy()
            
            # Get embeddings for diversity sampling
            encoder_out = self.model.encoder(**encoded)
            from z24_encoder import mean_pool
            embeddings = mean_pool(
                encoder_out.last_hidden_state,
                encoded["attention_mask"],
            ).cpu().numpy()
            
            for j, sample in enumerate(batch):
                per_dim_unc = {f"D{k+1}": float(uncertainties[j, k]) for k in range(24)}
                total_unc = float(uncertainties[j].mean())
                
                unc_values = list(per_dim_unc.values())
                unc_margin = max(unc_values) - min(unc_values)
                
                candidate = SampleCandidate(
                    sample_id=sample.get("sample_id", f"sample_{i+j}"),
                    context=sample.get("context", ""),
                    response=sample.get("response", ""),
                    total_uncertainty=total_unc,
                    per_dim_uncertainty=per_dim_unc,
                    uncertainty_margin=unc_margin,
                    predicted_scores={f"D{k+1}": float(scores[j, k]) for k in range(24)},
                    embedding=embeddings[j],
                    source=sample.get("source", ""),
                    timestamp=datetime.now().isoformat(),
                )
                
                candidates.append(candidate)
        
        logger.info(f"Scored {len(candidates)} candidates")
        return candidates
    
    def select_for_review(
        self,
        n_samples: Optional[int] = None,
    ) -> List[SampleCandidate]:
        """
        Select samples for human review using configured strategy.
        """
        n_samples = n_samples or self.config.batch_size
        
        # Score pool
        candidates = self.score_pool()
        
        if not candidates:
            logger.warning("No candidates available for selection")
            return []
        
        # Apply acquisition function
        strategy = self.config.strategy
        
        if strategy == AcquisitionStrategy.UNCERTAINTY:
            selected = uncertainty_acquisition(candidates)[:n_samples]
        
        elif strategy == AcquisitionStrategy.UNCERTAINTY_MARGIN:
            selected = margin_acquisition(candidates)[:n_samples]
        
        elif strategy == AcquisitionStrategy.DIVERSITY:
            selected = diversity_acquisition(candidates, n_samples)
        
        elif strategy == AcquisitionStrategy.HYBRID:
            selected = hybrid_acquisition(
                candidates,
                n_samples,
                self.config.uncertainty_weight,
                self.config.diversity_weight,
            )
        
        elif strategy == AcquisitionStrategy.RANDOM:
            selected = random.sample(candidates, min(n_samples, len(candidates)))
        
        else:
            selected = candidates[:n_samples]
        
        # Update review queue
        self.review_queue = selected
        
        # Save queue to disk
        with open(self.config.review_queue_path, "w") as f:
            for c in selected:
                f.write(json.dumps(c.to_dict()) + "\n")
        
        logger.info(f"Selected {len(selected)} samples for review (strategy: {strategy.value})")
        
        # Log statistics
        avg_uncertainty = np.mean([c.total_uncertainty for c in selected])
        logger.info(f"Average uncertainty of selected samples: {avg_uncertainty:.4f}")
        
        return selected
    
    def submit_labels(
        self,
        labeled_samples: List[Dict[str, Any]],
    ) -> int:
        """
        Submit human-annotated labels.
        
        Each sample should have:
        - sample_id: str
        - labels: Dict[str, float] (D1-D24 scores)
        """
        added = 0
        
        for sample in labeled_samples:
            sample_id = sample.get("sample_id")
            labels = sample.get("labels", {})
            
            if not sample_id or not labels:
                continue
            
            # Find original sample
            pool_sample = next((s for s in self.pool if s.get("sample_id") == sample_id), None)
            
            if pool_sample:
                # Move from pool to labeled
                pool_sample["labels"] = labels
                pool_sample["labeled_at"] = datetime.now().isoformat()
                pool_sample["labeling_method"] = "human"
                
                self.labeled.append(pool_sample)
                self.pool.remove(pool_sample)
                
                added += 1
        
        self.labels_since_retrain += added
        self.total_labels += added
        
        self._save_state()
        
        logger.info(f"Added {added} human labels (total: {self.total_labels})")
        
        # Check if retraining needed
        if self.labels_since_retrain >= self.config.retrain_after_n_labels:
            if self.total_labels >= self.config.min_samples_for_retrain:
                logger.info("Triggering retraining...")
                self._trigger_retrain()
        
        return added
    
    def _trigger_retrain(self) -> None:
        """Trigger model retraining with new labels"""
        # This would integrate with z24_trainer.py
        # For now, just log
        logger.info(f"Retraining triggered with {self.total_labels} labeled samples")
        self.labels_since_retrain = 0
        self.iteration += 1
    
    def get_statistics(self) -> Dict[str, Any]:
        """Get current active learning statistics"""
        return {
            "pool_size": len(self.pool),
            "labeled_size": len(self.labeled),
            "review_queue_size": len(self.review_queue),
            "total_labels": self.total_labels,
            "labels_since_retrain": self.labels_since_retrain,
            "iteration": self.iteration,
            "strategy": self.config.strategy.value,
        }
    
    def export_for_annotation(
        self,
        output_path: str,
        format: str = "jsonl",
    ) -> str:
        """
        Export review queue in format suitable for annotation tool.
        """
        if not self.review_queue:
            self.select_for_review()
        
        if format == "jsonl":
            with open(output_path, "w") as f:
                for c in self.review_queue:
                    record = {
                        "sample_id": c.sample_id,
                        "context": c.context,
                        "response": c.response,
                        "predicted_scores": c.predicted_scores,
                        "uncertainty": c.total_uncertainty,
                        "labels": {},  # To be filled by annotator
                    }
                    f.write(json.dumps(record) + "\n")
        
        elif format == "csv":
            import csv
            with open(output_path, "w", newline="") as f:
                writer = csv.DictWriter(f, fieldnames=[
                    "sample_id", "context", "response", "uncertainty",
                    *[f"D{i}" for i in range(1, 25)]
                ])
                writer.writeheader()
                for c in self.review_queue:
                    row = {
                        "sample_id": c.sample_id,
                        "context": c.context[:500],
                        "response": c.response[:500],
                        "uncertainty": c.total_uncertainty,
                    }
                    for i in range(1, 25):
                        row[f"D{i}"] = ""  # To be filled
                    writer.writerow(row)
        
        logger.info(f"Exported {len(self.review_queue)} samples to {output_path}")
        return output_path


# =============================================================================
# Human-in-the-Loop Interface
# =============================================================================

def create_annotation_interface(
    loop: ActiveLearningLoop,
    port: int = 8080,
):
    """
    Create a simple web interface for annotation.
    
    Requires: flask
    """
    try:
        from flask import Flask, render_template_string, request, jsonify
    except ImportError:
        logger.error("Flask not installed. Run: pip install flask")
        return None
    
    app = Flask(__name__)
    
    HTML_TEMPLATE = """
    <!DOCTYPE html>
    <html>
    <head>
        <title>Z24 Annotation Interface</title>
        <style>
            body { font-family: Arial, sans-serif; margin: 20px; }
            .sample { border: 1px solid #ccc; padding: 15px; margin: 10px 0; }
            .context { background: #f0f0f0; padding: 10px; }
            .response { background: #e8f4e8; padding: 10px; }
            .dimensions { display: grid; grid-template-columns: repeat(4, 1fr); gap: 10px; }
            .dimension { display: flex; align-items: center; gap: 5px; }
            input[type="range"] { width: 100px; }
            button { padding: 10px 20px; margin: 5px; cursor: pointer; }
            .save-btn { background: #4CAF50; color: white; }
            .skip-btn { background: #f44336; color: white; }
        </style>
    </head>
    <body>
        <h1>Z24 Annotation Interface</h1>
        <div id="stats"></div>
        <div id="sample"></div>
        <script>
            let currentSample = null;
            let queue = [];
            
            async function loadQueue() {
                const resp = await fetch('/api/queue');
                queue = await resp.json();
                document.getElementById('stats').innerHTML = 
                    `Queue: ${queue.length} samples | Total labeled: ${queue.total_labels || 0}`;
                if (queue.length > 0) loadSample(0);
            }
            
            function loadSample(idx) {
                currentSample = queue[idx];
                const dims = Array.from({length: 24}, (_, i) => `
                    <div class="dimension">
                        <label>D${i+1}</label>
                        <input type="range" id="d${i+1}" min="0" max="1" step="0.05" value="0.5">
                        <span id="v${i+1}">0.5</span>
                    </div>
                `).join('');
                
                document.getElementById('sample').innerHTML = `
                    <div class="sample">
                        <h3>Sample: ${currentSample.sample_id}</h3>
                        <p>Uncertainty: ${currentSample.uncertainty?.toFixed(3) || 'N/A'}</p>
                        <div class="context"><strong>Context:</strong><br>${currentSample.context}</div>
                        <div class="response"><strong>Response:</strong><br>${currentSample.response}</div>
                        <h4>Dimension Scores:</h4>
                        <div class="dimensions">${dims}</div>
                        <button class="save-btn" onclick="save()">Save & Next</button>
                        <button class="skip-btn" onclick="skip()">Skip</button>
                    </div>
                `;
                
                // Add listeners
                for (let i = 1; i <= 24; i++) {
                    document.getElementById(`d${i}`).oninput = function() {
                        document.getElementById(`v${i}`).innerText = this.value;
                    };
                }
            }
            
            async function save() {
                const labels = {};
                for (let i = 1; i <= 24; i++) {
                    labels[`D${i}`] = parseFloat(document.getElementById(`d${i}`).value);
                }
                
                await fetch('/api/submit', {
                    method: 'POST',
                    headers: {'Content-Type': 'application/json'},
                    body: JSON.stringify({
                        sample_id: currentSample.sample_id,
                        labels: labels
                    })
                });
                
                loadQueue();
            }
            
            function skip() {
                queue.shift();
                if (queue.length > 0) loadSample(0);
            }
            
            loadQueue();
        </script>
    </body>
    </html>
    """
    
    @app.route('/')
    def index():
        return render_template_string(HTML_TEMPLATE)
    
    @app.route('/api/queue')
    def get_queue():
        if not loop.review_queue:
            loop.select_for_review()
        
        return jsonify([c.to_dict() for c in loop.review_queue])
    
    @app.route('/api/submit', methods=['POST'])
    def submit():
        data = request.json
        loop.submit_labels([data])
        return jsonify({"status": "ok"})
    
    @app.route('/api/stats')
    def stats():
        return jsonify(loop.get_statistics())
    
    return app


# =============================================================================
# CLI
# =============================================================================

if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description="Z24 Active Learning")
    parser.add_argument("--pool", default="unlabeled_pool.jsonl", help="Unlabeled pool path")
    parser.add_argument("--select", type=int, default=50, help="Number of samples to select")
    parser.add_argument("--strategy", choices=["uncertainty", "diversity", "hybrid", "random"], 
                        default="hybrid")
    parser.add_argument("--export", help="Export selected samples to this path")
    parser.add_argument("--serve", action="store_true", help="Start annotation web interface")
    parser.add_argument("--port", type=int, default=8080)
    
    args = parser.parse_args()
    
    # Demo without model
    print("Z24 Active Learning")
    print("=" * 60)
    print(f"Strategy: {args.strategy}")
    print(f"Batch size: {args.select}")
    
    if args.serve:
        print(f"Starting annotation interface on port {args.port}...")
        # Would need model loaded for real usage
        print("Note: Run with actual model for full functionality")
