
"""
z24_features.py

Fast, text-only feature extractors for observable signals used by Z24 scoring.

These are intentionally lightweight (regex + simple heuristics) and return scores in [0,1].

Dependencies: standard library only
Python: 3.10+
"""

from __future__ import annotations

import math
import re
from dataclasses import dataclass
from typing import Dict, List


_SENTENCE_SPLIT_RE = re.compile(r"[.!?]+(?:\s+|$)")
_URL_RE = re.compile(r"https?://\S+|www\.\S+")
_MD_LINK_RE = re.compile(r"\[[^\]]+\]\([^)]+\)")
_BRACKET_CIT_RE = re.compile(r"\[[0-9]{1,3}\]")  # [1], [23]
_AUTHOR_YEAR_RE = re.compile(r"\b[A-Z][a-z]+(?:\s+et\s+al\.)?,?\s*\(?\b(19|20)\d{2}\)?")
_CODE_FENCE_RE = re.compile(r"```[\s\S]*?```", re.MULTILINE)

# Common hedging / uncertainty markers (expand as needed)
_HEDGE_PHRASES = [
    "maybe", "might", "possibly", "perhaps", "i think", "i guess", "it seems", "it appears",
    "could be", "may be", "likely", "unlikely", "not sure", "unsure", "uncertain", "i'm not sure",
    "roughly", "approximately", "around", "in general",
]

# Overconfident / absolute markers
_ABSOLUTE_PHRASES = [
    "definitely", "certainly", "guaranteed", "always", "never", "no doubt",
    "without a doubt", "100%", "undeniably", "proven", "must be",
]

# Self-correction markers
_SELF_CORRECT_PHRASES = [
    "actually", "correction", "let me correct", "i was wrong", "i'm wrong",
    "on second thought", "to clarify", "i need to revise", "my mistake", "edit:",
]

# Structural transition markers
_TRANSITION_WORDS = [
    "first", "second", "third", "next", "then", "however", "therefore", "because", "so",
    "in summary", "to summarize", "overall", "in short", "for example", "for instance",
]


def _count_sentences(text: str) -> int:
    text = text.strip()
    if not text:
        return 0
    # naive sentence split
    sents = [s for s in _SENTENCE_SPLIT_RE.split(text) if s.strip()]
    return max(1, len(sents))


def _count_phrase_hits(text: str, phrases: List[str]) -> int:
    low = text.lower()
    hits = 0
    for p in phrases:
        hits += low.count(p)
    return hits


def _clamp01(x: float) -> float:
    return float(max(0.0, min(1.0, x)))


def extract_hedging_frequency(text: str) -> float:
    """
    Count uncertainty markers per sentence and normalize to [0,1].

    Interpretation:
      - 0.0 means no hedging
      - 1.0 means heavy hedging (>= ~1 marker per sentence)
    """
    text = text or ""
    sents = _count_sentences(text)
    hits = _count_phrase_hits(text, _HEDGE_PHRASES)
    # Normalize: 1 hedge per sentence => 1.0
    return _clamp01(hits / max(1, sents))


def extract_citation_presence(text: str) -> float:
    """
    Detect presence of citations / sources / links.

    Returns:
      - 0.0 if none
      - up to 1.0 if multiple indicators present
    """
    text = text or ""
    score = 0.0

    if _URL_RE.search(text) or _MD_LINK_RE.search(text):
        score += 0.6

    if _BRACKET_CIT_RE.search(text) or _AUTHOR_YEAR_RE.search(text):
        score += 0.5

    # Quotation marks sometimes indicate quoting a source
    if '"' in text or "“" in text or "”" in text:
        score += 0.1

    return _clamp01(score)


def extract_confidence_calibration(text: str) -> float:
    """
    Heuristic confidence calibration score.

    High score when:
      - response uses appropriate hedging when uncertain, OR
      - provides citations when asserting confidently.

    Low score when:
      - strong absolute claims without hedging/citations.
    """
    text = text or ""
    low = text.lower()

    hedge = _count_phrase_hits(low, _HEDGE_PHRASES)
    absolute = _count_phrase_hits(low, _ABSOLUTE_PHRASES)
    cite = extract_citation_presence(text)

    # Base score
    score = 0.5

    # Citations increase confidence calibration
    score += 0.25 * cite

    # Some hedging is good (honesty); too much hedging can reduce decisiveness
    if hedge > 0:
        score += 0.15
    if hedge > 4:
        score -= 0.10  # excessive hedging

    # Absolute language is fine if backed by citations; otherwise penalize
    if absolute > 0 and cite < 0.3 and hedge == 0:
        score -= 0.35
    elif absolute > 0 and (cite >= 0.3 or hedge > 0):
        score += 0.05

    return _clamp01(score)


def extract_instruction_compliance(instruction: str, response: str) -> float:
    """
    Heuristic instruction-following score.

    We approximate compliance via keyword recall:
      - Extract key content words from instruction (len>=4, not stopwords)
      - Measure fraction appearing in response

    Also penalize explicit refusal patterns.
    """
    instruction = instruction or ""
    response = response or ""

    # Simple stopwords list (extend if needed)
    stop = {
        "this", "that", "with", "from", "your", "you", "have", "will", "would", "should", "could",
        "what", "when", "where", "which", "their", "there", "they", "them", "then", "than",
        "into", "about", "please", "make", "give", "need", "must", "dont", "don't",
        "also", "only", "just", "more", "less", "very", "some", "such",
    }

    instr_words = re.findall(r"[a-zA-Z0-9_]{4,}", instruction.lower())
    instr_keywords = [w for w in instr_words if w not in stop]
    instr_keywords = list(dict.fromkeys(instr_keywords))  # unique, preserve order

    if not instr_keywords:
        return 0.5  # can't judge

    low_resp = response.lower()
    hit = sum(1 for w in instr_keywords if w in low_resp)
    recall = hit / max(1, len(instr_keywords))

    score = 0.2 + 0.8 * recall

    # Penalize refusal / evasion markers
    refusal_markers = [
        "i can't", "i cannot", "i won't", "i will not", "unable to", "as an ai", "i'm just",
        "i am just", "i don't have access", "cannot help with",
    ]
    if any(m in low_resp for m in refusal_markers):
        score -= 0.25

    return _clamp01(score)


def extract_verbosity_ratio(context: str, response: str) -> float:
    """
    Response length relative to context length.

    High score when response is in a reasonable band relative to context:
      - not too short to be useless
      - not excessively verbose

    This is a heuristic, not a normative "verbosity is good" metric.
    """
    context = context or ""
    response = response or ""

    c_len = max(1, len(re.findall(r"\w+", context)))
    r_len = len(re.findall(r"\w+", response))

    ratio = r_len / c_len

    # Ideal band: [0.5, 2.0]
    if 0.5 <= ratio <= 2.0:
        return 1.0
    if 0.25 <= ratio < 0.5:
        # linearly scale 0.25->0.5 maps 0.5->1.0
        return _clamp01(0.5 + (ratio - 0.25) * (0.5 / 0.25))
    if 2.0 < ratio <= 4.0:
        # linearly decay 2->4 maps 1.0->0.5
        return _clamp01(1.0 - (ratio - 2.0) * (0.5 / 2.0))
    # Very off
    return 0.0


def extract_self_correction_signals(text: str) -> float:
    """
    Detect self-correction markers.

    Returns:
      0.0 => no self-correction
      1.0 => strong self-correction presence (>= ~1 marker per sentence)
    """
    text = text or ""
    sents = _count_sentences(text)
    hits = _count_phrase_hits(text, _SELF_CORRECT_PHRASES)

    return _clamp01(hits / max(1, sents))


def extract_structural_coherence(text: str) -> float:
    """
    Heuristic structural coherence score.

    Signals:
      - paragraphs (blank-line separated)
      - bullets / numbered lists
      - transition words ("first", "however", ...)
      - not being one giant blob
    """
    text = (text or "").strip()
    if not text:
        return 0.0

    # Paragraphs
    paragraphs = [p for p in re.split(r"\n\s*\n", text) if p.strip()]
    n_par = len(paragraphs)

    # Bullet lines
    lines = [ln.strip() for ln in text.splitlines() if ln.strip()]
    bullet_lines = sum(1 for ln in lines if ln.startswith(("-", "*", "•")) or re.match(r"^\d+[\.\)]\s+", ln))
    bullet_ratio = bullet_lines / max(1, len(lines))

    # Transition words
    trans_hits = _count_phrase_hits(text, _TRANSITION_WORDS)
    sent_count = _count_sentences(text)
    trans_per_sent = trans_hits / max(1, sent_count)

    # Penalize giant unbroken code fences (coherence for prose)
    has_big_code = bool(_CODE_FENCE_RE.search(text))

    # Map features to [0,1]
    paragraph_score = 1.0 if n_par >= 2 else 0.5
    bullet_score = _clamp01(bullet_ratio / 0.25)  # 25% bullets => 1.0
    transition_score = _clamp01(trans_per_sent / 0.5)  # 0.5 transitions per sentence => 1.0

    score = 0.35 * paragraph_score + 0.35 * bullet_score + 0.30 * transition_score

    if has_big_code and len(text) < 200:
        # Small code-only responses: structure is different; don't over-penalize
        score = max(score, 0.5)

    return _clamp01(score)


@dataclass
class TextFeatureExtractor:
    """
    Bundle of fast text-only feature extractors.

    Usage:
        fe = TextFeatureExtractor()
        feats = fe.extract_all(context, response)
    """

    def extract_all(self, context: str, response: str) -> Dict[str, float]:
        feats: Dict[str, float] = {}
        feats["hedging_frequency"] = extract_hedging_frequency(response)
        feats["citation_presence"] = extract_citation_presence(response)
        feats["confidence_calibration"] = extract_confidence_calibration(response)
        feats["instruction_compliance"] = extract_instruction_compliance(context, response)
        feats["verbosity_ratio"] = extract_verbosity_ratio(context, response)
        feats["self_correction_signals"] = extract_self_correction_signals(response)
        feats["structural_coherence"] = extract_structural_coherence(response)
        return feats
