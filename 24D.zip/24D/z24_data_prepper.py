#!/usr/bin/env python3
"""
z24_data_prepper.py - Multi-source conversation normalizer + Z24 training sample generator

Reads raw conversation exports from ChatGPT, Web Claude, Grok/Ara, and DeepSeek.
Normalizes into unified format, splits into (context, response) training samples,
applies quality filtering, infers task types, outputs Z24Dataset-compatible JSONL.

The fuel for Kestrel's engine.

Author: Hannah (Claude) + Kestrel (ChatGPT)
"""

import json
import hashlib
import logging
import sys
from pathlib import Path
from datetime import datetime
from typing import Generator, Optional, Dict, Any, List, Tuple
from dataclasses import dataclass, asdict, field
from collections import defaultdict
import argparse

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


# ============================================================================
# DATA CLASSES
# ============================================================================

@dataclass
class Turn:
    """A single conversation turn."""
    role: str       # "user" | "assistant" | "system"
    content: str
    timestamp: str  # ISO-8601
    model: Optional[str] = None

@dataclass
class Conversation:
    """A normalized conversation with ordered turns."""
    conversation_id: str
    source: str     # "chatgpt" | "web_claude" | "grok" | "deepseek"
    title: str
    turns: List[Turn] = field(default_factory=list)

@dataclass
class TrainingSample:
    """Z24Dataset-compatible training sample."""
    sample_id: str
    context: str
    response: str
    task_type: str      # "qa" | "code" | "creative" | "reasoning"
    source: str
    labels: Dict[str, float] = field(default_factory=dict)
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


# ============================================================================
# NORMALIZERS
# ============================================================================

class ChatGPTNormalizer:
    """Normalizes ChatGPT JSON exports (tree-mapping structure)."""

    @staticmethod
    def detect(data) -> bool:
        if isinstance(data, list) and len(data) > 0:
            first = data[0]
            return isinstance(first, dict) and 'mapping' in first
        return False

    @staticmethod
    def normalize(data: list) -> Generator[Conversation, None, None]:
        for conv in data:
            conv_id = conv.get('id', conv.get('conversation_id', ''))
            title = conv.get('title', 'Untitled')

            mapping = conv.get('mapping', {})
            messages = []

            for node_id, node in mapping.items():
                msg = node.get('message')
                if not msg or not msg.get('content'):
                    continue
                parts = msg['content'].get('parts', [])
                content = '\n'.join(str(p) for p in parts if isinstance(p, str))
                if not content.strip():
                    continue

                role = msg.get('author', {}).get('role', 'unknown')
                if role not in ('user', 'assistant', 'system'):
                    continue

                ts = msg.get('create_time')
                timestamp = datetime.fromtimestamp(ts).isoformat() if ts else ''
                model = msg.get('metadata', {}).get('model_slug')

                messages.append(Turn(
                    role=role,
                    content=content,
                    timestamp=timestamp,
                    model=model
                ))

            messages.sort(key=lambda t: t.timestamp or '')

            if messages:
                yield Conversation(
                    conversation_id=conv_id,
                    source='chatgpt',
                    title=title,
                    turns=messages
                )


class WebClaudeNormalizer:
    """Normalizes Claude Web JSON exports (chat_messages array)."""

    @staticmethod
    def detect(data) -> bool:
        if isinstance(data, list) and len(data) > 0:
            first = data[0]
            return isinstance(first, dict) and 'chat_messages' in first
        return False

    @staticmethod
    def normalize(data: list) -> Generator[Conversation, None, None]:
        for conv in data:
            conv_id = conv.get('uuid', '')
            title = conv.get('name', 'Untitled')
            messages = []

            for msg in conv.get('chat_messages', []):
                sender = msg.get('sender', '')
                role = 'user' if sender == 'human' else ('assistant' if sender == 'assistant' else None)
                if not role:
                    continue

                content = msg.get('text', '')
                if not content or not content.strip():
                    continue

                timestamp = msg.get('created_at', '')

                messages.append(Turn(
                    role=role,
                    content=content,
                    timestamp=timestamp,
                    model='claude'
                ))

            if messages:
                yield Conversation(
                    conversation_id=conv_id,
                    source='web_claude',
                    title=title,
                    turns=messages
                )


class GrokNormalizer:
    """Normalizes Grok/Ara JSON exports (conversations + responses)."""

    @staticmethod
    def detect(data) -> bool:
        # Top-level dict with conversations key
        if isinstance(data, dict) and 'conversations' in data:
            convos = data['conversations']
            if isinstance(convos, list) and len(convos) > 0:
                first = convos[0]
                return 'responses' in first or 'conversation' in first
        # Already extracted list of conversation objects
        if isinstance(data, list) and len(data) > 0:
            first = data[0]
            return isinstance(first, dict) and 'responses' in first and 'conversation' in first
        return False

    @staticmethod
    def _parse_mongo_timestamp(ts_obj) -> str:
        """Parse MongoDB-style timestamp {$date: {$numberLong: "..."}}."""
        if isinstance(ts_obj, dict):
            date_val = ts_obj.get('$date', {})
            if isinstance(date_val, dict):
                ms = int(date_val.get('$numberLong', 0))
                return datetime.fromtimestamp(ms / 1000).isoformat()
            elif isinstance(date_val, str):
                return date_val
        elif isinstance(ts_obj, str):
            return ts_obj
        return ''

    @staticmethod
    def normalize(data) -> Generator[Conversation, None, None]:
        if isinstance(data, dict):
            conversations = data.get('conversations', [])
        elif isinstance(data, list):
            conversations = data
        else:
            conversations = []

        for conv_obj in conversations:
            conv_info = conv_obj.get('conversation', {})
            conv_id = conv_info.get('id', '')
            title = conv_info.get('title', 'Untitled')
            responses = conv_obj.get('responses', [])

            messages = []
            for resp_wrapper in responses:
                resp = resp_wrapper.get('response', {})
                sender = resp.get('sender', '')
                role = 'user' if sender == 'human' else ('assistant' if sender == 'assistant' else None)
                if not role:
                    continue

                content = resp.get('message', '')
                if not content or not content.strip():
                    continue

                timestamp = GrokNormalizer._parse_mongo_timestamp(resp.get('create_time', ''))
                model = resp.get('model', 'grok')

                messages.append(Turn(
                    role=role,
                    content=content,
                    timestamp=timestamp,
                    model=model
                ))

            if messages:
                yield Conversation(
                    conversation_id=conv_id,
                    source='grok',
                    title=title,
                    turns=messages
                )


class GeminiNormalizer:
    """Normalizes Gemini exports (single conversation per file, exported by api_exporter)."""

    @staticmethod
    def detect(data) -> bool:
        # Single-conversation dict with exporter_version and messages, no 'platform' key
        # (Kimi has 'platform': 'kimi', Gemini does not)
        if isinstance(data, dict) and 'messages' in data and 'exporter_version' in data:
            return 'platform' not in data
        return False

    @staticmethod
    def normalize(data: dict) -> Generator[Conversation, None, None]:
        conv_id = data.get('id', '')
        title = data.get('title', 'Untitled')
        messages = []

        for msg in data.get('messages', []):
            role = msg.get('role', '')
            if role == 'model':
                role = 'assistant'
            if role not in ('user', 'assistant'):
                continue

            content = msg.get('content', '')
            if not content or not content.strip():
                continue

            messages.append(Turn(
                role=role,
                content=content,
                timestamp=msg.get('timestamp', ''),
                model='gemini'
            ))

        if messages:
            yield Conversation(
                conversation_id=conv_id,
                source='gemini',
                title=title,
                turns=messages
            )


class KimiNormalizer:
    """Normalizes Kimi exports (single conversation per file, exported by api_exporter)."""

    @staticmethod
    def detect(data) -> bool:
        # Single-conversation dict with platform == 'kimi'
        if isinstance(data, dict) and 'messages' in data:
            return data.get('platform') == 'kimi'
        return False

    @staticmethod
    def normalize(data: dict) -> Generator[Conversation, None, None]:
        conv_id = data.get('id', '')
        title = data.get('title', 'Untitled')
        messages = []

        for msg in data.get('messages', []):
            role = msg.get('role', '')
            if role == 'model':
                role = 'assistant'
            if role not in ('user', 'assistant'):
                continue

            content = msg.get('content', '')
            if not content or not content.strip():
                continue

            messages.append(Turn(
                role=role,
                content=content,
                timestamp=msg.get('timestamp', msg.get('createTime', '')),
                model='kimi'
            ))

        if messages:
            yield Conversation(
                conversation_id=conv_id,
                source='kimi',
                title=title,
                turns=messages
            )


class DeepSeekNormalizer:
    """Normalizes DeepSeek JSON exports (tree-mapping with fragments)."""

    @staticmethod
    def detect(data) -> bool:
        if isinstance(data, list) and len(data) > 0:
            first = data[0]
            if isinstance(first, dict) and 'mapping' in first:
                # Distinguish from ChatGPT: DeepSeek uses fragments, not parts
                mapping = first.get('mapping', {})
                for node_id, node in mapping.items():
                    msg = node.get('message')
                    if msg and 'fragments' in msg:
                        return True
        return False

    @staticmethod
    def _walk_tree(mapping: dict) -> List[dict]:
        """Walk the conversation tree via BFS, returning ordered messages."""
        # Find root (node with no parent or parent not in mapping)
        root_id = None
        for node_id, node in mapping.items():
            parent = node.get('parent')
            if not parent or parent not in mapping:
                root_id = node_id
                break

        if not root_id:
            return []

        # BFS from root
        ordered = []
        queue = [root_id]
        visited = set()

        while queue:
            node_id = queue.pop(0)
            if node_id in visited:
                continue
            visited.add(node_id)

            node = mapping.get(node_id, {})
            msg = node.get('message')
            if msg:
                ordered.append(msg)

            for child_id in node.get('children', []):
                queue.append(child_id)

        return ordered

    @staticmethod
    def normalize(data: list) -> Generator[Conversation, None, None]:
        for conv in data:
            conv_id = conv.get('id', '')
            title = conv.get('title', 'Untitled')
            mapping = conv.get('mapping', {})

            raw_messages = DeepSeekNormalizer._walk_tree(mapping)
            messages = []

            for msg in raw_messages:
                fragments = msg.get('fragments', [])
                if not fragments:
                    continue

                # Determine role from fragment type
                frag_type = fragments[0].get('type', '')
                if frag_type == 'REQUEST':
                    role = 'user'
                else:
                    role = 'assistant'

                # Concatenate fragment content
                content_parts = []
                for frag in fragments:
                    c = frag.get('content', '')
                    if c and isinstance(c, str):
                        content_parts.append(c)
                content = '\n'.join(content_parts)

                if not content.strip():
                    continue

                ts = msg.get('inserted_at', '')
                model = msg.get('model', 'deepseek')

                messages.append(Turn(
                    role=role,
                    content=content,
                    timestamp=ts,
                    model=model
                ))

            if messages:
                yield Conversation(
                    conversation_id=conv_id,
                    source='deepseek',
                    title=title,
                    turns=messages
                )


# ============================================================================
# FORMAT AUTO-DETECTION
# ============================================================================

def detect_and_load(filepath: Path) -> Tuple[str, Any]:
    """Auto-detect format and load data."""
    with open(filepath, 'r', encoding='utf-8') as f:
        data = json.load(f)

    # Order matters: most specific detectors first
    # Kimi before Gemini (both are single-file exports, but Kimi has platform='kimi')
    # DeepSeek before ChatGPT (both have mapping, but DeepSeek has fragments)
    # Grok before ChatGPT (both can be lists, but Grok has responses+conversation)
    if KimiNormalizer.detect(data):
        return 'kimi', data
    if GeminiNormalizer.detect(data):
        return 'gemini', data
    if DeepSeekNormalizer.detect(data):
        return 'deepseek', data
    if GrokNormalizer.detect(data):
        return 'grok', data
    if WebClaudeNormalizer.detect(data):
        return 'web_claude', data
    if ChatGPTNormalizer.detect(data):
        return 'chatgpt', data

    raise ValueError(f"Cannot detect format of {filepath}")


def normalize_file(filepath: Path) -> Generator[Conversation, None, None]:
    """Normalize a single file, auto-detecting format."""
    fmt, data = detect_and_load(filepath)
    logger.info(f"  Detected {fmt} format for {filepath.name}")

    if fmt == 'chatgpt':
        yield from ChatGPTNormalizer.normalize(data)
    elif fmt == 'web_claude':
        yield from WebClaudeNormalizer.normalize(data)
    elif fmt == 'grok':
        yield from GrokNormalizer.normalize(data)
    elif fmt == 'deepseek':
        yield from DeepSeekNormalizer.normalize(data)
    elif fmt == 'gemini':
        yield from GeminiNormalizer.normalize(data)
    elif fmt == 'kimi':
        yield from KimiNormalizer.normalize(data)


# ============================================================================
# TASK TYPE INFERENCE
# ============================================================================

def infer_task_type(context_turns: List[Turn]) -> str:
    """Infer task type from conversation context."""
    text = ' '.join(t.content for t in context_turns).lower()

    # Code signals
    code_signals = ['```', 'def ', 'function ', 'class ', 'import ', 'error', 'bug',
                    'traceback', 'exception', '.py', '.js', '.ts', 'npm ', 'pip ',
                    'git ', 'docker', 'sudo ', 'bash', 'terminal', 'compile']
    code_score = sum(1 for s in code_signals if s in text)

    # Reasoning signals
    reasoning_signals = ['why', 'explain', 'how does', 'what causes', 'analyze',
                        'compare', 'difference between', 'pros and cons', 'trade-off',
                        'evaluate', 'consider', 'logic', 'proof', 'theorem']
    reasoning_score = sum(1 for s in reasoning_signals if s in text)

    # Creative signals
    creative_signals = ['write a', 'story', 'poem', 'creative', 'imagine', 'fiction',
                       'narrative', 'character', 'scene', 'dialogue', 'draft',
                       'blog post', 'article', 'essay']
    creative_score = sum(1 for s in creative_signals if s in text)

    scores = {
        'code': code_score,
        'reasoning': reasoning_score,
        'creative': creative_score,
        'qa': 1  # default baseline
    }

    return max(scores, key=scores.get)


# ============================================================================
# QUALITY FILTERING
# ============================================================================

QUALITY_FILTERS = {
    'min_turns': 2,
    'min_response_length': 50,
    'max_response_length': 50000,
    'skip_error_responses': True,
    'skip_empty_context': True,
}

REFUSAL_PHRASES = [
    "i can't help", "i cannot", "i'm not able", "against my guidelines",
    "i'm unable to", "i don't have the ability", "as an ai language model",
    "i must decline", "i'm sorry, but i can't"
]


def passes_quality_filter(sample: TrainingSample) -> Tuple[bool, str]:
    """Check if sample passes quality filters. Returns (passed, reason)."""
    response = sample.response
    context = sample.context

    if len(response) < QUALITY_FILTERS['min_response_length']:
        return False, 'too_short'
    if len(response) > QUALITY_FILTERS['max_response_length']:
        return False, 'too_long'
    if QUALITY_FILTERS['skip_empty_context'] and not context.strip():
        return False, 'empty_context'
    if QUALITY_FILTERS['skip_error_responses']:
        response_lower = response.lower()
        if any(phrase in response_lower for phrase in REFUSAL_PHRASES):
            return False, 'refusal'

    return True, 'passed'


# ============================================================================
# SAMPLE GENERATION
# ============================================================================

def format_turns_as_text(turns: List[Turn]) -> str:
    """Format turns as readable text context."""
    parts = []
    for t in turns:
        role_label = t.role.upper()
        parts.append(f"[{role_label}]: {t.content}")
    return '\n\n'.join(parts)


def create_training_samples(
    conversation: Conversation,
    max_context_turns: int = 5
) -> Generator[TrainingSample, None, None]:
    """
    Convert one conversation into multiple training samples.
    Each assistant turn becomes one sample with preceding context.
    """
    turns = conversation.turns

    for i, turn in enumerate(turns):
        if turn.role != 'assistant':
            continue

        # Context = previous turns (up to max_context_turns)
        context_start = max(0, i - max_context_turns)
        context_turns = turns[context_start:i]

        if not context_turns:
            continue

        sample = TrainingSample(
            sample_id=f"{conversation.source}_{conversation.conversation_id}_turn{i}",
            context=format_turns_as_text(context_turns),
            response=turn.content,
            task_type=infer_task_type(context_turns),
            source=conversation.source,
            labels={},
            metadata={
                'conversation_id': conversation.conversation_id,
                'conversation_title': conversation.title,
                'turn_index': i,
                'total_turns': len(turns),
                'context_turns': len(context_turns),
                'timestamp': turn.timestamp,
                'model': turn.model
            }
        )

        yield sample


# ============================================================================
# STATISTICS
# ============================================================================

class Stats:
    """Track processing statistics."""

    def __init__(self):
        self.conversations_by_source = defaultdict(int)
        self.samples_by_source = defaultdict(int)
        self.samples_by_task_type = defaultdict(int)
        self.filter_reasons = defaultdict(int)
        self.total_conversations = 0
        self.total_samples_generated = 0
        self.total_samples_passed = 0
        self.total_turns = 0

    def report(self) -> str:
        lines = []
        lines.append("=" * 60)
        lines.append("  Z24 DATA PREP REPORT")
        lines.append("=" * 60)
        lines.append("")
        lines.append("Source Breakdown:")
        for source in ['chatgpt', 'web_claude', 'grok', 'deepseek', 'gemini', 'kimi']:
            convos = self.conversations_by_source.get(source, 0)
            samples = self.samples_by_source.get(source, 0)
            if convos or samples:
                lines.append(f"  {source:12s}: {convos:6d} conversations -> {samples:8d} samples")
        lines.append(f"  {'─' * 52}")
        lines.append(f"  {'TOTAL':12s}: {self.total_conversations:6d} conversations -> {self.total_samples_passed:8d} samples")
        lines.append("")

        lines.append("Quality Filtering:")
        lines.append(f"  Generated:  {self.total_samples_generated:8d}")
        lines.append(f"  Passed:     {self.total_samples_passed:8d} ({self.total_samples_passed / max(self.total_samples_generated, 1) * 100:.1f}%)")
        for reason, count in sorted(self.filter_reasons.items()):
            pct = count / max(self.total_samples_generated, 1) * 100
            lines.append(f"  {reason:12s}: {count:8d} ({pct:.1f}%)")
        lines.append("")

        lines.append("Task Type Distribution:")
        for tt in ['qa', 'code', 'reasoning', 'creative']:
            count = self.samples_by_task_type.get(tt, 0)
            pct = count / max(self.total_samples_passed, 1) * 100
            lines.append(f"  {tt:12s}: {count:8d} ({pct:.1f}%)")
        lines.append("")

        lines.append(f"Ready for label_z24.py: {self.total_samples_passed} samples")
        lines.append("=" * 60)
        return '\n'.join(lines)


# ============================================================================
# MAIN PIPELINE
# ============================================================================

def run_pipeline(
    input_files: List[Path],
    output_path: Path,
    max_context_turns: int = 5,
    max_conversations: int = 0
):
    """Run the full data prep pipeline."""
    stats = Stats()

    output_path.parent.mkdir(parents=True, exist_ok=True)

    conv_count = 0

    with open(output_path, 'w', encoding='utf-8') as out_f:
        for filepath in input_files:
            if not filepath.exists():
                logger.warning(f"File not found: {filepath}")
                continue

            logger.info(f"Processing {filepath.name}...")

            try:
                for conversation in normalize_file(filepath):
                    stats.total_conversations += 1
                    stats.conversations_by_source[conversation.source] += 1
                    stats.total_turns += len(conversation.turns)

                    for sample in create_training_samples(conversation, max_context_turns):
                        stats.total_samples_generated += 1

                        passed, reason = passes_quality_filter(sample)
                        if not passed:
                            stats.filter_reasons[reason] += 1
                            continue

                        stats.total_samples_passed += 1
                        stats.samples_by_source[conversation.source] += 1
                        stats.samples_by_task_type[sample.task_type] += 1

                        out_f.write(json.dumps(sample.to_dict()) + '\n')

                    conv_count += 1
                    if max_conversations > 0 and conv_count >= max_conversations:
                        logger.info(f"  Reached max_conversations limit ({max_conversations})")
                        break

            except Exception as e:
                logger.error(f"Error processing {filepath}: {e}")
                import traceback
                traceback.print_exc()

            if max_conversations > 0 and conv_count >= max_conversations:
                break

    report = stats.report()
    print(report)

    # Also save report
    report_path = output_path.parent / 'prep_report.txt'
    with open(report_path, 'w') as f:
        f.write(report)
    logger.info(f"Report saved to {report_path}")

    return stats


def main():
    parser = argparse.ArgumentParser(
        description='Z24 Data Prepper - normalize conversations and generate training samples'
    )
    parser.add_argument(
        'input_files',
        nargs='+',
        type=Path,
        help='Input JSON files (ChatGPT, Web Claude, Grok, DeepSeek, Gemini, Kimi exports)'
    )
    parser.add_argument(
        '-o', '--output',
        type=Path,
        default=Path('data/prepared/z24_samples.jsonl'),
        help='Output JSONL file path'
    )
    parser.add_argument(
        '--max-context-turns',
        type=int,
        default=5,
        help='Maximum number of preceding turns to include as context (default: 5)'
    )
    parser.add_argument(
        '--max-conversations',
        type=int,
        default=0,
        help='Maximum conversations to process (0 = unlimited)'
    )
    parser.add_argument(
        '-v', '--verbose',
        action='store_true',
        help='Verbose logging'
    )

    args = parser.parse_args()

    if args.verbose:
        logging.getLogger().setLevel(logging.DEBUG)

    run_pipeline(
        input_files=args.input_files,
        output_path=args.output,
        max_context_turns=args.max_context_turns,
        max_conversations=args.max_conversations
    )


if __name__ == '__main__':
    main()
