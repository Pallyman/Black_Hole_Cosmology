# Related topics

This directory contains a list of additional topics that are adjacent to everything discussed in prior chapters.

These chapters don't contain a training script individually, but the changes discussed in each are relatively small, and code snippets are provided to make it easy to add the features into your code.
